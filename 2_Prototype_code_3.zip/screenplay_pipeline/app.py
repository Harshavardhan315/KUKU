"""Promo Finder - web prototype.

Run:  streamlit run app.py
Upload a script (.txt / .zip of episodes) or use the built-in demo show, press
"Find promos", and get a ranked posting plan with timestamps, reasons and the
spoken text of each clip.
"""
from __future__ import annotations

import dataclasses
import os
import shutil
import tempfile
import zipfile
from pathlib import Path

import pandas as pd
import streamlit as st

from screenplay_pipeline.pipeline import PipelineConfig, run_pipeline
from screenplay_pipeline.promos import PromoConfig, promo_transcript

HERE = Path(__file__).parent
DEMO = HERE / "sample" / "demo_show"

st.set_page_config(page_title="Promo Finder", page_icon="🎬", layout="wide")
st.title("🎬 Promo Finder for microdrama screenplays")
st.caption("Finds 20-60 s promo clips that open on a hook, end on an unresolved cliffhanger "
           "and make sense to a stranger, then ranks them and plans the posting order.")

# ---------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("1. Input")
    source = st.radio("Script source", ["Demo show (3 invented episodes)", "Upload my own"], index=0)
    uploads = None
    if source == "Upload my own":
        uploads = st.file_uploader("Episode .txt files, or one .zip", type=["txt", "zip"],
                                   accept_multiple_files=True)
        st.warning("Uploaded scripts are processed in memory on this server and deleted after the run. "
                   "Do not upload confidential scripts to a public deployment.")

    st.header("2. Settings")
    min_len, max_len = st.slider("Promo length (seconds)", 15, 90, (20, 60))
    per_ep = st.slider("Max promos per episode", 1, 5, 2)
    stitch = st.checkbox("Allow stitched promos (two moments joined)", value=True)
    strict_end = st.checkbox("Strict ending gate (must end unresolved)", value=True)
    strict_open = st.checkbox("Strict stand-alone opening gate", value=True)

    st.header("3. Optional model re-rank")
    provider = st.selectbox("Provider", ["none (rules only)", "openai-compatible", "anthropic"])
    model = base_url = ""
    key = ""
    if provider != "none (rules only)":
        model = st.text_input("Model name")
        if provider == "openai-compatible":
            base_url = st.text_input("Base URL", "https://api.openai.com/v1")
        key = st.text_input("API key (used for this run only)", type="password")
        st.caption("The model only re-judges the top candidates; a failed call keeps the rule score.")

    run = st.button("Find promos", type="primary", width="stretch")


# ---------------------------------------------------------------- helpers
def stage_input(workdir: Path) -> Path:
    """Copy the chosen scripts into workdir and return the folder to read."""
    src = workdir / "in"
    src.mkdir()
    if source.startswith("Demo"):
        for f in DEMO.glob("*.txt"):
            shutil.copy(f, src / f.name)
        return src
    if not uploads:
        raise ValueError("Upload at least one .txt episode or a .zip of episodes.")
    for u in uploads:
        data = u.getvalue()
        if u.name.lower().endswith(".zip"):
            zpath = workdir / u.name
            zpath.write_bytes(data)
            with zipfile.ZipFile(zpath) as z:
                for m in z.namelist():                      # block path tricks
                    if Path(m).is_absolute() or ".." in Path(m).parts:
                        raise ValueError(f"unsafe path in zip: {m}")
                z.extractall(src)
        else:
            (src / Path(u.name).name).write_bytes(data)
    return src


def run_all() -> dict:
    work = Path(tempfile.mkdtemp(prefix="promo_app_"))
    try:
        src = stage_input(work)
        pc = dataclasses.replace(PromoConfig(), min_len=float(min_len), max_len=float(max_len),
                                 max_per_episode=per_ep, stitch=stitch,
                                 strict_ending=strict_end, strict_standalone=strict_open)
        kw = dict(input_path=str(src), output_dir=str(work / "out"), workers=1,
                  make_figures=False, promo_config=pc)
        if provider != "none (rules only)":
            if not key or not model:
                raise ValueError("Re-rank needs a model name and an API key (or switch it off).")
            os.environ["PROMO_APP_KEY"] = key
            extra = {"model": model, "api_key_env": "PROMO_APP_KEY"}
            if base_url:
                extra["base_url"] = base_url
            kw.update(rerank_provider=provider, rerank_kwargs=extra)
        res = run_pipeline(PipelineConfig(**kw))
        out = work / "out"
        md = (out / "PROMOS.md").read_text(encoding="utf-8") if (out / "PROMOS.md").exists() else ""
        csv = (out / "data" / "promos.csv").read_bytes() if (out / "data" / "promos.csv").exists() else b""
        return {"summary": res["summary"], "promos": res["tables"].get("promos", pd.DataFrame()),
                "elements": res["tables"]["elements"], "md": md, "csv": csv}
    finally:
        os.environ.pop("PROMO_APP_KEY", None)
        shutil.rmtree(work, ignore_errors=True)


# ---------------------------------------------------------------- run
if run:
    try:
        with st.spinner("Parsing episodes, scoring, finding promos..."):
            st.session_state["result"] = run_all()
    except (ValueError, SystemExit) as e:
        st.session_state.pop("result", None)
        st.error(str(e))
    except Exception as e:                                  # show, don't crash the page
        st.session_state.pop("result", None)
        st.error(f"The run failed: {type(e).__name__}: {e}")

res = st.session_state.get("result")
if not res:
    st.info("Pick a source on the left and press **Find promos**. The demo show runs in about a second.")
    st.stop()

S, P, E = res["summary"], res["promos"], res["elements"]
c = st.columns(5)
c[0].metric("Episodes", S["n_episodes"])
c[1].metric("Script runtime (min)", S["total_runtime_min"])
c[2].metric("Promos found", len(P))
c[3].metric("Total promo time (min)", round(P["duration_s"].sum() / 60, 1) if len(P) else 0)
c[4].metric("Pipeline time (s)", S["runtime_seconds"]["total"] if isinstance(S.get("runtime_seconds"), dict) else S.get("runtime_seconds"))

if S.get("rerank"):
    st.success(f"Model re-rank: {S['rerank']}")

if P.empty:
    st.warning("No promo passed every gate. Try widening the length range or relaxing the ending gate.")
    st.stop()

tab1, tab2, tab3 = st.tabs(["Posting plan", "Inspect a promo", "How the gates behaved"])

with tab1:
    plan = P.sort_values("post_order")[["post_order", "wave", "rank", "timestamps", "kind", "duration_s",
                                         "hook", "end_type", "cliffhanger", "score"]].copy()
    plan["score"] = plan["score"].round(2)
    st.dataframe(plan, width="stretch", hide_index=True)
    d1, d2, _ = st.columns([1, 1, 4])
    d1.download_button("Download promos.csv", res["csv"], "promos.csv", "text/csv")
    d2.download_button("Download PROMOS.md", res["md"], "PROMOS.md", "text/markdown")

with tab2:
    order = P.sort_values("post_order")
    pick = st.selectbox("Promo (in posting order)", order.index,
                        format_func=lambda i: f"#{order.loc[i, 'post_order']}  ·  {order.loc[i, 'timestamps']}  ·  "
                                              f"{order.loc[i, 'duration_s']:.0f}s")
    r = P.loc[pick]
    left, right = st.columns([3, 2])
    with left:
        talk, notes = promo_transcript(r, E)
        st.subheader("What the viewer hears")
        st.code(talk, language=None)
        st.subheader("What the shot notes show")
        st.code(notes or "(no shot notes in this window)", language=None)
    with right:
        st.subheader("Why it works")
        st.write(r["why_it_works"])
        st.subheader("Why it is posted here")
        st.write(r["post_reason"])
        st.subheader("Scores (0-1)")
        st.table(pd.DataFrame({"score": {k: round(float(r[k]), 2) for k in
                 ["hook_score", "cliffhanger_score", "drama_score", "standalone_score", "score"]}}))
        st.caption(f"Hook type: {r['hook_kind']} · ends on: {r['end_type']} · "
                   f"{'stitched from ' + str(r['n_segments']) + ' moments' if r['n_segments'] > 1 else 'one continuous stretch'}")

with tab3:
    fs = S.get("promo_filter_stats") or {}
    st.write("Counts of what the gates rejected before ranking:")
    st.json(fs)
    st.write("Promo kinds:", S.get("promo_kinds"))
    st.caption("A rejected opening means the line would confuse a stranger (a dangling 'And...', a reply to a "
               "question we cannot see). A rejected ending means the clip would stop on a settled or neutral beat.")
