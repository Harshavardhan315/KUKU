# Screenplay Scene Breakdown & Sentiment Pipeline

Parses episodic screenplays into structured scenes / dialogue / action, maps who interacts with whom,
tracks emotional polarity and mood across each episode, and exports metrics, charts and a report.

Built and verified on a 50-episode microdrama pack (3,727 blocks, 100 scenes, ~103 min of screen time):
**0 parse issues, element counts match the raw files exactly, full run in ~1.3 s.**

```bash
pip install -r requirements.txt
python -m screenplay_pipeline run --input scripts.zip --output output/     # file | folder | .zip
python -m pytest -q                                                          # 57 tests
```

Outputs: `output/PROMOS.md` (ranked promo shortlist), `output/REPORT.md`, `summary.json`, `data/*.csv` (elements, scenes, beats, episodes, characters,
network edges, mood transitions, parse issues, ...), `figures/*.png`.

---


## Web prototype (the "prototype link")

```bash
pip install -r requirements.txt
streamlit run app.py
```

Pick the built-in demo show (3 invented episodes, safe to publish) or upload your own `.txt` episodes / one `.zip`,
press **Find promos**, and you get the ranked posting plan, each clip's spoken text and shot notes, why it works, why it
is posted at that slot, and what the gates rejected. `promos.csv` and `PROMOS.md` download from the page.
An optional sidebar panel re-ranks the shortlist with a model (OpenAI-compatible or Anthropic) using a key you paste for that run only.

**Hosting (free):** push this folder to GitHub, then on share.streamlit.io choose the repo, branch `main`, main file `app.py`.
Do not commit confidential scripts or the real raw outputs to a public repo; the demo show in `sample/demo_show/` is enough for reviewers.

## 1. Architecture

```
 .zip / folder / .txt
        │  ingest.py        in-memory zip read (no extraction), encoding fallback, natural sort
        ▼
 ┌────────────── per-episode, process pool, chunked ───────────────┐
 │ A  parser.py     dialect detect → streaming state machine       │
 │                  → Episode{Scene{Element}} + ParseIssues        │
 │ C1 sentiment.py  score each element (backend + tone tags)       │
 └──────────────────────── returns DataFrames ────────────────────┘
        ▼
 characters.py   alias file → honorific folding → canonical speaker; mention detector
        ▼
 B  network.py   scene presence → co-presence edges, dialogue exchanges, centrality, communities
        ▼
 C2 sentiment.py scenes + 10-s "beats" → sentiment / intensity / mood, arcs, turning points
        ▼
 D  metrics.py   dialogue:action ratio, pacing, per-character table, summary.json, REPORT.md
 viz.py          6 PNG charts
```

| Concern | Choice | Why |
|---|---|---|
| Language / data | Python 3.11+, pandas, numpy | Tabular, vectorisable, universal |
| Parsing | `re` + line-oriented state machine | Deterministic, O(n), debuggable; no ML needed for structured text |
| Sentiment | VADER + domain lexicon overlay + delivery-tag fusion; **swappable backend** | Free, ~instant, no GPU, deterministic. A transformer drops in via `--backend transformer` |
| Network | networkx | Centrality + community detection in a few lines |
| Charts | matplotlib | Static PNGs for the report |
| Parallelism | `ProcessPoolExecutor` | Parse/score is CPU-bound Python; episodes are independent |

**Division of labour: rules vs. model.** Structure (headings, cues, timestamps), identity resolution,
metrics and aggregation are *code*. Only word-level polarity is "model" (VADER), and it is corrected by the
author's own emotion annotations in the script (`(Trembling, Pleading)`), which are treated as the
strongest signal.

---

## 2. The data (and what it forced)

The sample is **not** classic Fountain text. Every block is `**LABEL (tone tags):**` + `Start/End` timing +
text, with `CAMERA`, `ACTION`, `SOUND FX` blocks alongside dialogue. Findings that shaped the design:

* **Episodes are ~2 minutes and 25 of 50 contain a single scene.** Scene-level arcs were meaningless on a first
  attempt, so arcs, shifts and mood transitions run on equal-length ~10-second **beats** (`--beat-seconds`).
* **Delivery tags are rich** (620 distinct, 1,236 combos, e.g. `Mocking, Spiteful`, `O.S.`, `Continuing`) and
  beat the word-level model on short lines → tag lexicon + fusion.
* **Episode 6 uses upper-case structural keys** (`SCENE HEADING:`) → case-insensitive keys.
* **Characters change labels**: `JULIANA`/`LADY JULIANA`, `THE FORMER GROOM` = `GERALD`,
  `THE BEARDED STRANGER`→`ALEXANDER` after the reveal.
* A second dialect (classic screenplay) is also supported so a new input doesn't break the tool.

---

## 3. Modules

### A · `parser.py` — regex screenplay parser
`parse_text(text) → Episode`, `episodes_to_frames(episodes) → {elements, scenes, episodes, issues}`

* **Elements:** `DIALOGUE / ACTION / CAMERA / SOUND / TEXT` with `speaker_raw`, `tone` tags, `modifiers`
  (`O.S.`, `V.O.`), `start`, `end`, cleaned `text`.
* **Scenes:** heading split into `int_ext`, `location`, `location_base`, `time_of_day`; `CONTINUOUS`
  inherits the previous scene's time of day (`tod_effective`).
* **Issues, never exceptions:** `missing_timing`, `negative_duration`, `element_outside_scene`,
  `empty_block`, `orphan_text`, `duplicate_episode_number`, ... → `parse_issues.csv`.

### B · `characters.py` + `network.py` — entities & interactions
* **Co-presence** (undirected): characters *speak* in the scene **or are named in action/camera text**
  → `scenes_together`, `scenes_both_speak`. Per-episode and series-level edge tables.
* **Dialogue exchange** (directed): `A → B` when B speaks right after A in the same scene.
* Degree/strength, betweenness, PageRank, greedy-modularity communities.

### C · `sentiment.py` — polarity & narrative arc
Per element: `sent = 0.4·VADER(text) + 0.6·mean(tag valence)` (dialogue with tags), else VADER alone.
Weights: dialogue 1.0 · action 0.6 · camera/sound 0.3 · × log(1 + words).
* `emotion` ∈ anger, contempt, fear, shock, sadness, tenderness, joy, resolve (tags weigh 1.0, text
  keywords 0.4).
* Per scene/beat: `sentiment`, `intensity` (|sent|), `volatility`, `dominant_mood`, `delta_prev`,
  `major_shift` (jump ≥ 1.5·σ of that episode's deltas and ≥ 0.15).
* Per episode: opening/closing sentiment & mood, `closing_intensity`, turning points, **arc shape**
  (rise / fall / man-in-a-hole / icarus / flat — simplified Reagan et al. 2016).
* Series: mood-transition matrix (beat → next beat).

### D · `metrics.py` — summary & export
`dialogue_word_share`, `da_word_ratio`, `dialogue_time_share` (union of intervals, so overlapping blocks
aren't double-counted), `shots_per_min`, `avg_shot_len`, `words_per_min`, per-character footprint/emotion/
centrality, headline `summary.json`, human-readable `REPORT.md`. Definitions are in the module docstring.

### E · `promos.py` — promo shortlist (the brief's Problem 1)
Finds 20-60 s promos as **one contiguous stretch or a stitch of non-contiguous moments** (same episode, or the next
`cross_span` episodes). Every dialogue/action block start × lengths 20..60 s (end snaps to a block end, never
mid-line), scored 0-1 on:

* **hook** - first 3 s, `(1-visual_share)` × text arousal + `visual_share` (0.4) × the strongest **camera / sound /
  action note** overlapping those seconds (`visual.py`: tight insert, push-in, slap, shatter, explosion, "eyes snap wide"
  ... noisy-OR of weighted cues). *The input has no video, so "visual" = the script's written shot description, not pixels.*
* **cliffhanger** - end intensity, unanswered question / cut-off line, clip reaches the show's own episode end, and a
  strong visual/sound beat in the last 6 s.
* **Ending gate** - a promo may only *end* on an open question, a cut-off line, or a charged line/action/shot with tension
  left hanging. Resolved or neutral endings (a settled line, scene-setting action, a bare camera hold) and warm/reassuring
  ones ("reassuringly... fades to black") are rejected: 2,632 candidate endings on the sample. Every promo records its
  `end_type`.
* **drama** - intensity + emotional range.  **standalone** - speaker count (two in conflict is best), continuity.

**Hard stand-alone gate** (`standalone.py`): a clip may not open on a dangling conjunction (And/But/So/Then...), a
mid-sentence fragment, an unresolved pronoun (he/she/they with nobody named in the opening shot), a one/two-word reply, a
short "that/this/it" line, or a line that leans on earlier events ("as I said", "last time"). Rejections are counted in
`PROMOS.md` (here: 488 of 1,567 possible opening blocks). It removes *detectable* dependencies only.

**Stitching**: a strong opening segment (6-30 s) + a strong closing segment from a later moment, in order, total 20-60 s.
A pair needs shared characters **and** shared distinctive spoken words (a topical thread; 2+ across episodes). On the sample,
9,333 cross-episode joins had shared characters and fit 20-60 s; the thread rule cut them to 38, none of which won - without it,
9 cross-episode promos with no real connection would have been picked.
A 0.05 penalty keeps a contiguous clip ahead when it is as good.

Output per promo (`promos.csv`): `rank, episode(s), kind (single | stitched-in-episode | stitched-cross-episode),
n_segments, timestamps ("ep32 01:11-01:36 | ep32 02:20-02:34"), duration_s, score, hook, visual_hook, cliffhanger,
end_type, why_it_works, signals, post_order, wave, post_reason, opening_line`, component scores, `segments_json`.
`why_it_works` is one viewer-facing line ("Opens on a physical blow inside 3 s, so a scroller stops; ...; ends on an
unanswered question, so viewers tap through to the next episode"); the mechanical drivers sit in `signals`.

**Posting plan** (`plan_posting`): `rank` is quality; `post_order` is the schedule - quality order, but no two promos from one
episode within 2 slots of each other. Wave 1 (first 10) = lead posts, wave 2 (next 30) = steady follow-ups, wave 3 = backfill.
`post_reason` says why each is where it is (its best trait vs the set average, what it opens/ends on, and "held back a slot"
when spacing moved it). The rationale wording is a model of viewer behaviour (scroll-stop, tap-through), not measured on any
platform. Weights, stitch and gate switches live in `PromoConfig`
(`--no-stitch`, `--no-cross-episode`). Result on the sample: 96 promos (90 single, 6 stitched in-episode, 0 cross-episode),
mean 37.2 s, 57 with a strong visual hook, 23% end where the episode ends; endings: 38 open question, 28 charged line,
16 cut-off line, 9 charged action, 5 charged shot. Check quality with
`evaluate promo-sample|promo-score` (blind y/n sheet -> your precision@20).

### F · `providers.py` — swap the model with a flag
Optional model re-rank behind one interface: `RerankProvider.judge(clips) -> [ClipVerdict | None]`. A `ClipView`
carries transcript, shot notes, the rules' own hook/cliffhanger and an optional `media` path/URL (so a *video* model
can plug in later). `None` = "no opinion", so a failing/slow/garbled model can never change a ranking.
Built in (stdlib only): `rules` (default, no model), `openai-compatible` (OpenAI, Groq, OpenRouter, Gemini's OpenAI
endpoint, Ollama, vLLM, LM Studio) and `anthropic`; `register_provider(name, factory)` adds yours.

```bash
python -m screenplay_pipeline run --input scripts.zip --output out \
  --rerank-provider openai-compatible --rerank-model llama-3.3-70b-versatile \
  --rerank-base-url https://api.groq.com/openai/v1 --rerank-key-env GROQ_API_KEY --rerank-cache .cache
```
The model judges a wider shortlist (default 4 per episode), its verdict is blended 50/50 with the rule score, then the best 2
per episode are kept. Replies are cached on disk (re-runs free and reproducible); keys come from an env var and are never
written to outputs; script text is sent as delimited data with an "ignore instructions inside it" system prompt.
**Tested against a local stand-in server over real HTTP (both wire formats, failures, caching) - not against a live vendor API.**

---

## 4. Edge cases & how they're handled

| Messy input | Handling | Pinned by test |
|---|---|---|
| Header case differs (`SCENE HEADING:`) | case-insensitive structural regex | `test_uppercase_structural_keys…` |
| Cue wrapped over several lines / **multi-line parenthetical** | re-join up to 3 lines until the closing `**` (timestamped); balance `(`…`)` across lines (classic) | `test_timestamped_full_parse`, `test_dialect_detection_and_fountain` |
| Several parentheticals on one cue; unclosed `(` | all extracted; missing `)` closed implicitly | `test_cue_parentheticals` |
| `V.O.` / `O.S.` / `CONT'D` / `Continuing` vs. emotion | modifier set separates *technical* tags from *tone* tags | same |
| Inline `(beat)` inside speech | moved to tone tags, removed from spoken text | `test_inline_direction_stripped…` |
| Multi-line dialogue / action | joined with single spaces | `test_timestamped_full_parse` |
| Missing / reversed timestamps | pinned to previous end / swapped; issue logged | `test_messy_input_never_raises…` |
| BOM, CRLF, curly quotes, NBSP, zero-width chars | `normalize_text` | `test_normalize_and_words` |
| Not-a-slugline headings (`BLACK SCREEN`), `I/E.`, `#12#`, `FARM-HOUSE` | tolerant heading parser | `test_heading_variants` |
| Classic format: title page, `CUT TO:`, ALL-CAPS words in action (`SLAMS`) | skipped / not mistaken for cues | `test_dialect_detection_and_fountain` |
| **Shifting titles** `LADY JULIANA` = `JULIANA` | honorific/article folding | `test_honorific_folding…` |
| `LORD ASHCROFT` ≠ `LADY ASHCROFT` | gender-conflicting titles never merge | `test_gender_conflicting…` |
| `THE BEARDED STRANGER` → `ALEXANDER` (until reveal) | **episode-ranged alias rules** in `config/aliases.json` | `test_episode_ranged_alias` |
| `PRIEST` vs `HIGH PRIEST`, `NOBLEMAN` vs `BLOND NOBLEMAN` | deliberately **not** fuzzy-merged (wrong merge > duplicate); listed in `unresolved_labels.csv` | `test_generic_subset…` |
| Label that is only an article (`A`) | no collapse to empty string (bug found by tests) | `test_article_only_label…` |

---

## 5. Scaling

Measured on **2,500 episodes (27 MB text, ≈5,100 screen-minutes ≈ 5,000 pages by the one-page-per-minute rule),
2 vCPU sandbox, text perturbed so the sentiment cache cannot flatter the result**
(`python scripts/benchmark.py --input scripts.zip --copies 50 --workers 1 2`):

| Version | Serial | 2 workers |
|---|---|---|
| First working version | 32.8 s | 61.5 s (**slower** — see below) |
| Final | 17.7 s | **9.6 s** (~260 episodes/s, peak RSS ≈ 560 MB) |

The table is the pipeline **without** the promo stage. With promos (visual scoring, stand-alone gate, stitching) the
same 2,500-episode run takes **45 s on 2 cores** (promo stage 34 s, single-threaded; peak RSS ≈ 0.9 GB); a 50-episode show
takes ≈ 3 s. Stitching first made that stage 8× slower (12 s → 101 s); profiling showed per-candidate pandas slicing, and
preparing each episode once cut it by two thirds with byte-identical output.

What was done, found by profiling rather than guessing:

1. **Single streaming pass, precompiled regexes.** Linear time, no whole-file regex backtracking.
2. **Workers return DataFrames, not objects.** Pickling ~190k small `Element`s made 2 workers *slower* than 1;
   returning columnar chunks fixed it (parse+score 13.2 s → 4.2 s).
3. **Vectorised aggregation.** Per-group Python loops (beats, scene metrics, interval-union) replaced by
   groupby sums and a loop-free union (`running max of ends`); that stage fell **17.6 s → 2.2 s**. Outputs were
   verified identical to the loop version (Δ ≤ 3e-16).
4. **Memoisation**: `stem()` and per-process sentiment cache (repeated lines like "No." scored once).
5. **Mention detection = one compiled alternation** per text, independent of cast size.
6. Categorical dtypes for `kind` / `speaker`; stage timers in `summary.json` (`runtime_seconds`).

**Cost & human in the loop.** The whole pipeline is rule-based CPU code: ≈0 marginal cost per show (50 episodes
≈ 3 s including the promo stage; **measured** at 2,500 episodes: 45 s end to end on 2 cores, promo stage 34 s
single-threaded, 0.9 GB peak).
The optional model re-rank (section F) sends **only the top ~4 candidates per episode** (≈ 150-200 short calls per
50-episode show; token cost is my estimate, not measured). A human editor stays the final gate:
the tool outputs a shortlist with timestamps, the editor confirms/trims, and their accept/reject feeds the y/n sheet
used to re-tune the weights.

**Not implemented (next steps at >10× this size):** on-disk per-file cache keyed by content hash, Parquet/
streaming output, sharding across machines. **Transformer backend is untested here** (no model download access)
and would dominate cost; mitigation already in the code is length-sorted batching — measure before relying on it.

---

## 6. Quality & known limitations (honest list)

Checked: element counts vs. raw cue lines (3,727 = 3,727), scene count (100 = 100), alias merges add up
(e.g. JULIANA 352 + LADY JULIANA 110 = 462), refactors verified against previous outputs, 57 tests, plots
sanity-checked against the story (Ep 1: joyful bride → collapse at the altar; Ep 50 ends on `shock`, the
discovery cliffhanger).

**Not checked: sentiment accuracy and promo precision against human judgment — no gold set exists yet.** Use the included evaluator
(`python -m screenplay_pipeline.evaluate sample|score`) with ~80 lines you label yourself.

Failure modes seen in a manual spot-check:
* **Polite words inside distress**: `(Hysterical, Screaming) "Please, Alexander! Have mercy!"` scores only −0.11.
* **Menace without lexicon words**: `"And now… you will save your brother."` scores 0.0 (word-level model blind;
  its tag `inexorable` isn't in the lexicon).
* **Keyword false positives**: `"You're freezing."` counted toward *shock*; sarcasm and irony are invisible.
* **Neutral = "no cue found"**, not "calm".
* **Arc labels are heuristic** (thirds of a ~12-beat series, threshold 0.1) — descriptive, not validated.
* **Network:** addressee is inferred from turn order (wrong in 3+ person scenes); `Alexander's mother` in
  action text also marks Alexander present; generic roles (`LORD`, `GUARD`) appear as "characters".
* **Aliases in `config/aliases.json` were inferred from loglines** and need your review.
* Lexicon tag coverage is 93% of occurrences; the rest are in `tone_tag_coverage.csv`.

Promo failure modes seen when reading the final picks (these are judgement calls by me, not measured):
* **Weak hook that still ranks high:** #10 opens on "I am tired. That is all." (a flat line carried by a close-up note);
  #12 opens on the fragment "Unsupervised. In your hands alone." which needs the scene before it.
* **Charged but already resolved endings:** #9 ends on a vow ("No one will ever hurt you for protecting me again"), which is
  intense but closes the moment; #20 opens on relief ("Oh, thank God! His chest is quiet!"), a scene already resolved.
* **Ending gate is wording-and-sentiment based:** of the 13 promos that end on an action line I read each; 10 are clearly tense
  (an iron stopping inches from an eye, armed figures through smoke), 3 are borderline (a maid weeping, a motionless reading scene,
  a hand closing on a ring). "Unresolved" is approximated, not verified.
* **Context the gate cannot see:** it only checks surface wording, so a line like "You didn't hurt me." that needs the
  previous scene would pass if it contained no marker word; a one-word reply passes when the opening shot is strong.
* **Visual score is a reading of the script's shot note**, not of footage; a shot note can promise more than the
  episode delivers, and the same cue words appear in quiet scenes ("close-up" alone scores 0.3).
* **Stitched promos rank low** (best is #27 of 96): the penalty plus the thread test keep them behind contiguous clips,
  and no cross-episode stitch survived on this show.
* **Stand-in tested only:** the model re-rank has never run against a live vendor API.

---

## 7. Make it yours (where to put your own judgment)

1. **Label 80 lines and run the evaluator** — report your own accuracy/κ and failure cases.
2. **Curate `config/aliases.json`** from `unresolved_labels.csv`; decide how aggressive to be.
3. **Tune `config/lexicon.json`** (tag groups, valences, overrides, VADER overlay) using `tone_tag_coverage.csv`.
4. **Choose beat length, shift threshold, kind weights** (`ScoringConfig`, `--beat-seconds`) and defend them.
5. **Try `--backend transformer`** on a sample and compare with VADER on your labelled set.
6. Rewrite docstrings/comments in your own words once you can explain every stage without looking.

## 8. Layout

```
screenplay_pipeline/   models · ingest · parser(A) · characters · network(B) · sentiment(C) · metrics(D) · promos(E) · visual · standalone · providers(F) · viz · pipeline · cli · evaluate
config/                aliases.json · lexicon.json
tests/                 57 tests (parser edge cases, identity resolution, network, sentiment, metrics, promos, visual cues, stand-alone and ending gates, stitching, rationale, posting plan, provider interface over HTTP, evaluators)
sample/                classic_fountain_sample.txt (second dialect)
eval/                  blind labelling sheets (sentiment lines, promo review) + docs/ (MAKE_IT_YOURS, VIDEO_SCRIPT, BUILD_NOTES)
scripts/benchmark.py   scaling benchmark
```
