# Build notes - AI assistance (edit this in your own words before submitting)

The assignment asks which AI tools were used and one place they got it wrong. Draft facts from this build:

**Tool:** Claude generated the first implementation of all four modules; behaviour was then checked against the
real 50-episode data, and fixed where it was wrong.

**Where the first draft was wrong (all caught by running it on the data or by tests):**
1. *Scene-level arcs assumed enough scenes per episode.* The data has 100 scenes in 50 episodes (25 episodes have
   one scene), so arcs were "flat" for 38/50 episodes. Fix: 10-second beats.
2. *Stock VADER scored "venomous, wretched traitor" as exactly 0.0* and read "Please save him." (sobbing) as
   positive. Fix: domain lexicon overlay + fusion with the script's own delivery tags.
3. *Parallelism made it slower* (61 s with 2 workers vs 33 s serial) because workers returned ~190k pickled
   objects. Fix: return DataFrames per chunk (-> 9.6 s).
4. *Character resolver collapsed a label made only of an article to an empty string* (a unit test caught it).
5. *Benchmark re-ingested its own `REPORT.md`* because `.md` was an accepted input suffix.
6. *"whispering" counted as tenderness* and the final 1-second beat defined every episode's "ending"; both fixed.

7. *Promo ranker's first draft counted warm moments as "hooks"* (|sentiment| treated tenderness like a jolt) and
   ranked a clip that opens mid-sentence ("...and killing my wife afterward.") first. Found by reading the top 15
   picks; fixed with asymmetric arousal and a mid-thought penalty.

**What was NOT AI-verified:** sentiment accuracy against human judgement (no gold set yet), promo precision against editors, the alias
assumptions in `config/aliases.json`, and the transformer backend (never executed).

8. *Cross-episode stitching, first draft joined unrelated moments.* Sharing two characters was treated as "same story",
   so a clip from ep 13 got a payoff from ep 14 that had nothing to do with it (found by reading the stitched picks). Fix: joined
   segments must also share distinctive *spoken* words (a topical thread). A second false link came from action-prose words
   ("bloody, knuckles"), so only dialogue counts. Result: of 9,333 cross-episode joins that shared characters and fit 20-60 s, 38 (0.4%) now pass and none
   is selected - the capability is tested on synthetic data but the real data does not contain a coherent one.
9. *"Crackling flames" scored as an impact sound* (regex `crack\w*`); tightened. *The stand-alone gate let "That will be
   your testimony." and "Why would anyone do this?" through*; added a short-deictic rule.
10. *Optimisation:* the promo stage went 12 s -> 101 s at 2,500 episodes after stitching; profiling showed per-candidate
    pandas slicing. Prepared each episode once, per-line topic words, bounded candidates: 101 s -> 38 s, **byte-identical output**.
11. Measured (not estimated): 2,500 episodes incl. promo stage = 45 s on 2 cores, 0.9 GB peak. Weight stability: 20 random
    +/-25% weight perturbations keep 90% of the top 20 on average (worst 75%). Dropping a term keeps this share of the top 20:
    hook 30%, cliffhanger 30%, standalone 60%, drama 75% - hook and cliffhanger drive the ranking. Turning visual cues off keeps
    70% of the top 20. The opening gate removes 488 of 1,567 possible opening blocks; with it off, 31 of 96 promos would open on a
    line it rejects (one/two-word replies, "that/this" lines, conjunction openers).
12. *Provider interface tested only against a local stand-in server* (both wire formats, 500s, junk replies, cache); never
    against a live vendor API, because no key/network was available here.
13. *The cliffhanger check only looked at how intense the last line was.* A review of the ending types showed 26 of 100 promos
    ended on an action line and about 7 of those were warm or resolved ("reassuringly... fades to black", "walk hand-in-hand into the
    sunlight"), because positive sentiment and close-up cues were both counted as charge. Fix: a promo may only end on an open question,
    a cut-off line, or a *tense* (non-positive, non-warm) charged line/action/shot; 2,632 candidate endings rejected. After the fix,
    13 promos end on an action line; I read them: 10 clearly tense, 3 borderline. The share ending at the episode's own last block
    fell from 37% to 23% (bare camera holds no longer count).
14. *The "why it works" line was a list of internal signals* ("strong opening jolt; clear two-person conflict"), nothing a viewer
    would feel. Rewritten around scroll-stop and tap-through; the signals moved to their own column. *Ranking had no posting
    logic* beyond the score; added `post_order` (episode spacing), waves, and a per-promo reason.
