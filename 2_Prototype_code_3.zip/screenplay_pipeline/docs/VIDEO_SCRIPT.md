# 3-minute walkthrough - talking points (say it in your own words)

**0:00-0:20 Problem.** Editors watch every episode to pick promos by hand; new shows weekly. I built a tool that
reads the screenplay (with timestamps) and shortlists 20-60 s promos with hook, cliffhanger and a ranking.

**0:20-0:50 Run it.** Terminal: `python -m screenplay_pipeline run --input scripts.zip --output output/`.
~2 seconds for 50 episodes. Show the folder: `PROMOS.md`, `data/promos.csv`, `REPORT.md`, `figures/`.

**0:50-1:40 Output.** Open `PROMOS.md`: pick #1 - read its hook, cliffhanger, "why it works", timestamps. Open
`figures/episode_001_timeline.png`: joyful opening collapsing at the altar - this is the signal under the scoring.

**1:40-2:20 How it picks.** Parser -> per-block sentiment (word model + the script's own tone tags) -> candidate
windows -> hook (first 3 s: the words AND the script's camera/sound notes, e.g. "extreme close-up", "whip crack"),
cliffhanger, drama, stand-alone (a hard gate: no opening on "And...", "But...", an unnamed "he/she", or a line that needs
earlier events) -> rank. It can also stitch two moments (show a stitched pick in `PROMOS.md`). Endings are gated too: a promo must stop on an open or tense beat, never a settled line or a warm camera hold. All rules, so ~nothing per show;
a model re-rank is one flag (`--rerank-provider`) and any OpenAI-compatible or Anthropic model plugs in.

**2:20-2:50 Honest limits.** Show one bad pick (e.g. an opener like "This house..." or a static action as hook).
Say: no video in the input, so 'visual' means the written shot notes, not pixels; the gate removes detectable
dependencies only; cross-episode stitching is built but the sample has no coherent case; the model re-rank is tested on
a stand-in server, not a live API.

**2:40-2:50 Posting plan.** Open the Posting plan in `PROMOS.md`: wave 1 = 10 lead posts, each with a reason (its best trait, what it opens and ends on); episodes are spaced so the feed does not repeat.

**2:50-3:00 Human in the loop.** Editor confirms the shortlist; my y/n review sheet measures precision.
