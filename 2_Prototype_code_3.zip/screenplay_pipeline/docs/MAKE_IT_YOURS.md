# Make it your own - your to-do list (about 3 hours, in this order)

These are the parts Kuku grades on *your* judgment. The files are prepared; the decisions are yours.

1. **Watch/read 20 promos, fill `eval/promo_review.csv`** (y/n columns), then run
   `python -m screenplay_pipeline.evaluate promo-score --labels eval/promo_review.csv --key eval/promo_key_DO_NOT_OPEN.csv`
   -> your own precision@20 and your own list of where it picks badly (use the `why_bad` column).
2. **Label 80 lines in `eval/sentiment_to_label.csv`** (-1/0/1), run `evaluate score` -> your accuracy and kappa.
3. **Change at least three things and say why**: promo weights (`PromoConfig`), beat length, the lexicon
   (`config/lexicon.json`), alias rules (`config/aliases.json`). Re-run, compare the top 10 before/after.
4. **Rewrite `docs/BUILD_NOTES.md` and the solution doc in your own words.** Keep only claims you can defend.
5. **Know these answers cold for the interview (you will run it on a new input):**
   - What is a "beat" and why not scenes? - What does `hook_score` actually measure?
   - Why VADER + tags instead of a transformer, and what breaks? - What would you do at 1,000 shows?
   - Which promo does it get wrong, and why? - What does the human editor still do?
6. **Host it**: push the code zip to GitHub (NOT the raw-outputs zip - it contains Kuku's script text) or a Colab,
   open the link in a private window, then paste it in the form.
7. **Record the 3-minute video** from `docs/VIDEO_SCRIPT.md` in your own voice.

8. **Try the model re-rank with a free-tier key** (README section F): set an env var with your key and run with `--rerank-provider openai-compatible --rerank-base-url <endpoint> --rerank-model <model> --rerank-key-env <VAR>`. It has only been tested against a local stand-in server, so a live run is something you can honestly add to the video.
