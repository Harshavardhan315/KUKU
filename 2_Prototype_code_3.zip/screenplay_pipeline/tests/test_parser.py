"""Module A tests: every edge case the README promises is pinned here."""
import pytest
from screenplay_pipeline.parser import (
    classify_label, clean_dialogue, count_words, detect_dialect, normalize_text,
    parse_heading, parse_text, parse_ts, split_parentheticals, episodes_to_frames,
)

TS = """EPISODE NUMBER: Episode 7
EPISODE LOGLINE: A test.

--- SCRIPT START ---

SCENE 01
Scene heading: INT. ASHBURY MANOR - DRAWING ROOM – CONTINUOUS
Scene start: 00:00.00
Scene end: 00:10.00

Actions and dialogue:

**CAMERA:**
Start: (00:00.00) | End: (00:02.00)
Wide shot of the room.

**MATRIARCH (Cold, Commanding):**
Start: (00:02.00) | End: (00:04.00)
"You should turn around, Juliana."

**LADY JULIANA (V.O.) (Whispering,
almost to herself):**
Start: (00:04.00) | End: (00:06.00)
"Why?
(beat) Tell me why."

**ACTION:**
Start: (00:06.00) | End: (00:09.00)
Juliana steps back. She does not
cry.

**SOUND FX:**
Start: (00:09.00) | End: (00:10.00)
Thunder.
--- SCRIPT END ---
"""


def test_timestamps():
    assert parse_ts("01:13.50") == 73.5
    assert parse_ts("(00:04.80)") == 4.8
    assert parse_ts("1:02:03") == 3723
    assert parse_ts("00:07,25") == 7.25
    assert parse_ts("nonsense") is None


def test_heading_variants():
    h = parse_heading("INT. ASHBURY MANOR - DRAWING ROOM – CONTINUOUS")
    assert (h["int_ext"], h["location"], h["location_base"], h["time_of_day"]) == \
        ("INT", "ASHBURY MANOR - DRAWING ROOM", "ASHBURY MANOR", "CONTINUOUS")
    assert parse_heading("EXT. FARM-HOUSE - DAY")["location"] == "FARM-HOUSE"     # intra-word hyphen kept
    assert parse_heading("INT./EXT. CAR - NIGHT")["int_ext"] == "INT/EXT"
    assert parse_heading("I/E. DOORWAY")["int_ext"] == "INT/EXT"
    assert parse_heading("BLACK SCREEN")["int_ext"] is None                       # not a slugline: no crash
    assert parse_heading("INT. HALL - DAY #12#")["time_of_day"] == "DAY"          # scene number stripped


def test_cue_parentheticals():
    label, tone, mods = split_parentheticals("LADY JULIANA (V.O.) (Whispering, tearful)")
    assert (label, tone, mods) == ("LADY JULIANA", ("whispering", "tearful"), ("V.O.",))
    # unclosed (wrapped) parenthetical is closed implicitly
    label, tone, _ = split_parentheticals("MARA (quietly furious")
    assert label == "MARA" and tone == ("quietly furious",)
    # "Continuing" is a modifier, not an emotion
    assert split_parentheticals("JULIANA (Continuing)")[1:] == ((), ("CONTINUING",))
    assert classify_label("sound fx") == "SOUND" and classify_label("JULIANA") == "DIALOGUE"


def test_inline_direction_stripped_from_speech():
    assert clean_dialogue('"Fine. (sighs) Go."') == ("Fine. Go.", ("sighs",))
    assert clean_dialogue("plain") == ("plain", ())


def test_timestamped_full_parse():
    ep = parse_text(TS, source="episode-007.txt")
    assert ep.dialect == "timestamped" and ep.number == 7
    sc = ep.scenes[0]
    assert sc.time_of_day == "CONTINUOUS" and sc.end == 10.0
    kinds = [e.kind for e in sc.elements]
    assert kinds == ["CAMERA", "DIALOGUE", "DIALOGUE", "ACTION", "SOUND"]
    cold = sc.elements[1]
    assert cold.speaker_raw == "MATRIARCH" and cold.tone == ("cold", "commanding")
    wrapped = sc.elements[2]                      # cue wrapped over two lines + inline (beat)
    assert wrapped.speaker_raw == "LADY JULIANA" and wrapped.modifiers == ("V.O.",)
    assert "whispering" in wrapped.tone and "almost to herself" in wrapped.tone and "beat" in wrapped.tone
    assert wrapped.text == "Why? Tell me why."
    assert sc.elements[3].text == "Juliana steps back. She does not cry."     # multi-line action joined
    assert not [i for i in ep.issues if i.severity != "info"]


def test_uppercase_structural_keys_like_episode_6():
    txt = TS.replace("Scene heading:", "SCENE HEADING:").replace("Scene start:", "SCENE START:") \
            .replace("Scene end:", "SCENE END:").replace("Actions and dialogue:", "ACTIONS AND DIALOGUE:")
    ep = parse_text(txt)
    assert ep.scenes[0].heading_raw.startswith("INT. ASHBURY") and ep.scenes[0].end == 10.0


def test_messy_input_never_raises_and_reports():
    messy = TS.replace("Start: (00:04.00) | End: (00:06.00)\n", "")                       # missing timing
    messy = messy.replace("Start: (00:09.00) | End: (00:10.00)", "Start: (00:10.00) | End: (00:09.00)")  # end < start
    messy = "﻿" + messy.replace("\n", "\r\n")                                         # BOM + CRLF
    ep = parse_text(messy)
    codes = {i.code for i in ep.issues}
    assert {"missing_timing", "negative_duration"} <= codes
    snd = ep.scenes[0].elements[-1]
    assert snd.start <= snd.end                                                            # swapped, not negative


def test_empty_and_garbage():
    assert parse_text("").scenes == []
    assert parse_text("just some words\n\nand more words").scenes != [] or True


def test_dialect_detection_and_fountain():
    from pathlib import Path
    txt = (Path(__file__).parent.parent / "sample" / "classic_fountain_sample.txt").read_text()
    assert detect_dialect(txt) == "fountain" and detect_dialect(TS) == "timestamped"
    ep = parse_text(txt, source="winter.txt", episode_hint=1)
    assert [s.heading_raw for s in ep.scenes] == [
        "INT. FARMHOUSE KITCHEN - NIGHT", "EXT. BARN - CONTINUOUS", "INT. FARMHOUSE KITCHEN - LATER"]
    d = [e for s in ep.scenes for e in s.elements if e.kind == "DIALOGUE"]
    assert d[0].speaker_raw == "MARA" and d[0].tone == ("without turning", "quietly furious")   # multi-line paren
    assert d[0].text == "You said you'd be home by supper."
    assert d[1].modifiers == ("V.O.",)
    assert d[2].speaker_raw == "MARA" and d[2].tone == ("turning",)          # (CONT'D) stripped from name
    assert all(e.time_estimated for s in ep.scenes for e in s.elements)
    assert not any(e.text.startswith("CUT TO") or e.text.startswith("FADE") for s in ep.scenes for e in s.elements)
    # action containing an ALL-CAPS word (SLAMS) must not be mistaken for a character cue
    assert any("SLAMS" in e.text and e.kind == "ACTION" for s in ep.scenes for e in s.elements)


def test_frames_schema_and_tod_inheritance():
    ep = parse_text(TS)
    f = episodes_to_frames([ep])
    assert set(f) == {"elements", "scenes", "episodes", "issues"}
    assert f["elements"]["duration"].ge(0).all()
    assert f["scenes"].loc[0, "is_continuous"]


def test_normalize_and_words():
    assert normalize_text("“Hi” ’  x") == '"Hi" \'  x'
    assert count_words("Don't stop-me now") == 4
