"""Module B tests: identity resolution & network construction."""
from collections import Counter
import pandas as pd
from screenplay_pipeline.characters import AliasRule, CharacterResolver, MentionDetector, fold_label
from screenplay_pipeline import network


def make_resolver(labels, rules=None):
    return CharacterResolver(rules=rules or []).fit(labels)


def test_honorific_folding_picks_most_frequent_bare_form():
    r = make_resolver(["JULIANA"] * 5 + ["LADY JULIANA"] * 3 + ["THE PRIEST", "PRIEST"])
    assert r.resolve("LADY JULIANA") == "JULIANA" and r.resolve("JULIANA") == "JULIANA"
    assert r.resolve("THE PRIEST") == r.resolve("PRIEST") == "PRIEST"


def test_gender_conflicting_titles_never_merge():
    r = make_resolver(["LORD ASHCROFT"] * 3 + ["LADY ASHCROFT"] * 2)
    assert r.resolve("LORD ASHCROFT") != r.resolve("LADY ASHCROFT")


def test_article_only_label_does_not_collapse_to_empty():
    r = make_resolver(["A", "A", "A", "THE"])
    assert r.resolve("A") == "A" and r.resolve("THE") == "THE"


def test_generic_subset_labels_are_not_fuzzy_merged():
    r = make_resolver(["PRIEST", "HIGH PRIEST", "NOBLEMAN", "BLOND NOBLEMAN", "ELDER NOBLEMAN", "LORD"])
    assert r.resolve("HIGH PRIEST") == "HIGH PRIEST" and r.resolve("PRIEST") == "PRIEST"
    assert r.resolve("NOBLEMAN") == "NOBLEMAN" and r.resolve("LORD") == "LORD"


def test_episode_ranged_alias():
    rule = AliasRule("ALEXANDER", ["THE BEARDED STRANGER"], to_episode=7)
    r = make_resolver(["ALEXANDER", "THE BEARDED STRANGER"], [rule])
    assert r.resolve("THE BEARDED STRANGER", 3) == "ALEXANDER"
    assert r.resolve("THE BEARDED STRANGER", 20) != "ALEXANDER"                  # outside the range: rule off
    assert fold_label("LORD") == (frozenset({"LORD"}), None)                    # lone title = a role, kept


def test_mention_detection_longest_match_and_case():
    r = make_resolver(["JULIANA"] * 4 + ["LADY JULIANA"] * 2 + ["GERALD"] * 3)
    det = MentionDetector(r, Counter(["JULIANA"] * 4 + ["LADY JULIANA"] * 2 + ["GERALD"] * 3), min_lines=3)
    assert det.find("Lady Juliana's gloved hand trembles as Gerald turns.") == {"JULIANA", "GERALD"}
    assert det.find("the gerald statue") == set()                               # case-sensitive: no false hit


def _elements():
    rows = [  # ep1 scene0: A speaks, B answers, C is only shown in action
        dict(episode=1, scene_idx=0, order=0, kind="DIALOGUE", speaker="ANNA", n_words=3, text="x"),
        dict(episode=1, scene_idx=0, order=1, kind="DIALOGUE", speaker="BEN", n_words=3, text="x"),
        dict(episode=1, scene_idx=0, order=2, kind="DIALOGUE", speaker="ANNA", n_words=3, text="x"),
        dict(episode=1, scene_idx=0, order=3, kind="ACTION", speaker=None, n_words=3, text="Cara watches."),
        dict(episode=1, scene_idx=1, order=4, kind="DIALOGUE", speaker="ANNA", n_words=3, text="x"),
    ]
    return pd.DataFrame(rows)


def test_presence_edges_exchanges():
    el = _elements()
    r = make_resolver(["ANNA"] * 3 + ["BEN"] * 3 + ["CARA"] * 3)
    det = MentionDetector(r, Counter({"ANNA": 3, "BEN": 3, "CARA": 3}), min_lines=3)
    pres = network.build_presence(el, det)
    scene0 = pres[pres.scene_idx == 0].set_index("character")
    assert scene0.loc["CARA", "role"] == "mentioned" and scene0.loc["ANNA", "n_lines"] == 2
    by_ep, series = network.build_edges(pres)
    ab = series[(series.a == "ANNA") & (series.b == "BEN")].iloc[0]
    assert ab.scenes_together == 1 and ab.scenes_both_speak == 1
    ac = series[(series.a == "ANNA") & (series.b == "CARA")].iloc[0]
    assert ac.scenes_together == 1 and ac.scenes_both_speak == 0
    ex = network.dialogue_exchanges(el).set_index(["src", "dst"])["exchanges"]
    assert ex[("ANNA", "BEN")] == 1 and ex[("BEN", "ANNA")] == 1                          # scene boundary not crossed
    G = network.build_graph(series)
    assert network.centrality_table(G).shape[0] == 3
