import pandas as pd
from screenplay_pipeline.promos import PromoConfig, find_promos, _open_end, _arousal


def _fake():
    rows, t = [], 0.0
    def add(kind, spk, text, sent, emo, dur=4.0):
        nonlocal t
        rows.append(dict(episode=1, order=len(rows), kind=kind, speaker=spk, text=text, sent=sent, emotion=emo,
                         tone="furious" if spk else "", start=t, end=t + dur)); t += dur
    add("ACTION", None, "Rain falls on the courtyard.", 0.0, None)
    add("DIALOGUE", "ANNA", "You lied to me! The secret is out!", -0.8, "anger")
    for k in range(10):
        add("DIALOGUE", "BEN" if k % 2 else "ANNA", f"Line number {k} about what happened.", -0.3, "contempt")
    add("DIALOGUE", "BEN", "Then who is the father?", -0.5, "shock")
    return pd.DataFrame(rows)


def test_open_end_and_arousal():
    assert _open_end("Who is it?") == 1.0 and _open_end("Fine.") == 0.0 and _open_end("Stop!") == 0.5
    assert _arousal("The secret!", -0.6, "anger") > _arousal("Hello.", 0.0, None)


def test_promos_respect_duration_overlap_and_hook():
    el = _fake()
    eps = pd.DataFrame({"episode": [1], "continuity": ["First episode of the series."]})
    p = find_promos(el, eps, PromoConfig(max_per_episode=2))
    assert len(p) >= 1 and p["duration_s"].between(20, 60).all()
    assert list(p["rank"]) == sorted(p["rank"]) and p["score"].is_monotonic_decreasing
    best = p.iloc[0]
    assert "secret" in best["hook"] or "lied" in best["hook"]          # opens on the jolt, not the rain
    assert best["segment_end"] <= el["end"].max() + 1e-9
    if len(p) > 1:
        a, b = p.iloc[0], p.iloc[1]
        overlap = min(a.segment_end, b.segment_end) - max(a.segment_start, b.segment_start)
        assert overlap <= 0.3 * min(a.duration_s, b.duration_s) + 1e-9


def test_promo_review_roundtrip():
    from screenplay_pipeline import evaluate as ev
    p = pd.DataFrame({"rank": range(1, 41), "episode": 1, "start_ts": "00:00.0", "end_ts": "00:30.0", "duration_s": 30.0,
                      "hook": "h", "cliffhanger": "c", "score": 0.5})
    sheet, key = ev.promo_sheet(p, k=20, n_low=10)
    assert len(sheet) == 30 and "rank" not in sheet.columns and "score" not in sheet.columns
    m = sheet.merge(key, on="clip_id")
    sheet["would_post"] = ["y" if r <= 20 else "n" for r in m["rank"]]
    out = ev.promo_precision(sheet, key)
    assert out["precision_top20"] == 1.0 and out["precision_lower_ranked"] == 0.0
