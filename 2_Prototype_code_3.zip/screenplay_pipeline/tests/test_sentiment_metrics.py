"""Module C/D tests."""
import numpy as np
import pandas as pd
import pytest
from screenplay_pipeline import metrics, sentiment
from screenplay_pipeline.parser import parse_text, episodes_to_frames
from screenplay_pipeline.sentiment import Lexicon, ScoringConfig, VaderBackend, classify_arc, stem
from tests.test_parser import TS


@pytest.fixture(scope="module")
def lex():
    return Lexicon.load()


@pytest.fixture(scope="module")
def backend(lex):
    return VaderBackend(lex)


def test_stemming_unifies_inflections():
    assert stem("sobbing") == stem("sobs") == stem("sobbed") == "sob"


def test_tone_lookup(lex):
    assert lex.lookup_tone("Sobbing")[1] == "sadness" and lex.lookup_tone("sobbing")[0] < 0
    assert lex.lookup_tone("mocking, spiteful")[1] == "contempt"      # multi-word falls back to each word
    assert lex.lookup_tone("whispering")[1] == "neutral"              # delivery, not emotion
    assert lex.lookup_tone("zzzzz") is None


def test_domain_overlay_fixes_vader_blind_spot(backend):
    assert backend.score(["You venomous, wretched traitor."])[0] < -0.5   # stock VADER gives exactly 0.0


def test_tone_tag_corrects_misleading_wording(backend, lex):
    """'Please save him.' reads positive to a word-level model; the (Sobbing) tag must win."""
    ep = parse_text(TS.replace("(Cold, Commanding)", "(Sobbing)").replace("You should turn around, Juliana.", "Please save him."))
    sentiment.score_episode(ep, backend, lex)
    e = ep.scenes[0].elements[1]
    assert e.sent_tone < 0 and e.sent < e.sent_text and e.emotion == "sadness"


def test_arc_classifier():
    assert classify_arc([0, 0, 0, 0, 0, 0]) == "flat"
    assert classify_arc([-.4, -.4, 0, 0, .4, .4]) == "rise"
    assert classify_arc([.4, .4, 0, 0, -.4, -.4]) == "fall"
    assert classify_arc([.3, .3, -.5, -.5, .3, .3]) == "man-in-a-hole"
    assert classify_arc([-.3, -.3, .5, .5, -.3, -.3]) == "icarus"
    assert classify_arc([0.1]) == "flat"


def test_union_length_does_not_double_count():
    assert metrics.union_length(np.array([0.0, 1.0, 5.0]), np.array([3.0, 2.0, 6.0])) == 4.0
    assert metrics.union_length(np.array([]), np.array([])) == 0.0


def test_end_to_end_metrics(backend, lex):
    ep = sentiment.score_episode(parse_text(TS), backend, lex)
    f = episodes_to_frames([ep])
    el = f["elements"].assign(speaker=lambda d: d["speaker_raw"].astype(object))
    sc = sentiment.analyze_scenes(el, f["scenes"])
    sm = metrics.scene_metrics(el, sc).iloc[0]
    assert sm["n_camera"] == 1 and sm["n_dialogue"] == 2 and sm["n_sound"] == 1
    assert sm["dialogue_words"] == 5 + 4                         # "You should turn around, Juliana." + "Why? Tell me why."
    assert sm["shots_per_min"] == pytest.approx(1 / (10 / 60))
    assert 0 < sm["dialogue_time_share"] <= 1
    beats = sentiment.build_beats(el, f["scenes"], beat_seconds=5)
    assert len(beats) == 2 and beats["rel_pos"].iloc[-1] == 1.0


def test_evaluator_roundtrip():
    from screenplay_pipeline import evaluate as ev
    el = pd.DataFrame({"kind": ["DIALOGUE"] * 6, "n_words": [4] * 6, "episode": 1, "scene_idx": 0, "speaker": "X",
                       "tone": "", "text": list("abcdef"), "sent": [-.6, -.5, 0.0, .1, .7, .5], "emotion": None})
    s = ev.draw_sample(el, n=12)      # 6 per kind; only DIALOGUE present here
    assert {"row_id", "label"} <= set(s.columns) and "sent" not in s.columns     # model score withheld
    s["label"] = [-1, -1, 0, 0, 1, -1]                                           # last one deliberately wrong
    r = ev.evaluate(s, el)
    assert r["n_labelled"] == 6 and r["accuracy"] == pytest.approx(5 / 6) and r["kappa"] > 0.6
