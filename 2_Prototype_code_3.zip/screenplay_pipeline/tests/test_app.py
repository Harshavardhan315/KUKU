"""Smoke test for the Streamlit prototype (runs the real pipeline on the demo show)."""
from pathlib import Path

import pytest

pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest

APP = str(Path(__file__).resolve().parents[1] / "app.py")


def test_app_runs_demo_and_shows_posting_plan():
    at = AppTest.from_file(APP, default_timeout=120).run()
    assert not at.exception
    at.button[0].click().run()
    assert not at.exception and not at.error
    metrics = {m.label: m.value for m in at.metric}
    assert metrics["Episodes"] == "3" and int(metrics["Promos found"]) >= 1
    assert len(at.dataframe) == 1                     # the posting plan table


def test_app_upload_mode_without_file_gives_friendly_error():
    at = AppTest.from_file(APP, default_timeout=120).run()
    at.radio[0].set_value("Upload my own").run()
    at.button[0].click().run()
    assert not at.exception
    assert any("Upload at least one" in e.value for e in at.error)
