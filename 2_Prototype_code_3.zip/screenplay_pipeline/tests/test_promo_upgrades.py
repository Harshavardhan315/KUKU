"""Tests for the promo upgrades: visual cues, strict stand-alone gate, stitching, provider interface."""
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pandas as pd
import pytest

from screenplay_pipeline import providers as pv
from screenplay_pipeline.promos import PromoConfig, find_promos, promo_transcript
from screenplay_pipeline.standalone import check_opening, name_tokens
from screenplay_pipeline.visual import add_visual_columns, score_note


# ------------------------------------------------------------------ helpers
class Ep:
    """Tiny builder for one synthetic episode (CAMERA/SOUND run in parallel with the dialogue)."""
    def __init__(self, ep=1):
        self.ep, self.rows, self.t = ep, [], 0.0

    def line(self, spk, text, sent=-0.3, emo="contempt", dur=4.0, cam=None, snd=None):
        r = dict(episode=self.ep, order=len(self.rows), kind="DIALOGUE", speaker=spk, text=text, sent=sent, emotion=emo,
                 tone="", start=self.t, end=self.t + dur, scene_idx=0)
        if cam:
            self.rows.append({**r, "kind": "CAMERA", "speaker": None, "text": cam, "sent": 0.0, "emotion": None})
            r["order"] = len(self.rows)
        self.rows.append(r)
        if snd:
            self.rows.append({**r, "order": len(self.rows), "kind": "SOUND", "speaker": None, "text": snd, "sent": 0.0, "emotion": None})
        self.t += dur
        return self

    def calm(self, n, spk="ANNA"):
        for k in range(n):
            w1, w2 = "qz" + chr(97 + k) + "xv" + chr(97 + k), "kj" + chr(97 + k) + "wp" + chr(65 + k).lower() * 2   # unique, non-repeating filler
            self.line(spk if k % 2 else "BEN", f"Oh, {w1}, {w2}, {w1}{w2}.", 0.0, None)
        return self

    def df(self):
        d = pd.DataFrame(self.rows)
        d["order"] = range(len(d))
        return d


def eps_df(*nums, cont="First episode."):
    return pd.DataFrame({"episode": list(nums), "continuity": [cont] * len(nums)})


# ------------------------------------------------------------------ (1) visual cues
def test_visual_score_orders_cues_sensibly():
    slap, _ = score_note("A sharp slap lands as the camera whip-pans to her stunned face.", "CAMERA")
    close, _ = score_note("Close-up on Anna.", "CAMERA")
    plain, _ = score_note("Wide shot of the garden.", "CAMERA")
    boom, tags = score_note("Ear-splitting explosion and terrified screams.", "SOUND")
    creak, _ = score_note("A door creaks.", "SOUND")
    ember, _ = score_note("Crackling flames and wood popping in the fireplace.", "SOUND")
    assert boom > 0.8 and slap > 0.7 > close > plain == 0.0
    assert creak < 0.2 and ember == 0.0 and "shock sound" in tags
    assert 0.0 <= max(slap, boom) <= 1.0


def test_visual_hook_lifts_a_promo_with_identical_dialogue():
    def build(cam):
        e = Ep()
        e.line("ANNA", "I know what you did last winter.", -0.3, None, cam=cam)
        for k in range(10):
            e.line("BEN" if k % 2 else "ANNA", f"We must settle the ledger matter number {k} tonight.", -0.2, None)
        e.line("BEN", "Who told them where to look?", -0.6, "fear")
        return e.df()
    quiet = find_promos(build("Wide shot of the garden."), eps_df(1))
    loud = find_promos(build("Extreme close-up as Anna slaps Ben, his face whipping aside."), eps_df(1))
    assert loud.iloc[0]["hook_visual_score"] > quiet.iloc[0]["hook_visual_score"] + 0.5
    assert loud.iloc[0]["hook_score"] > quiet.iloc[0]["hook_score"]
    assert "slap" in loud.iloc[0]["visual_hook"].lower() or "strike" in loud.iloc[0]["visual_hook"].lower()


# ------------------------------------------------------------------ (3) strict stand-alone gate
@pytest.mark.parametrize("opener,why", [
    (["And that is why we are here."], "dangling_conjunction"),
    (["But you promised me!"], "dangling_conjunction"),
    (["...and then he left."], "mid_thought"),
    (["he never told me."], "mid_thought"),
    (["She took it from him."], "unresolved_pronoun"),
    (["Who?"], "fragment_reply"),
    (["That will be your testimony."], "deictic_reference"),
    (["Why would anyone do this?"], "deictic_reference"),
    (["As I said, last time was the end."], "back_reference"),
])
def test_gate_rejects_dependent_openers(opener, why):
    v = check_opening(opener, "", {"anna"})
    assert not v.ok and why in v.reasons


def test_gate_accepts_clean_openers_and_visual_exceptions():
    assert check_opening(["You poisoned my father!"], "", set()).ok
    assert check_opening(["She took it."], "Close-up on Anna, hands shaking.", {"anna"}).ok       # antecedent in the shot note
    assert check_opening(["Who?"], "", set(), strong_visual=True).ok                                # shot carries the hook
    assert name_tokens(["ALEXANDER'S MOTHER"]) == {"alexander", "mother"}


def test_no_promo_opens_on_a_dangling_line_and_stats_are_reported():
    e = Ep()
    e.line("ANNA", "And that is exactly what I told you!", -0.9, "anger")       # strongest block, but dangling
    e.line("BEN", "You never listened to a word of it.", -0.5, "anger")
    for k in range(10):
        e.line("ANNA" if k % 2 else "BEN", f"Matter {k} of the estate is settled now, said the clerk.", -0.2, None)
    e.line("BEN", "Who gave them the key?", -0.6, "fear")
    p = find_promos(e.df(), eps_df(1))
    assert len(p) >= 1
    assert not p["opening_line"].str.lower().str.startswith(("and ", "but ", "so ", "then ")).any()
    assert p.attrs["filter_stats"]["dangling_conjunction"] >= 1


# ------------------------------------------------------------------ (2) multi-segment stitching
def _split_episode(ep=1):
    """Hook up front, 100 s of nothing, payoff at the end: no single 60 s clip can hold both."""
    e = Ep(ep)
    e.line("ANNA", "You poisoned the duchess with arsenic!", -0.9, "anger", cam="Extreme close-up of Anna, trembling with fury.")
    e.line("BEN", "The arsenic ledger proves nothing, Anna.", -0.6, "contempt", dur=5.0)
    e.calm(25)
    e.line("ANNA", "Then read the arsenic ledger aloud, Ben, and watch them all arrive.", -0.7, "anger")
    e.line("BEN", "Who told them to come?", -0.6, "fear", dur=5.0)
    return e


def test_stitched_promo_spans_non_contiguous_moments_in_order():
    p = find_promos(_split_episode().df(), eps_df(1), PromoConfig(max_per_episode=3))
    st = p[p["kind"] == "stitched-in-episode"]
    assert len(st) >= 1
    r = st.iloc[0]
    segs = json.loads(r["segments_json"])
    assert r["n_segments"] == 2 and len(segs) == 2
    assert segs[0]["end"] + 1.5 <= segs[1]["start"]                     # non-contiguous, in order
    assert 20 <= r["duration_s"] <= 60
    assert abs(sum(s["end"] - s["start"] for s in segs) - r["duration_s"]) < 0.2
    assert " | " in r["timestamps"] and "arsenic" in r["signals"]       # the shared thread is named
    assert find_promos(_split_episode().df(), eps_df(1), PromoConfig(stitch=False))["n_segments"].eq(1).all()


def test_stitching_needs_a_shared_thread_not_just_shared_characters():
    e = Ep()
    e.line("ANNA", "You poisoned the duchess with arsenic!", -0.9, "anger")
    e.line("BEN", "Nothing was ever proven, Anna.", -0.6, "contempt", dur=5.0)
    e.calm(25)
    e.line("ANNA", "Dinner will be served shortly, Ben, hurry!", -0.7, "anger")
    e.line("BEN", "Who is coming?", -0.6, "fear", dur=5.0)
    p = find_promos(e.df(), eps_df(1), PromoConfig(max_per_episode=5))
    assert not (p["n_segments"] > 1).any()


def test_cross_episode_stitch_and_switch_off():
    a = Ep(1)
    a.line("ANNA", "You poisoned the duchess with arsenic and hid the ledger!", -0.9, "anger", cam="Tight insert on a shaking hand.")
    a.line("BEN", "Nobody will ever find the ledger, Anna.", -0.6, "contempt", dur=5.0)
    a.calm(25)
    b = Ep(2)
    b.calm(25)
    b.line("ANNA", "The arsenic ledger is in the abbey, Ben, and the bishop reads it tonight.", -0.8, "anger")
    b.line("BEN", "Who told the bishop?", -0.6, "fear", dur=5.0)
    el = pd.concat([a.df(), b.df()], ignore_index=True)
    p = find_promos(el, eps_df(1, 2), PromoConfig(max_per_episode=4, cross_span=1))
    cx = p[p["kind"] == "stitched-cross-episode"]
    assert len(cx) >= 1 and cx.iloc[0]["episodes"] == "1+2"
    segs = json.loads(cx.iloc[0]["segments_json"])
    assert [s["episode"] for s in segs] == [1, 2]
    assert not (find_promos(el, eps_df(1, 2), PromoConfig(max_per_episode=4, cross_episode=False))["kind"]
                == "stitched-cross-episode").any()


# ------------------------------------------------------------------ (4) provider interface
class _Fake(BaseHTTPRequestHandler):
    mode = "openai"
    calls = 0

    def log_message(self, *a):
        pass

    def do_POST(self):
        type(self).calls += 1
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if type(self).mode == "500":
            self.send_response(500); self.end_headers(); return
        user = body["messages"][-1]["content"]
        good = "poison" in user
        verdict = json.dumps({"hook": 0.9 if good else 0.1, "cliffhanger": 0.9 if good else 0.1, "standalone": 0.9,
                              "rationale": "fake model"})
        text = "Sure! " + verdict if type(self).mode == "openai" else verdict
        if self.path.endswith("/chat/completions"):
            reply = {"choices": [{"message": {"content": text}}]}
            assert self.headers["Authorization"] == "Bearer secret-key"
        else:
            reply = {"content": [{"type": "text", "text": text}]}
            assert self.headers["x-api-key"] == "secret-key" and body["system"]
        data = json.dumps(reply).encode()
        self.send_response(200); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)


@pytest.fixture()
def server():
    srv = HTTPServer(("127.0.0.1", 0), _Fake)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    _Fake.mode, _Fake.calls = "openai", 0
    yield f"http://127.0.0.1:{srv.server_port}"
    srv.shutdown()


def _promos_and_elements():
    e = _split_episode()
    el = e.df()
    p = find_promos(el, eps_df(1), PromoConfig(max_per_episode=4))
    return p, el


def test_openai_compatible_and_anthropic_providers_rerank_over_http(server, monkeypatch):
    monkeypatch.setenv("FAKEKEY", "secret-key")
    p, el = _promos_and_elements()
    for name, base in (("openai-compatible", server + "/v1"), ("anthropic", server)):
        prov = pv.make_provider(name, model="any-model", base_url=base, api_key_env="FAKEKEY", retries=0)
        out = pv.rerank_promos(p, el, prov, blend=0.5, keep_per_episode=2)
        assert 1 <= len(out) <= 2 and out["rank"].tolist() == list(range(1, len(out) + 1)) and out["score"].is_monotonic_decreasing
        assert out["llm_hook"].notna().all() and (out["llm_rationale"] == "fake model").all()
        assert out.attrs["provider"] == name and out.attrs["judged"] == len(p)
        mixed = (0.5 * out["rule_score"] + 0.5 * (0.35 * out["llm_hook"] + 0.35 * out["llm_cliffhanger"] + 0.3 * out["llm_standalone"])).round(3)
        assert (out["score"] - mixed).abs().max() < 1e-9


def test_provider_failure_falls_back_to_rule_scores(server, monkeypatch):
    monkeypatch.setenv("FAKEKEY", "secret-key")
    _Fake.mode = "500"
    p, el = _promos_and_elements()
    prov = pv.make_provider("openai-compatible", model="m", base_url=server + "/v1", api_key_env="FAKEKEY", retries=0)
    out = pv.rerank_promos(p, el, prov, keep_per_episode=2)
    assert out.attrs["judged"] == 0 and out.attrs["provider_errors"] == len(p)
    assert out["llm_hook"].isna().all()
    assert out["score"].tolist() == out["rule_score"].tolist()                  # ranking unchanged by the failure


def test_reply_cache_makes_reruns_free(server, monkeypatch, tmp_path):
    monkeypatch.setenv("FAKEKEY", "secret-key")
    p, el = _promos_and_elements()
    kw = dict(model="m", base_url=server + "/v1", api_key_env="FAKEKEY", retries=0, cache_dir=str(tmp_path))
    pv.rerank_promos(p, el, pv.make_provider("openai-compatible", **kw))
    first = _Fake.calls
    pv.rerank_promos(p, el, pv.make_provider("openai-compatible", **kw))
    assert first == len(p) and _Fake.calls == first


def test_parse_verdict_is_defensive():
    assert pv.parse_verdict("no json here") is None
    assert pv.parse_verdict('{"hook": "high"}') is None
    v = pv.parse_verdict('prefix {"hook": 7, "cliffhanger": -2, "standalone": 0.5, "rationale": "x"} suffix')
    assert (v.hook, v.cliffhanger, v.standalone) == (1.0, 0.0, 0.5)


def test_custom_provider_registers_and_rules_means_none():
    class Always:
        name = "always"
        def __init__(self, **_): pass
        def judge(self, clips):
            return [pv.ClipVerdict(1, 1, 1, "x") for _ in clips]
    pv.register_provider("always", Always)
    assert pv.make_provider("rules") is None and pv.make_provider(None) is None
    p, el = _promos_and_elements()
    out = pv.rerank_promos(p, el, pv.make_provider("always"), blend=1.0, keep_per_episode=1)
    assert len(out) == 1 and out.iloc[0]["score"] == 1.0
    with pytest.raises(ValueError):
        pv.make_provider("nope")


def test_clipview_carries_transcript_and_shot_notes_for_multimodal_use():
    p, el = _promos_and_elements()
    talk, notes = promo_transcript(p.iloc[0], el)
    assert "[segment 1" in talk and "ANNA" in talk
    assert any(w in notes for w in ("CAMERA", "SOUND")) or "[segment 1" in notes


# ------------------------------------------------------------------ Q3: ending gate
def test_neutral_endings_are_rejected_and_every_promo_has_an_end_type():
    from screenplay_pipeline.promos import _ending
    assert _ending("Who is it?", "DIALOGUE", 0.1, 0.0, 0.0, 0.45) == "open question"
    assert _ending("I will never...", "DIALOGUE", 0.0, 0.0, 0.0, 0.45) == "cut-off line"
    assert _ending("Thank you, that is all.", "DIALOGUE", 0.1, 0.0, 0.0, 0.45) is None          # resolved, neutral
    assert _ending("The lamp burns low on the table.", "ACTION", 0.1, 0.0, 0.0, 0.45) is None   # scene-setting stage direction
    assert _ending("Anna falls to her knees, sobbing.", "ACTION", 0.7, 0.6, 0.0, 0.45) == "charged action"
    assert _ending("It is done.", "DIALOGUE", 0.1, 0.0, 0.8, 0.45) == "charged shot"
    # warm / resolved beats leave nothing hanging, however strongly they are shot
    assert _ending("Alexander squeezes Juliana's hands reassuringly as the scene fades to black.", "ACTION", 0.6, 0.6, 0.7, 0.45, 0.4) is None
    assert _ending("They walk hand-in-hand into the sunlight.", "ACTION", 0.6, 0.5, 0.7, 0.45, 0.0) is None
    assert _ending("You are my whole world!", "DIALOGUE", 0.5, 0.0, 0.0, 0.45, 0.6) is None
    e = Ep()
    e.line("ANNA", "You poisoned the duchess with arsenic!", -0.9, "anger")
    for k in range(10):
        e.line("BEN" if k % 2 else "ANNA", f"Matter {k} of the estate is settled now, said the clerk.", -0.2, None)
    quiet = find_promos(e.df(), eps_df(1))                                                       # ends on a bland, resolved line
    assert quiet.empty or quiet.attrs["filter_stats"]["ending_neutral"] > 0
    e.line("BEN", "Who told the bishop?", -0.6, "fear")
    p = find_promos(e.df(), eps_df(1))
    assert len(p) >= 1 and set(p["end_type"]) <= {"open question", "cut-off line", "charged line", "charged action", "charged shot"}
    assert "unanswered question" in p.iloc[0]["cliffhanger"] or p.iloc[0]["end_type"] != "open question"


# ------------------------------------------------------------------ Q4: viewer-retention rationale
def test_why_it_works_is_one_viewer_facing_line_and_signals_are_kept_apart():
    p = find_promos(_split_episode().df(), eps_df(1), PromoConfig(max_per_episode=3))
    for r in p.itertuples():
        assert "\n" not in r.why_it_works and r.why_it_works.endswith(".") and len(r.why_it_works) < 330
        assert "scroller stops" in r.why_it_works and ("viewers" in r.why_it_works)             # scrolling + retention wording
        assert r.signals and r.signals != r.why_it_works                                         # mechanical audit trail is separate
    assert p.iloc[0]["hook_kind"]


# ------------------------------------------------------------------ Q5: posting plan
def test_posting_plan_orders_waves_and_spaces_same_episode():
    from screenplay_pipeline.promos import plan_posting
    n = 50
    p = pd.DataFrame({"rank": range(1, n + 1), "episode": [1, 1, 1, 2, 2, 3] + list(range(4, n - 2)),
                      "score": [1 - i / 100 for i in range(n)], "hook_score": 0.5, "cliffhanger_score": 0.5, "drama_score": 0.5,
                      "standalone_score": 0.5, "end_type": "open question", "hook_kind": "an open confrontation"})
    p.loc[0, "hook_score"] = 0.95                                                                 # promo 1 stands out on hooking power
    q = plan_posting(p, PromoConfig(wave_sizes=(10, 30), spacing=2))
    assert sorted(q["post_order"]) == list(range(1, n + 1)) and q["wave"].tolist().count(1) == 10 and q["wave"].tolist().count(2) == 30
    seq = q.sort_values("post_order")["episode"].tolist()
    assert all(seq[i] not in seq[max(0, i - 2):i] for i in range(len(seq)) if seq.count(seq[i]) <= 3 and i < 12)   # spaced where possible
    top = q.sort_values("post_order").iloc[0]
    assert top["rank"] == 1 and top["post_reason"].startswith("Lead wave") and "highest hooking power" in top["post_reason"]
    assert any("Held back" in r for r in q["post_reason"])                                        # a pushed-back promo says so
    assert q.sort_values("post_order")["wave"].is_monotonic_increasing


def test_report_has_plan_and_end_gate_lines(tmp_path):
    from screenplay_pipeline.promos import write_promo_report
    p = find_promos(_split_episode().df(), eps_df(1), PromoConfig(max_per_episode=3))
    f = tmp_path / "PROMOS.md"
    write_promo_report(f, p)
    t = f.read_text()
    assert "## Posting plan" in t and "Wave 1" in t and "Ending gate" in t and "Why post here" in t
