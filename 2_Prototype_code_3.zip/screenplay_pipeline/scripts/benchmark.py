"""Scaling benchmark: replicate a corpus N times (with perturbed text so the sentiment
cache cannot inflate throughput) and time the full pipeline serial vs parallel.

    python scripts/benchmark.py --input scripts.zip --copies 50 --workers 1 2
"""
import argparse, re, resource, shutil, sys, tempfile, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from screenplay_pipeline.ingest import iter_sources
from screenplay_pipeline.pipeline import PipelineConfig, run_pipeline

STRUCT = re.compile(r"^(\*\*|Start:|SCENE|Scene|EPISODE|CONTINUITY|---|Actions|ACTIONS)", re.I)


def perturb(text: str, k: int) -> str:
    out = []
    for line in text.split("\n"):
        if line.strip() and not STRUCT.match(line):
            line = line[:-1] + f" zq{k}\"" if line.endswith('"') else line + f" zq{k}"
        out.append(line)
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True); ap.add_argument("--copies", type=int, default=50)
    ap.add_argument("--workers", type=int, nargs="+", default=[1, 2])
    a = ap.parse_args()
    base = list(iter_sources(a.input))
    tmp = Path(tempfile.mkdtemp(prefix="bench_"))
    n = 0
    for k in range(a.copies):
        for name, raw in base:
            n += 1
            (tmp / f"episode-{n:05d}.txt").write_text(perturb(raw.decode("utf-8-sig"), k), encoding="utf-8")
    mb = sum(f.stat().st_size for f in tmp.iterdir()) / 1e6
    print(f"{n} episodes, {mb:.1f} MB of script text")
    for w in a.workers:
        t = time.perf_counter()
        res = run_pipeline(PipelineConfig(input_path=str(tmp), output_dir=str(Path(tempfile.gettempdir()) / f"bench_out_w{w}"),
                                          workers=w, make_figures=False))
        dt = time.perf_counter() - t
        s = res["summary"]
        print(f"workers={w}: {dt:6.1f}s total | stages {s['runtime_seconds']} | "
              f"{n/dt:6.1f} episodes/s | {s['total_runtime_min']:.0f} screen-min | "
              f"peak RSS {resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024:.0f} MB")
    shutil.rmtree(tmp)


if __name__ == "__main__":
    main()
