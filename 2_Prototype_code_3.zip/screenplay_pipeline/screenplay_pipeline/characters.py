"""Character identity resolution ("shifting character titles").

Screenplays refer to one person under many labels: ``JULIANA``, ``LADY JULIANA``,
and - before her name is revealed - ``LADY IN GOLD GOWN``.  Resolution is layered
from safest to riskiest, and every decision is inspectable:

1. **Alias file** (``config/aliases.json``) - human-curated, optionally limited
   to an episode range (``"THE BEARDED STRANGER"`` is Alexander only until his
   name is revealed).  Highest priority; this is where *your* knowledge of the
   show goes.
2. **Honorific / article folding** - labels that differ only by a title
   (``LADY JULIANA`` == ``JULIANA``, ``THE PRIEST`` == ``PRIEST``) are merged.
   Gender-conflicting titles are *never* merged (``LORD ASHCROFT`` !=
   ``LADY ASHCROFT``).
3. **Everything else stays separate** and is listed in ``unresolved_labels.csv``
   so a human can add alias rules.  Fuzzy/subset merging (``PRIEST`` into
   ``HIGH PRIEST``) was deliberately rejected: on the sample data it silently
   fuses different people, and a wrong merge is worse than a duplicate node.
"""
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

ARTICLES = {"THE", "A", "AN"}
TITLES_M = {"LORD", "SIR", "MR", "MASTER", "DUKE", "KING", "PRINCE", "FATHER", "COUNT", "BARON"}
TITLES_F = {"LADY", "DAME", "MRS", "MISS", "MADAM", "DUCHESS", "QUEEN", "PRINCESS", "COUNTESS", "BARONESS"}


def _tokens(label: str) -> list[str]:
    return re.sub(r"[^A-Z0-9' -]", " ", label.upper()).split()


def fold_label(label: str) -> tuple[frozenset, Optional[str]]:
    """Return ``(core tokens, gender)`` for *label* after removing articles and titles.

    ``'LADY JULIANA' -> ({'JULIANA'}, 'F')``;  ``'LORD' -> ({'LORD'}, None)`` (a title
    that is the *whole* label is a role name, not an honorific, so it is kept).
    """
    toks = [t for t in _tokens(label) if t not in ARTICLES] or _tokens(label)
    core = [t for t in toks if t not in TITLES_M | TITLES_F]
    if not core:                                    # label is only a title -> keep as role
        return frozenset(toks), None
    genders = {"M" for t in toks if t in TITLES_M} | {"F" for t in toks if t in TITLES_F}
    return frozenset(core), (next(iter(genders)) if len(genders) == 1 else None)


@dataclass
class AliasRule:
    canonical: str
    aliases: list
    from_episode: Optional[int] = None
    to_episode: Optional[int] = None
    note: str = ""

    def applies(self, episode: Optional[int]) -> bool:
        if episode is None:
            return True
        if self.from_episode is not None and episode < self.from_episode:
            return False
        return not (self.to_episode is not None and episode > self.to_episode)


def load_alias_rules(path: Optional[str | Path]) -> list[AliasRule]:
    """Load alias rules from JSON: ``{"rules": [{"canonical": ..., "aliases": [...], ...}]}``."""
    if not path or not Path(path).exists():
        return []
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return [AliasRule(canonical=r["canonical"].upper(),
                      aliases=[a.upper() for a in r["aliases"]],
                      from_episode=r.get("from_episode"), to_episode=r.get("to_episode"),
                      note=r.get("note", "")) for r in data.get("rules", [])]


@dataclass
class CharacterResolver:
    """Maps raw speaker labels to canonical character names.

    Call :meth:`fit` once on all labels (it needs corpus frequencies to choose
    the most common spelling as canonical), then :meth:`resolve` per label.
    """

    rules: list = field(default_factory=list)
    _auto: dict = field(default_factory=dict)       # raw label -> canonical (rule 2)
    _freq: Counter = field(default_factory=Counter)

    def fit(self, labels: Iterable[str]) -> "CharacterResolver":
        self._freq = Counter(l.upper() for l in labels if l)
        groups: dict[frozenset, dict[Optional[str], list]] = defaultdict(lambda: defaultdict(list))
        for lab in self._freq:
            core, gender = fold_label(lab)
            groups[core][gender].append(lab)
        for core, by_gender in groups.items():
            genders = [g for g in by_gender if g is not None]
            for gender, labs in by_gender.items():
                # a bare (gender-less) label folds into the single gendered family
                # if there is exactly one; with M *and* F present it stays apart.
                bucket = list(labs)
                if gender is None and len(genders) == 1:
                    continue
                if gender is not None and len(genders) == 1 and None in by_gender:
                    bucket += by_gender[None]
                canon = self._pick_canonical(bucket)
                for lab in bucket:
                    self._auto[lab] = canon
        return self

    def _pick_canonical(self, labels: list) -> str:
        best = max(labels, key=lambda l: (self._freq[l], -len(l)))
        toks = [t for t in _tokens(best) if t not in ARTICLES] or _tokens(best)
        # drop the title only when a bare spelling exists in the group (JULIANA + LADY JULIANA
        # -> JULIANA); a title-only family keeps it ("LORD ASHCROFT") so M/F namesakes stay distinct.
        has_bare = any(not (set(_tokens(l)) & (TITLES_M | TITLES_F)) for l in labels)
        if has_bare:
            toks = [t for t in toks if t not in TITLES_M | TITLES_F] or toks
        return " ".join(toks)

    def resolve(self, label: Optional[str], episode: Optional[int] = None) -> Optional[str]:
        if not label:
            return None
        key = label.upper()
        for rule in self.rules:
            if key in rule.aliases and rule.applies(episode):
                return rule.canonical
        auto = self._auto.get(key, key)
        for rule in self.rules:                     # canonical spelling may itself be an alias target
            if auto in rule.aliases and rule.applies(episode):
                return rule.canonical
        return auto

    def surface_forms(self) -> dict[str, set]:
        """canonical name -> every raw label / alias that maps to it (for mention detection)."""
        forms: dict[str, set] = defaultdict(set)
        for lab in self._freq:
            forms[self.resolve(lab)].add(lab)
        for rule in self.rules:
            forms[rule.canonical].update(rule.aliases)
            forms[rule.canonical].add(rule.canonical)
        return forms

    def unresolved_report(self, min_lines: int = 1) -> list[dict]:
        """Labels that look descriptive / generic and were left untouched - candidates for alias rules."""
        ruled = {a for r in self.rules for a in r.aliases} | {r.canonical for r in self.rules}
        out = []
        for lab, n in self._freq.most_common():
            canon = self._auto.get(lab, lab)
            multi = len(_tokens(lab)) > 1
            if lab not in ruled and canon == lab and multi and n >= min_lines:
                out.append({"label": lab, "lines": n})
        return out


class MentionDetector:
    """Find character names inside action / camera / sound text.

    Dialogue tells us who *speaks*; most characters in a scene are also *shown*
    in the action lines ("Juliana pauses at the threshold").  A single compiled
    alternation (longest form first) scans each text once - O(text) regardless
    of how many characters exist.  Matching is case-sensitive on Title Case
    forms so common words ("maid", "guard") are not mistaken for characters.
    """

    def __init__(self, resolver: CharacterResolver, line_counts: Counter, min_lines: int = 3):
        self._map: dict[str, str] = {}
        for canon, forms in resolver.surface_forms().items():
            if sum(line_counts.get(f, 0) for f in forms) < min_lines:
                continue
            for f in forms | {canon}:
                if f and f.strip():
                    self._map[f.title()] = canon
        if self._map:
            alt = "|".join(re.escape(k) for k in sorted(self._map, key=len, reverse=True))
            self._re = re.compile(rf"\b(?:the\s+|The\s+)?({alt})(?:'s)?\b")
        else:
            self._re = None

    def find(self, text: str) -> set:
        if not self._re or not text:
            return set()
        return {self._map[m.group(1)] for m in self._re.finditer(text)}
