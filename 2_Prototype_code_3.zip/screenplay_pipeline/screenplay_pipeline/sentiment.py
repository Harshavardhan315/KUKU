"""Module C - sentiment polarity & narrative-arc analysis.

Scoring model (per element, all scores in ``[-1, 1]``)
------------------------------------------------------
``sent_text``  polarity of the *words* (pluggable backend; VADER by default)
``sent_tone``  mean valence of the author's own delivery tags, e.g. the
               ``(Trembling, Pleading)`` in a cue - an explicit emotion annotation
               that is more reliable than inferring emotion from words
``sent``       ``(1 - w) * sent_text + w * sent_tone`` for dialogue with tags,
               otherwise ``sent_text``
``emotion``    dominant discrete emotion from tags (weight 1.0) and keyword
               cues in the text (weight 0.4 each)

Aggregation (per scene): block-weighted mean ``sentiment``, mean absolute value
``intensity`` (how emotionally loaded, regardless of sign), within-scene
``volatility`` (std), ``dominant_mood``, and the scene-to-scene ``delta``.
Per episode: arc shape, turning points, opening / closing mood.

The text scorer is a swappable backend (:class:`SentimentBackend`) so a stronger
model can be dropped in via ``--backend transformer`` or ``register_backend``.
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Callable, Optional, Protocol, Sequence

import numpy as np
import pandas as pd

from .models import ACTION, CAMERA, DIALOGUE, SOUND, TEXT, Element, Episode

EMOTIONS = ["anger", "contempt", "fear", "shock", "sadness", "tenderness", "joy", "resolve"]
_DEFAULT_LEXICON = Path(__file__).resolve().parent.parent / "config" / "lexicon.json"


# =============================================================================
# Lexicon (tone tags + keywords), stem based
# =============================================================================
@lru_cache(maxsize=200_000)
def stem(word: str) -> str:
    """Tiny suffix stripper: enough to unify sobbing / sobs / sobbed -> 'sob'."""
    w = word.lower()
    for suf in ("ingly", "edly", "ing", "ed", "ly", "es", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[: -len(suf)]
            break
    if len(w) > 3 and w[-1] == w[-2] and w[-1] not in "aeiou":      # sobb -> sob
        w = w[:-1]
    return w


@lru_cache(maxsize=50_000)
def _phrase_key(phrase: str) -> str:
    return " ".join(stem(t) for t in re.findall(r"[a-z']+", phrase.lower()))


@dataclass
class Lexicon:
    tone: dict            # stemmed tag -> (valence, emotion)
    vader_overlay: dict
    keywords: dict        # stemmed word -> emotion

    @classmethod
    def load(cls, path: Optional[str | Path] = None) -> "Lexicon":
        data = json.loads(Path(path or _DEFAULT_LEXICON).read_text(encoding="utf-8"))
        overrides = {_phrase_key(k): v for k, v in data.get("valence_overrides", {}).items()}
        tone = {}
        for emotion, grp in data["tone_groups"].items():
            for w in grp["words"]:
                k = _phrase_key(w)
                tone[k] = (overrides.get(k, grp["valence"]), emotion)
        kw = {}
        for emotion, words in data.get("emotion_keywords", {}).items():
            for w in words:
                kw[_phrase_key(w)] = emotion
        return cls(tone=tone, vader_overlay=data.get("vader_overlay", {}), keywords=kw)

    def lookup_tone(self, tag: str) -> Optional[tuple]:
        """``(valence, emotion)`` for a tag; tries the full phrase, then each word."""
        k = _phrase_key(tag)
        if k in self.tone:
            return self.tone[k]
        hits = [self.tone[s] for s in k.split() if s in self.tone]
        if not hits:
            return None
        return (float(np.mean([h[0] for h in hits])), Counter(h[1] for h in hits).most_common(1)[0][0])


# =============================================================================
# Pluggable text-polarity backends
# =============================================================================
class SentimentBackend(Protocol):
    name: str

    def score(self, texts: Sequence[str]) -> list[float]:
        """Return one compound polarity in ``[-1, 1]`` per input text."""


class VaderBackend:
    """VADER with a period-drama overlay.

    Stock VADER scores ``'venomous, wretched traitor'`` as exactly 0.0; the
    overlay in ``lexicon.json`` fixes the most common gaps.  Cheap (~50k
    short texts/s per core) and deterministic - the right default for a
    thousands-of-pages batch.
    """

    name = "vader"

    def __init__(self, lexicon: Lexicon):
        from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
        self._an = SentimentIntensityAnalyzer()
        self._an.lexicon.update(lexicon.vader_overlay)
        self._cached = lru_cache(maxsize=200_000)(lambda t: self._an.polarity_scores(t)["compound"])

    def score(self, texts: Sequence[str]) -> list[float]:
        return [self._cached(t) for t in texts]       # repeated lines ("No.") are scored once


class TransformerBackend:
    """Hugging Face sentiment pipeline (e.g. a RoBERTa/DistilBERT SST-2 model).

    NOTE: written to the public ``transformers`` API but **not executed in the
    build environment** (no model download access) - treat as untested.
    Texts are length-sorted and batched to minimise padding; polarity is
    ``P(positive) - P(negative)`` so 2- and 3-class models are both supported.
    """

    name = "transformer"

    def __init__(self, model: str = "distilbert-base-uncased-finetuned-sst-2-english",
                 device: int = -1, batch_size: int = 64, max_length: int = 128):
        from transformers import pipeline          # lazy: optional heavy dependency
        self._pipe = pipeline("text-classification", model=model, device=device, top_k=None,
                              truncation=True, max_length=max_length)
        self._bs = batch_size

    def score(self, texts: Sequence[str]) -> list[float]:
        order = sorted(range(len(texts)), key=lambda i: len(texts[i]))
        out = [0.0] * len(texts)
        for lo in range(0, len(order), self._bs):
            idx = order[lo: lo + self._bs]
            for i, res in zip(idx, self._pipe([texts[j] or "." for j in idx])):
                probs = {r["label"].lower(): r["score"] for r in res}
                pos = sum(v for k, v in probs.items() if "pos" in k or k in ("label_2", "5 stars", "4 stars"))
                neg = sum(v for k, v in probs.items() if "neg" in k or k in ("label_0", "1 star", "2 stars"))
                out[i] = pos - neg
        return out


_BACKENDS: dict[str, Callable[..., SentimentBackend]] = {}


def register_backend(name: str, factory: Callable[..., SentimentBackend]) -> None:
    """Plug in any scorer exposing ``name`` and ``score(texts) -> list[float]``."""
    _BACKENDS[name] = factory


register_backend("vader", lambda lexicon, **kw: VaderBackend(lexicon))
register_backend("transformer", lambda lexicon, **kw: TransformerBackend(**kw))


def make_backend(name: str, lexicon: Lexicon, **kwargs) -> SentimentBackend:
    if name not in _BACKENDS:
        raise ValueError(f"unknown backend {name!r}; available: {sorted(_BACKENDS)}")
    return _BACKENDS[name](lexicon, **kwargs)


# =============================================================================
# Element-level scoring
# =============================================================================
@dataclass
class ScoringConfig:
    tone_weight: float = 0.6          # share of the dialogue score taken from delivery tags
    keyword_weight: float = 0.4       # emotion mass of one keyword hit (tag hit = 1.0)
    kind_weight: dict = field(default_factory=lambda: {
        DIALOGUE: 1.0, ACTION: 0.6, CAMERA: 0.3, SOUND: 0.3, TEXT: 0.5})
    score_kinds: tuple = (DIALOGUE, ACTION, CAMERA, SOUND, TEXT)


_RE_TOKEN = re.compile(r"[A-Za-z']+")


def score_episode(ep: Episode, backend: SentimentBackend, lex: Lexicon,
                  cfg: Optional[ScoringConfig] = None) -> Episode:
    """Fill ``sent_text / sent_tone / sent / emotion`` on every element of *ep* (in place)."""
    cfg = cfg or ScoringConfig()
    els = [e for s in ep.scenes for e in s.elements if e.kind in cfg.score_kinds]
    scores = backend.score([e.text for e in els])
    for e, s_text in zip(els, scores):
        mass: Counter = Counter()
        vals = []
        for tag in e.tone:
            hit = lex.lookup_tone(tag)
            if hit:
                vals.append(hit[0])
                if hit[1] != "neutral":                 # delivery words like 'whispering' carry no discrete emotion
                    mass[hit[1]] += 1.0
        for tok in _RE_TOKEN.findall(e.text):
            emo = lex.keywords.get(stem(tok))
            if emo:
                mass[emo] += cfg.keyword_weight
        e.sent_text = float(s_text)
        e.sent_tone = float(np.mean(vals)) if vals else None
        w = cfg.tone_weight if (vals and e.kind == DIALOGUE) else (0.3 if vals else 0.0)
        e.sent = (1 - w) * e.sent_text + w * e.sent_tone if vals else e.sent_text
        e.emotion = mass.most_common(1)[0][0] if mass else None
    return ep


# =============================================================================
# Aggregation: scenes
# =============================================================================
def _wmean(values: np.ndarray, weights: np.ndarray) -> float:
    return float(np.average(values, weights=weights)) if weights.sum() > 0 else float("nan")


def _weighted_frame(elements: pd.DataFrame, cfg: ScoringConfig) -> pd.DataFrame:
    """Scored elements with the weights used by every aggregation (kind weight x log(1+words))."""
    df = elements[elements["sent"].notna()].copy()
    kind = df["kind"].astype(str)
    df["w"] = kind.map(cfg.kind_weight).fillna(0.3).to_numpy() * np.log1p(df["n_words"].clip(lower=1)).to_numpy()
    df["ws"] = df["w"] * df["sent"]
    df["wa"] = df["w"] * df["sent"].abs()
    df["is_d"] = kind.eq(DIALOGUE).to_numpy()
    return df


def _dominant_emotion(df: pd.DataFrame, keys: list, min_votes: float) -> pd.DataFrame:
    """Vectorised 'most frequent emotion per group'; ties go to the emotion seen first."""
    voted = df[df["emotion"].notna()]
    votes = (voted.groupby(keys + ["emotion"], sort=False, observed=True).size().rename("cnt").reset_index()
             .sort_values("cnt", ascending=False, kind="stable").drop_duplicates(keys))
    total = voted.groupby(keys, observed=True).size().rename("total").reset_index()
    out = votes.merge(total, on=keys)
    out["mood_share"] = out["cnt"] / out["total"]
    out["dominant_mood"] = np.where(out["cnt"] >= min_votes, out["emotion"], "neutral")
    return out[keys + ["dominant_mood", "mood_share"]]


def analyze_scenes(elements: pd.DataFrame, scenes: pd.DataFrame,
                   cfg: Optional[ScoringConfig] = None, shift_k: float = 1.5,
                   min_shift: float = 0.15) -> pd.DataFrame:
    """Return *scenes* extended with sentiment, intensity, volatility, mood and shift columns.

    ``sentiment`` / ``intensity`` are weighted means of ``sent`` / ``|sent|`` (weights:
    block kind x log(1+words)).  ``major_shift`` marks scene-to-scene jumps larger than
    ``shift_k`` standard deviations of that episode's deltas (and at least ``min_shift``).
    Fully vectorised (groupby sums), so cost is linear in the number of elements.
    """
    cfg = cfg or ScoringConfig()
    df = _weighted_frame(elements, cfg)
    keys = ["episode", "scene_idx"]
    agg = df.groupby(keys, sort=False).agg(w=("w", "sum"), ws=("ws", "sum"), wa=("wa", "sum"))
    agg["volatility"] = df.groupby(keys, sort=False)["sent"].std(ddof=0).fillna(0.0)
    agg["sentiment"], agg["intensity"] = agg["ws"] / agg["w"], agg["wa"] / agg["w"]
    d = df[df["is_d"]].groupby(keys, sort=False).agg(dw=("w", "sum"), dws=("ws", "sum"))
    agg["dialogue_sentiment"] = (d["dws"] / d["dw"]).reindex(agg.index)
    agg = agg.reset_index()[keys + ["sentiment", "intensity", "volatility", "dialogue_sentiment"]]
    mood = _dominant_emotion(df, keys, min_votes=1)
    out = scenes.merge(agg, on=keys, how="left").merge(mood, on=keys, how="left")
    out["dominant_mood"] = out["dominant_mood"].fillna("neutral")
    out["mood_share"] = out["mood_share"].fillna(0.0)
    out = out.sort_values(keys).reset_index(drop=True)
    g = out.groupby("episode")
    out["delta_prev"] = g["sentiment"].diff()
    sd = g["delta_prev"].transform("std")
    out["major_shift"] = out["delta_prev"].abs() >= np.maximum(shift_k * sd.fillna(0), min_shift)
    out["prev_mood"] = g["dominant_mood"].shift()
    return out


# =============================================================================
# Aggregation: episodes & narrative arcs
# =============================================================================
def classify_arc(series: Sequence[float], thr: float = 0.1) -> str:
    """Heuristic arc label from the first / middle / last third of a sentiment series.

    A simplified take on the six story-shape families of Reagan et al. (2016):
    ``rise``, ``fall``, ``man-in-a-hole`` (fall then rise), ``icarus`` (rise then
    fall), ``flat``.  Needs >= 3 scenes; shorter series are ``flat``.
    """
    x = np.asarray([v for v in series if not (v is None or math.isnan(v))], dtype=float)
    if len(x) < 3:
        return "flat"
    a, b, c = (float(np.mean(p)) for p in np.array_split(x, 3))
    net, dip, bump = c - a, min(a, c) - b, b - max(a, c)
    if dip > thr:
        return "man-in-a-hole"
    if bump > thr:
        return "icarus"
    if net > thr:
        return "rise"
    if net < -thr:
        return "fall"
    return "flat"


def build_beats(elements: pd.DataFrame, scenes: pd.DataFrame, beat_seconds: float = 10.0,
                cfg: Optional[ScoringConfig] = None, shift_k: float = 1.5, min_shift: float = 0.15,
                neutral_floor: float = 1.0) -> pd.DataFrame:
    """Equal-length time windows ("beats") with sentiment, intensity and dominant mood.

    Why beats?  Episodes here run ~2 minutes and half of them are a *single*
    scene, so scene-level series are too short to show an arc.  Each
    episode is cut into ``round(runtime / beat_seconds)`` equal windows (~10 s by
    default) - equal, not grid-aligned, so the last beat is never a 1-second
    sliver that single-handedly defines the "ending".  Beats with no scored
    content are skipped.

    ``major_shift`` flags beat-to-beat jumps >= ``shift_k`` x the episode's own
    delta std (and at least ``min_shift``) - the emotional turning points.
    """
    cfg = cfg or ScoringConfig()
    df = _weighted_frame(elements, cfg)
    runtime = scenes.groupby("episode")["end"].max().clip(lower=1.0)
    n_beats = (runtime / beat_seconds).round().clip(lower=1).astype(int)
    rt, nb = df["episode"].map(runtime), df["episode"].map(n_beats)
    mid = (df["start"] + df["end"]) / 2
    df["beat"] = np.minimum(nb - 1, (mid / rt * nb).astype(int)).astype(int)
    keys = ["episode", "beat"]
    agg = df.groupby(keys, sort=True).agg(n_elements=("w", "size"), w=("w", "sum"), ws=("ws", "sum"), wa=("wa", "sum"))
    beats = agg.reset_index()
    beats["sentiment"], beats["intensity"] = beats["ws"] / beats["w"], beats["wa"] / beats["w"]
    # scene that holds most of the beat's content
    sc = (df.groupby(keys + ["scene_idx"]).size().rename("n").reset_index()
            .sort_values(["n", "scene_idx"], ascending=[True, False]).drop_duplicates(keys, keep="last")[keys + ["scene_idx"]])
    beats = (beats.merge(sc, on=keys).merge(_dominant_emotion(df, keys, neutral_floor)[keys + ["dominant_mood"]],
                                            on=keys, how="left"))
    beats["dominant_mood"] = beats["dominant_mood"].fillna("neutral")
    beats["t_start"] = beats["beat"] * beats["episode"].map(runtime) / beats["episode"].map(n_beats)
    beats["t_end"] = (beats["beat"] + 1) * beats["episode"].map(runtime) / beats["episode"].map(n_beats)
    beats = beats.merge(scenes[["episode", "scene_idx", "scene_no", "heading_raw"]], on=["episode", "scene_idx"], how="left")
    beats = beats.sort_values(keys).reset_index(drop=True)
    g = beats.groupby("episode")
    beats["beat_idx"] = g.cumcount()
    beats["rel_pos"] = beats["beat_idx"] / (g["beat"].transform("size") - 1).clip(lower=1)
    beats["delta_prev"] = g["sentiment"].diff()
    sd = g["delta_prev"].transform("std").fillna(0)
    beats["major_shift"] = beats["delta_prev"].abs() >= np.maximum(shift_k * sd, min_shift)
    beats["prev_mood"] = g["dominant_mood"].shift()
    return beats[["episode", "beat", "t_start", "t_end", "scene_idx", "n_elements", "sentiment", "intensity",
                  "dominant_mood", "scene_no", "heading_raw", "beat_idx", "rel_pos", "delta_prev",
                  "major_shift", "prev_mood"]]


def analyze_episodes(beats: pd.DataFrame, episodes: pd.DataFrame) -> pd.DataFrame:
    """One row per episode, computed on beats: sentiment summary, arc shape, turning points, ending."""
    rows = []
    for ep, g in beats.groupby("episode"):
        g = g.sort_values("beat")
        s = g["sentiment"].to_numpy(dtype=float)
        moods = g["dominant_mood"].value_counts()
        moods = moods.drop("neutral", errors="ignore")
        last = g.iloc[-1]
        rows.append({
            "episode": ep, "n_beats": len(g),
            "mean_sentiment": float(np.mean(s)), "mean_intensity": float(g["intensity"].mean()),
            "opening_sentiment": float(s[0]), "closing_sentiment": float(s[-1]),
            "net_change": float(s[-1] - s[0]) if len(s) > 1 else 0.0,
            "min_sentiment": float(s.min()), "max_sentiment": float(s.max()),
            "lowest_point_s": float(g.iloc[int(np.argmin(s))]["t_start"]),
            "highest_point_s": float(g.iloc[int(np.argmax(s))]["t_start"]),
            "arc_shape": classify_arc(s),
            "n_major_shifts": int(g["major_shift"].sum()),
            "dominant_mood": moods.index[0] if len(moods) else "neutral",
            "opening_mood": g.iloc[0]["dominant_mood"], "closing_mood": last["dominant_mood"],
            "closing_intensity": float(last["intensity"]),
        })
    return episodes.merge(pd.DataFrame(rows), on="episode", how="left")


def sentiment_timeline(elements: pd.DataFrame, bin_seconds: float = 5.0) -> pd.DataFrame:
    """Per-episode sentiment on a fixed time grid (for plots and pacing analysis).

    Each element contributes its score to the bins its ``[start, end]`` span
    covers, weighted like in :func:`analyze_scenes`.
    """
    df = elements[elements["sent"].notna()]
    t = (df["start"] + df["end"]) / 2
    out = (df.assign(bin=(t // bin_seconds).astype(int) * bin_seconds)
             .groupby(["episode", "bin"], observed=True)["sent"].mean().rename("sentiment").reset_index())
    return out


def mood_transitions(frame: pd.DataFrame) -> pd.DataFrame:
    """Counts of dominant-mood transitions between consecutive beats (or scenes) within an episode."""
    t = frame.dropna(subset=["prev_mood"])
    return (t.groupby(["prev_mood", "dominant_mood"]).size().rename("count").reset_index()
              .rename(columns={"prev_mood": "from_mood", "dominant_mood": "to_mood"})
              .sort_values("count", ascending=False).reset_index(drop=True))


def tone_coverage(elements: pd.DataFrame, lex: Lexicon) -> pd.DataFrame:
    """Which delivery tags does the lexicon NOT recognise?  Extend ``lexicon.json`` with the top rows."""
    tags = Counter(t for s in elements["tone"].dropna() for t in s.split("|") if t)
    rows = [{"tag": t, "count": n, "covered": lex.lookup_tone(t) is not None} for t, n in tags.most_common()]
    return pd.DataFrame(rows, columns=["tag", "count", "covered"])
