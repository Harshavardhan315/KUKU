"""Visual-cue scoring from the script's own CAMERA / ACTION / SOUND FX notes.

The input pack is text only (no video), but every block carries a written shot description -
"Tight insert on Juliana's white-knuckled hand", "A sharp whip crack as the riding crop makes
contact".  Those notes are the closest thing to pixels we have, and they say far more about a
scroll-stopping first frame than the spoken words do.  This module turns each note into a
``vis`` score (0..1) plus human-readable ``vis_tags`` ("tight insert", "impact: slap"), so the
promo ranker can score a *visual* hook instead of relying on dialogue keywords alone.

How a note is scored
--------------------
Cues are independent pieces of evidence, each with a weight; they combine as a noisy-OR
(``1 - prod(1 - w)``) so two moderate cues beat one, and the score can never exceed 1:

* **Shot grammar** (CAMERA notes): insert / extreme close-up / whip-pan / push-in / low-angle.
* **Physical impact** (any note): slap, strike, lunge, shatter, slam, a drawn blade ...
* **Reveal / reaction**: someone bursts in, discovers, recoils, "eyes snap wide" ...
* **Raw expression**: agonized, furious, trembling, tear-filled, blood, wound ...
* **Shock sound** (SOUND FX notes): explosion, scream, crack, crash ... (ambient creaks and
  footsteps count much less).

Limits (stated in the write-up): this reads a *description* of the image, written by the
script's author, not the image.  A real video model would plug in through
:mod:`screenplay_pipeline.providers` (``ClipView.visual_notes`` is where its output goes).
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

from .models import ACTION, CAMERA, SOUND

# (regex, weight, tag) - first group: shot grammar, only meaningful in CAMERA notes
_SHOT = [
    (r"\b(extreme close[- ]?up|tight insert|insert (?:shot )?on|macro)\b", 0.50, "tight insert"),
    (r"\b(whip[- ]?pan|crash zoom|snap zoom|smash cut|jolting|handheld|shaky)\b", 0.45, "violent camera move"),
    (r"\b(push[- ]?in|dolly[- ]?in|slow zoom|rapid zoom)\b", 0.35, "push-in"),
    (r"\b(close[- ]?up|tight (?:shot|close))\b", 0.30, "close-up"),
    (r"\b(low[- ]angle|dutch|canted)\b", 0.30, "low angle"),
    (r"\b(over[- ]the[- ]shoulder)\b", 0.12, "over-the-shoulder"),
]
# content cues, valid in any note kind
_CONTENT = [
    (r"\b(slaps?|slapped|slapping|strikes?|struck|punch\w*|backhand\w*|lash\w*|whips?|whipp\w+|brand\w*)\b", 0.65, "impact: strike"),
    (r"\b(lunges?|lunged|lunging|shoves?|shoved|grabs?|grabbed|seiz\w+|wrench\w*|yank\w*|rips?|ripp\w+|tears? (?:at|open|off))\b", 0.50, "impact: grab/lunge"),
    (r"\b(smash\w*|shatter\w*|slams?|slammed|crash\w*|hurls?|hurled|flings?|flung|throws?|threw|bursts?)\b", 0.50, "impact: smash"),
    (r"\b(dagger|blade|knife|sword|pistol|poker|crop|noose|poison\w*|vial|goblet)\b", 0.35, "weapon/object of threat"),
    (r"\b(collaps\w+|crumples?|stagger\w*|falls? to|drops? to (?:her|his) knees|sink\w* to)\b", 0.40, "collapse"),
    (r"\b(reveals?|unveil\w*|discover\w*|uncover\w*|emerg\w+|steps? (?:through|out)|appears? (?:in|at)|doors? (?:burst|fl[iy]|swing|crash)\w*)\b", 0.40, "reveal/entrance"),
    (r"\b(recoil\w*|freez\w+|gasp\w*|stunned|frozen|snap(?:s|ping)? wide|eyes (?:widen|snap|flash)\w*|go(?:es)? pale|realiz\w+|horrified)\b", 0.40, "shock reaction"),
    (r"\b(agoniz\w+|furious|fury|rage|enrage\w*|terrif\w+|horror|devastat\w+|anguish\w*|sobbing|tear[- ]?(?:filled|streaked|stained)|tearful|trembl\w+|white[- ]knuckled|snarl\w*|sneer\w*|seeth\w+)\b", 0.35, "raw expression"),
    (r"\b(blood\w*|wounds?|gash\w*|scar\w*|bruis\w+|welts?|bleeding|gaunt|bound|shackle\w*|chain\w*)\b", 0.30, "injury/restraint"),
]
_SOUND = [
    (r"\b(explosion|detonation|gunshot|gunfire|thunder\w*|boom\w*|scream\w*|shriek\w*|wail\w*)\b", 0.70, "shock sound"),
    (r"\b(cracks?|cracked|crash\w*|bangs?|banged|slam\w*|shatter\w*|snaps?|snapped|thud\w*|stab\w*|clang\w*)\b", 0.55, "impact sound"),
    (r"\b(toll\w*|bells?|sting|stinger|drum\w*|heartbeat)\b", 0.35, "dramatic sound"),
    (r"\b(footstep\w*|bootstep\w*|creak\w*|rustl\w*|drip\w*|whisper\w*)\b", 0.15, "ambient sound"),
]
_SHOT_RX = [(re.compile(p, re.I), w, t) for p, w, t in _SHOT]
_CONTENT_RX = [(re.compile(p, re.I), w, t) for p, w, t in _CONTENT]
_SOUND_RX = [(re.compile(p, re.I), w, t) for p, w, t in _SOUND]

VISUAL_KINDS = {CAMERA, ACTION, SOUND}


def score_note(text: str, kind: str) -> tuple[float, list[str]]:
    """Score one CAMERA/ACTION/SOUND note.  Returns ``(vis 0..1, tags)``."""
    t = str(text or "")
    if not t.strip():
        return 0.0, []
    hits: list[tuple[float, str]] = []
    banks = []
    if kind == CAMERA:
        banks = [_SHOT_RX, _CONTENT_RX]
    elif kind == SOUND:
        banks = [_SOUND_RX, _CONTENT_RX]
    elif kind == ACTION:
        banks = [_CONTENT_RX]
    for bank in banks:
        for rx, w, tag in bank:
            if rx.search(t):
                # a note describing action in the *action* block is half as telling as the camera
                # lingering on it; keep ACTION a touch below CAMERA/SOUND for the same cue
                hits.append((w * (0.85 if kind == ACTION else 1.0), tag))
    if not hits:
        return 0.0, []
    hits.sort(reverse=True)
    top = hits[:4]                                   # four cues is already a loud note
    vis = 1.0 - float(np.prod([1.0 - w for w, _ in top]))
    return float(min(1.0, vis)), [tag for _, tag in top]


def add_visual_columns(elements: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of *elements* with ``vis`` and ``vis_tags`` (dialogue rows get 0 / "")."""
    df = elements.copy()
    kinds = df["kind"].astype(str).to_numpy()
    texts = df["text"].fillna("").tolist()
    vis, tags = np.zeros(len(df)), [""] * len(df)
    cache: dict[tuple[str, str], tuple[float, list[str]]] = {}
    for n, (k, t) in enumerate(zip(kinds, texts)):
        if k not in VISUAL_KINDS:
            continue
        key = (k, t)
        if key not in cache:
            cache[key] = score_note(t, k)
        v, tg = cache[key]
        vis[n], tags[n] = v, ", ".join(tg)
    df["vis"], df["vis_tags"] = vis, tags
    return df
