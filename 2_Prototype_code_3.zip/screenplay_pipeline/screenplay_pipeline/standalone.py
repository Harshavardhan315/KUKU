"""Strict "makes sense on its own" gate for promo openings.

A scrolling viewer who has never seen the show gets no setup.  So a promo may not *open* on a line
that only works with something earlier.  Previously this was a soft penalty; here it is a hard
filter - a candidate that fails is dropped, and because every block is a candidate start, the
ranker simply moves on to the next block that does pass (which is how leading dangling lines get
"stripped": the clip starts after them).

Checks, applied to the clip's opening spoken line(s) and the shot notes in its first seconds:

``dangling_conjunction``  opens on And / But / So / Then / Because / Or / Yet / Which ...
``mid_thought``           opens on "..." or a lowercase continuation
``unresolved_pronoun``    opens on he / she / they / him / her ... with nobody named in the opening
                          shot notes or earlier in the clip, so "who?" is unanswerable
``back_reference``        the first spoken lines lean on prior events ("as I said", "last time",
                          "remember when", "you promised" ...)
``deictic_reference``     a short opening line built on "that/this/it" ("That will be your testimony.") or
                          ending on a bare "this/that" ("Why would anyone do this?") with nothing in the
                          opening shot notes to point at
``fragment_reply``        opens on a one- or two-word reply ("Who?", "Rupert?") - an answer with no
                          question - unless the opening shot is itself a strong visual hook

What this does NOT do (and the write-up says so): it cannot tell that a line is confusing because
of plot knowledge it never mentions in surface wording.  It removes the *detectable* dependencies.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

CONJUNCTIONS = {
    "and", "but", "so", "then", "because", "or", "yet", "also", "however", "which", "whose", "whereas",
    "although", "though", "nor", "plus", "anyway", "besides", "meanwhile", "otherwise", "therefore", "thus",
}
DEICTIC = {"that", "this", "those", "these", "it", "its"}      # point at something the viewer has not seen
PRONOUNS = {"he", "she", "him", "her", "his", "hers", "they", "them", "their", "theirs", "himself", "herself"}
BACK_REFS = re.compile(
    r"\b(as (?:i|we) (?:said|told|mentioned|warned)|as you (?:know|said|promised|saw)|as promised|last time|"
    r"remember when|the other (?:night|day)|earlier (?:today|tonight)|what i told you|i (?:told|warned) you|"
    r"you promised|like before|like i said|not again|once again|that (?:night|day) (?:in|at|when))\b", re.I)

_WORD = re.compile(r"[A-Za-z][A-Za-z']*")


@dataclass
class Verdict:
    ok: bool
    reasons: tuple[str, ...] = ()


def _first_word(text: str) -> str:
    m = _WORD.search(text or "")
    return m.group(0).lower() if m else ""


def name_tokens(speakers) -> set[str]:
    """Lower-case name words for an episode's speakers ("ALEXANDER'S MOTHER" -> alexander, mother)."""
    out: set[str] = set()
    for s in speakers:
        for w in _WORD.findall(str(s)):
            w = w.lower().replace("'s", "")
            if len(w) >= 3:
                out.add(w)
    return out


def check_opening(dialogue_lines: list[str], lead_notes: str, names: set[str], strong_visual: bool = False) -> Verdict:
    """Verdict for a clip whose first spoken lines are *dialogue_lines* and whose opening shot/action
    notes read *lead_notes*.  ``strong_visual`` is True when those notes carry a big visual hook."""
    why: list[str] = []
    if not dialogue_lines:
        return Verdict(True)                      # silent/visual opener: nothing to depend on
    first = dialogue_lines[0].strip()
    w0 = _first_word(first)
    if w0 in CONJUNCTIONS:
        why.append("dangling_conjunction")
    if first.startswith(("...", "…")) or (first[:1].islower()):
        why.append("mid_thought")
    if w0 in PRONOUNS:
        notes = (lead_notes or "").lower()
        if not any(n in notes for n in names):
            why.append("unresolved_pronoun")
    words = _WORD.findall(first)
    n_words = len(words)
    if n_words <= 7 and not strong_visual and (w0 in DEICTIC or (words and words[-1].lower() in {"this", "that"})):
        why.append("deictic_reference")
    if 0 < n_words <= 2 and not strong_visual:
        why.append("fragment_reply")
    if any(BACK_REFS.search(t) for t in dialogue_lines[:2]):
        why.append("back_reference")
    return Verdict(not why, tuple(why))
