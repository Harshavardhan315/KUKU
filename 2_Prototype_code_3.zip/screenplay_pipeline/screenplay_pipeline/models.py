"""Typed records shared by every pipeline stage.

The parser emits these lightweight dataclasses (``slots=True`` keeps memory
flat when thousands of pages are held in RAM); later stages convert them to
pandas DataFrames, which are the interchange format for Modules B, C and D.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

# --- element kinds -----------------------------------------------------------
DIALOGUE = "DIALOGUE"
ACTION = "ACTION"
CAMERA = "CAMERA"
SOUND = "SOUND"
TEXT = "TEXT"          # on-screen text / super / title card
TRANSITION = "TRANSITION"

#: Block labels that are NOT a speaking character.  Everything else that appears
#: as a block label is treated as a character cue.
NON_SPEAKER_LABELS = {
    "CAMERA": CAMERA,
    "SHOT": CAMERA,
    "ACTION": ACTION,
    "SOUND FX": SOUND,
    "SOUND": SOUND,
    "SFX": SOUND,
    "SOUND EFFECT": SOUND,
    "SOUND EFFECTS": SOUND,
    "MUSIC": SOUND,
    "TEXT": TEXT,
    "SUPER": TEXT,
    "TITLE": TEXT,
    "ON SCREEN TEXT": TEXT,
    "TRANSITION": TRANSITION,
}

#: Parenthetical contents that describe *how a line is delivered technically*
#: (off-screen, voice-over, continued ...) rather than the emotional tone.
CUE_MODIFIERS = {
    "OS", "OC", "VO", "CONTD", "CONT", "CONTINUING", "CONTINUOUS", "OFFSCREEN",
    "OFF", "FILTERED", "ONPHONE", "INTOPHONE", "ONRADIO", "PRELAP", "SUBTITLED",
    "INTERCUT", "ON", "MORE",
}


@dataclass(slots=True)
class Element:
    """One atomic block of a script: a line of dialogue, an action beat, a shot..."""

    episode: int
    scene_no: int
    order: int                      # running index inside the episode (stable sort key)
    kind: str                       # one of the kind constants above
    speaker_raw: Optional[str]      # label exactly as written (dialogue only), parentheticals removed
    tone: tuple = ()                # emotional delivery tags, lower-cased ("cold", "commanding")
    modifiers: tuple = ()           # technical modifiers ("O.S.", "V.O.")
    start: Optional[float] = None   # seconds from episode start
    end: Optional[float] = None
    text: str = ""                  # spoken text / description, parentheticals stripped
    time_estimated: bool = False    # True when timestamps were synthesised (no timing in source)
    # --- filled by Module C -------------------------------------------------
    sent_text: Optional[float] = None
    sent_tone: Optional[float] = None
    sent: Optional[float] = None
    emotion: Optional[str] = None


@dataclass(slots=True)
class Scene:
    episode: int
    scene_no: int
    heading_raw: str = ""
    int_ext: Optional[str] = None
    location: Optional[str] = None
    location_base: Optional[str] = None
    time_of_day: Optional[str] = None
    start: Optional[float] = None
    end: Optional[float] = None
    elements: list = field(default_factory=list)


@dataclass(slots=True)
class ParseIssue:
    """A data-quality finding.  Collected instead of raised: one bad line must
    never kill a 5,000-page batch run."""

    episode: int
    line_no: int
    severity: str        # "info" | "warning" | "error"
    code: str            # machine-readable, e.g. "missing_timing"
    message: str


@dataclass
class Episode:
    number: int = 0
    source: str = ""
    dialect: str = "timestamped"
    logline: str = ""
    continuity: str = ""
    scenes: list = field(default_factory=list)
    issues: list = field(default_factory=list)
