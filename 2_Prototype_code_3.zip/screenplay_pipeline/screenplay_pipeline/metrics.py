"""Module D - aggregated metrics, summary and exporters.

Definitions (so every number in the report can be audited)
----------------------------------------------------------
dialogue_word_share   dialogue words / (dialogue words + action words)
da_word_ratio         dialogue words / action words  (NaN when no action)
dialogue_time_share   seconds covered by >= 1 dialogue block / scene duration
                      (union of intervals - overlapping blocks are not double counted)
action_time_share    same for ACTION blocks
shots_per_min         CAMERA blocks per minute  (pacing: cutting rate)
avg_shot_len          scene duration / CAMERA blocks
words_per_min         dialogue words per minute (speech density)

Camera and sound blocks are *direction*, not story content, so they are excluded
from the dialogue-vs-action word ratio but used for pacing.
"""
from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from .models import ACTION, CAMERA, DIALOGUE, SOUND


def union_length(starts: np.ndarray, ends: np.ndarray) -> float:
    """Total length covered by the union of ``[start, end]`` intervals."""
    if len(starts) == 0:
        return 0.0
    order = np.argsort(starts)
    s, e = starts[order], ends[order]
    total, cur_s, cur_e = 0.0, s[0], e[0]
    for a, b in zip(s[1:], e[1:]):
        if a > cur_e:
            total += cur_e - cur_s
            cur_s, cur_e = a, b
        else:
            cur_e = max(cur_e, b)
    return total + (cur_e - cur_s)


def _union_by_group(df: pd.DataFrame, keys: list) -> pd.Series:
    """Per-group length of the union of [start, end] intervals - no Python loop.

    Sorted by start, an interval adds ``max(0, end - max(start, running_max_of_previous_ends))``;
    summing these increments equals the union length (verified against :func:`union_length`).
    """
    if df.empty:
        return pd.Series(dtype=float)
    d = df.sort_values(keys + ["start"], kind="stable")
    running = d.groupby(keys)["end"].cummax()
    prev = running.groupby([d[k] for k in keys]).shift().fillna(-np.inf)
    inc = (d["end"] - np.maximum(d["start"], prev)).clip(lower=0)
    return inc.groupby([d[k] for k in keys]).sum()


def _grouped_block_metrics(el: pd.DataFrame, keys: list, duration: pd.Series) -> pd.DataFrame:
    """Vectorised dialogue / action / pacing metrics for every group defined by *keys*."""
    kind = el["kind"].astype(str)
    cnt = (el.assign(_k=kind).groupby(keys + ["_k"], observed=True)
             .agg(n=("order", "size"), words=("n_words", "sum")).unstack("_k", fill_value=0))
    def col(what, k):
        return cnt[(what, k)] if (what, k) in cnt.columns else pd.Series(0, index=cnt.index)
    out = pd.DataFrame(index=cnt.index)
    out["n_dialogue"], out["n_action"] = col("n", DIALOGUE), col("n", ACTION)
    out["n_camera"], out["n_sound"] = col("n", CAMERA), col("n", SOUND)
    out["dialogue_words"], out["action_words"] = col("words", DIALOGUE), col("words", ACTION)
    if "speaker" in el:
        out["n_speakers"] = el[kind.eq(DIALOGUE)].groupby(keys, observed=True)["speaker"].nunique()
    out = out.fillna(0)
    dur = duration.reindex(out.index).astype(float)
    safe = dur.where(dur > 0)
    dw, aw = out["dialogue_words"], out["action_words"]
    out["dialogue_word_share"] = dw / (dw + aw).where(dw + aw > 0)
    out["da_word_ratio"] = dw / aw.where(aw > 0)
    for name, k in (("dialogue_time_share", DIALOGUE), ("action_time_share", ACTION)):
        union = _union_by_group(el[kind.eq(k)], keys).reindex(out.index).fillna(0.0)
        out[name] = (union / safe).clip(upper=1.0).fillna(0.0)
    out["shots_per_min"] = out["n_camera"] / (safe / 60)
    out["avg_shot_len"] = safe / out["n_camera"].where(out["n_camera"] > 0)
    out["words_per_min"] = dw / (safe / 60)
    return out.reset_index()


def scene_metrics(elements: pd.DataFrame, scenes: pd.DataFrame) -> pd.DataFrame:
    """Scenes table extended with dialogue/action/pacing metrics."""
    keys = ["episode", "scene_idx"]
    m = _grouped_block_metrics(elements, keys, scenes.set_index(keys)["duration"])
    return scenes.merge(m, on=keys, how="left")


def episode_metrics(elements: pd.DataFrame, episodes: pd.DataFrame) -> pd.DataFrame:
    m = _grouped_block_metrics(elements, ["episode"], episodes.set_index("episode")["runtime"])
    return episodes.merge(m, on="episode", how="left")


def character_table(elements: pd.DataFrame, presence: pd.DataFrame, centrality: pd.DataFrame) -> pd.DataFrame:
    """Per-character footprint, emotional signature and network importance."""
    d = elements[elements["kind"].astype(str).eq(DIALOGUE)]
    total_words = max(int(d["n_words"].sum()), 1)
    g = d.groupby("speaker", observed=True)
    out = pd.DataFrame({
        "lines": g.size(), "words": g["n_words"].sum(),
        "episodes": g["episode"].nunique(), "first_episode": g["episode"].min(), "last_episode": g["episode"].max(),
        "avg_dialogue_sentiment": g["sent"].mean(),
        "dominant_emotion": g["emotion"].agg(lambda s: s.dropna().mode().iat[0] if s.notna().any() else "neutral"),
    })
    out["word_share"] = out["words"] / total_words
    scenes_present = presence.groupby("character").apply(
        lambda x: x[["episode", "scene_idx"]].drop_duplicates().shape[0], include_groups=False)
    out["scenes_present"] = scenes_present.reindex(out.index).fillna(0).astype(int)
    out = out.reset_index().rename(columns={"speaker": "character"})
    out = out.merge(centrality, on="character", how="left")
    return out.sort_values("lines", ascending=False).reset_index(drop=True)


# =============================================================================
# Summary + exporters
# =============================================================================
def _r(x, n=3):
    return None if x is None or (isinstance(x, float) and np.isnan(x)) else round(float(x), n)


def build_summary(*, episodes: pd.DataFrame, scenes: pd.DataFrame, beats: pd.DataFrame, elements: pd.DataFrame,
                  characters: pd.DataFrame, transitions: pd.DataFrame, issues: pd.DataFrame,
                  coverage: pd.DataFrame, backend: str, unresolved: list) -> dict:
    """Series-level headline numbers (JSON-serialisable)."""
    d_words = elements.loc[elements["kind"].astype(str).eq(DIALOGUE), "n_words"].sum()
    a_words = elements.loc[elements["kind"].astype(str).eq(ACTION), "n_words"].sum()
    shifts = (beats[beats["major_shift"]].assign(_abs=lambda x: x["delta_prev"].abs())
              .nlargest(10, "_abs"))
    covered = coverage.loc[coverage["covered"], "count"].sum() / max(coverage["count"].sum(), 1) if len(coverage) else None
    est = bool(elements["time_estimated"].any())
    ends = episodes.sort_values("closing_intensity", ascending=False).head(5)
    return {
        "backend": backend,
        "n_episodes": int(len(episodes)), "n_scenes": int(len(scenes)), "n_elements": int(len(elements)),
        "total_runtime_min": _r(episodes["runtime"].sum() / 60, 1),
        "timestamps_estimated": est,
        "dialogue_words": int(d_words), "action_words": int(a_words),
        "series_da_word_ratio": _r(d_words / a_words if a_words else float("nan")),
        "mean_dialogue_word_share": _r(episodes["dialogue_word_share"].mean()),
        "mean_shots_per_min": _r(episodes["shots_per_min"].mean(), 2),
        "mean_sentiment": _r(episodes["mean_sentiment"].mean()),
        "n_characters": int(len(characters)),
        "top_characters": characters.head(8)[["character", "lines", "episodes", "avg_dialogue_sentiment",
                                              "dominant_emotion"]].round(3).to_dict("records"),
        "arc_shape_counts": episodes["arc_shape"].value_counts().to_dict(),
        "dominant_mood_counts": beats["dominant_mood"].value_counts().to_dict(),
        "top_mood_transitions": transitions.head(8).to_dict("records"),
        "most_negative_episodes": episodes.nsmallest(3, "mean_sentiment")[["episode", "mean_sentiment"]].round(3).to_dict("records"),
        "most_positive_episodes": episodes.nlargest(3, "mean_sentiment")[["episode", "mean_sentiment"]].round(3).to_dict("records"),
        "biggest_shifts": shifts[["episode", "t_start", "heading_raw", "delta_prev", "prev_mood", "dominant_mood"]]
                          .round(3).to_dict("records"),
        "highest_intensity_endings": ends[["episode", "closing_mood", "closing_intensity"]].round(3).to_dict("records"),
        "parse_issue_counts": issues["code"].value_counts().to_dict() if len(issues) else {},
        "tone_tag_lexicon_coverage": _r(covered),
        "unresolved_character_labels": unresolved[:15],
    }


def md_table(df: pd.DataFrame, floatfmt: str = "{:.2f}") -> str:
    """Dependency-free GitHub-markdown table."""
    if df.empty:
        return "_(none)_"
    whole = {c for c in df.columns if pd.api.types.is_numeric_dtype(df[c]) and df[c].dropna().eq(df[c].dropna().round()).all()}
    def fmt(v, col):
        if isinstance(v, (float, np.floating)):
            if np.isnan(v):
                return ""
            return f"{v:.0f}" if col in whole else floatfmt.format(v)
        return str(v)
    head = "| " + " | ".join(map(str, df.columns)) + " |"
    sep = "| " + " | ".join("---" for _ in df.columns) + " |"
    cols = list(df.columns)
    body = ["| " + " | ".join(fmt(v, c) for v, c in zip(row, cols)) + " |" for row in df.itertuples(index=False)]
    return "\n".join([head, sep, *body])


def write_report(path: Path, summary: dict, episodes: pd.DataFrame, characters: pd.DataFrame,
                 scenes: pd.DataFrame) -> None:
    """Human-readable Markdown report."""
    s = summary
    est = "  \n> Timestamps in this input were **estimated** from word counts - treat time-based metrics as approximate." \
        if s["timestamps_estimated"] else ""
    L = [f"# Screenplay Analysis Report{est}", "",
         f"**{s['n_episodes']} episodes · {s['n_scenes']} scenes · {s['total_runtime_min']} min runtime · "
         f"{s['n_characters']} speaking characters** (sentiment backend: `{s['backend']}`)", "",
         "## Headline metrics", "",
         f"- Dialogue : action word ratio = **{s['series_da_word_ratio']}** "
         f"(dialogue is {s['mean_dialogue_word_share']:.0%} of story words on average)",
         f"- Cutting rate = **{s['mean_shots_per_min']} shots/min**",
         f"- Mean sentiment = **{s['mean_sentiment']}** (−1 very negative … +1 very positive)",
         f"- Episode arc shapes: {s['arc_shape_counts']}",
         f"- Dominant beat moods: {s['dominant_mood_counts']}", "",
         "## Dominant mood transitions (10-second beat → next beat)", "",
         md_table(pd.DataFrame(s["top_mood_transitions"])), "",
         "## Biggest emotional swings", "",
         md_table(pd.DataFrame(s["biggest_shifts"])), "",
         "## Highest-intensity episode endings", "",
         md_table(pd.DataFrame(s["highest_intensity_endings"])), "",
         "## Top characters", "",
         md_table(characters.head(10)[["character", "lines", "words", "episodes", "scenes_present",
                                       "avg_dialogue_sentiment", "dominant_emotion", "strength", "community"]]), "",
         "## Per-episode summary", "",
         md_table(episodes[["episode", "n_scenes", "runtime", "mean_sentiment", "mean_intensity", "arc_shape",
                            "opening_mood", "closing_mood", "dialogue_word_share", "shots_per_min"]]), "",
         "## Data quality", "",
         f"- Parse issues by type: {s['parse_issue_counts'] or 'none'}",
         f"- Delivery-tag lexicon coverage: {s['tone_tag_lexicon_coverage']}",
         f"- Unresolved descriptive character labels (candidates for `aliases.json`): "
         f"{[u['label'] for u in s['unresolved_character_labels']]}"]
    Path(path).write_text("\n".join(L) + "\n", encoding="utf-8")


def export_tables(out_dir: Path, tables: dict[str, pd.DataFrame], summary: dict) -> None:
    """Write every table to ``data/*.csv`` and the summary to ``summary.json``."""
    data = Path(out_dir) / "data"
    data.mkdir(parents=True, exist_ok=True)
    for name, df in tables.items():
        df.to_csv(data / f"{name}.csv", index=False)
    (Path(out_dir) / "summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
