"""Module A - regex-driven screenplay parser.

Two dialects are supported and auto-detected:

``timestamped``
    The Kuku production format::

        SCENE 01
        Scene heading: INT. CATHEDRAL - DAY
        Scene start: 00:00.00
        Scene end: 02:18.00

        **MATRIARCH (Cold, Commanding):**
        Start: (00:11.30) | End: (00:13.10)
        "You should turn around, Juliana."

``fountain``
    Classic industry layout (sluglines, centred CHARACTER cues, indented
    parentheticals, blank-line separated blocks).  Timestamps do not exist in
    this format, so durations are *estimated* from word counts and flagged with
    ``time_estimated=True`` so downstream metrics can be treated with care.

Design rules (all driven by real messiness found in the 50-episode sample):

* **Single streaming pass, line-oriented state machine.**  O(n) time, constant
  extra memory per episode, no catastrophic-backtracking regexes over the whole
  file.  All patterns are compiled once at import time.
* **Never raise on bad input.**  Anomalies become :class:`ParseIssue` records.
* **Case-insensitive structural keys** (episode 6 uses ``SCENE HEADING:`` where
  every other episode uses ``Scene heading:``).
* **Wrapped cues / multi-line parentheticals** are re-joined before parsing.
* **Cue parentheticals are split** into technical modifiers (``O.S.``, ``V.O.``,
  ``Continuing``) and emotional tone tags (``Mocking, Spiteful``).
"""
from __future__ import annotations

import re
import unicodedata
from typing import Iterable, Optional

import pandas as pd

from .models import (
    ACTION, CUE_MODIFIERS, DIALOGUE, NON_SPEAKER_LABELS, Element, Episode,
    ParseIssue, Scene,
)

# =============================================================================
# 0. Normalisation helpers
# =============================================================================
_CHAR_MAP = str.maketrans({
    "“": '"', "”": '"', "‘": "'", "’": "'",   # curly quotes
    " ": " ", "﻿": "", "​": "",                    # nbsp / BOM / zero-width
})


def normalize_text(raw: str) -> str:
    """Unicode-NFC, straighten quotes, unify newlines, drop BOM / zero-width chars."""
    text = unicodedata.normalize("NFC", raw).translate(_CHAR_MAP)
    return text.replace("\r\n", "\n").replace("\r", "\n")


_WORD = re.compile(r"[A-Za-z0-9]+(?:'[A-Za-z]+)?")


def count_words(text: str) -> int:
    return len(_WORD.findall(text))


# =============================================================================
# 1. Timestamps
# =============================================================================
# Accepts mm:ss, mm:ss.ff, h:mm:ss(.ff); comma or dot as decimal separator.
_TS = r"(?:\d+:)?\d{1,2}:\d{2}(?:[.,]\d{1,3})?"
_RE_TS = re.compile(r"^(?:(\d+):)?(\d{1,2}):(\d{2})(?:[.,](\d{1,3}))?$")


def parse_ts(value: str) -> Optional[float]:
    """``'01:13.50' -> 73.5``; ``None`` when *value* is not a timestamp."""
    m = _RE_TS.match(value.strip().strip("()[] "))
    if not m:
        return None
    hours, minutes, seconds, frac = m.groups()
    total = int(hours or 0) * 3600 + int(minutes) * 60 + int(seconds)
    return total + (float("0." + frac) if frac else 0.0)


# =============================================================================
# 2. Scene headings
# =============================================================================
_TOD = {
    "DAY", "NIGHT", "DAWN", "DUSK", "MORNING", "AFTERNOON", "EVENING", "SUNSET",
    "SUNRISE", "CONTINUOUS", "LATER", "MOMENTS LATER", "SAME", "SAME TIME",
    "NEXT DAY", "LATER THAT NIGHT", "DAYBREAK", "TWILIGHT", "MIDDAY",
    "MIDNIGHT", "EARLY MORNING", "LATE NIGHT", "CONTINUOUS ACTION",
}
_RE_HEADING = re.compile(
    r"^\s*(?P<ie>INT\.?\s*/\s*EXT\.?|EXT\.?\s*/\s*INT\.?|I\s*/\s*E\.?|INT\.?|EXT\.?|EST\.?)"
    r"\s+(?P<rest>.+?)\s*$", re.I)
# split on en/em dashes, or on hyphens that have whitespace on both sides
# ("FARM-HOUSE" stays intact, "MANOR - DRAWING ROOM" splits).
_RE_HEAD_SEP = re.compile(r"\s*[–—]\s*|\s+-+\s+")


def parse_heading(raw: str) -> dict:
    """Split ``'INT. ASHBURY MANOR - DRAWING ROOM - CONTINUOUS'`` into parts."""
    raw = re.sub(r"\s+#[\w.\-]+#\s*$", "", raw.strip())          # strip "#12#" scene numbers
    out = {"int_ext": None, "location": None, "location_base": None, "time_of_day": None}
    m = _RE_HEADING.match(raw)
    rest = m.group("rest") if m else raw.lstrip(".")
    if m:
        ie = re.sub(r"[^A-Z/]", "", m.group("ie").upper())
        out["int_ext"] = {"I/E": "INT/EXT", "INT/EXT": "INT/EXT", "EXT/INT": "INT/EXT"}.get(ie, ie)
    parts = [p.strip() for p in _RE_HEAD_SEP.split(rest) if p.strip()]
    if len(parts) > 1 and parts[-1].upper() in _TOD:
        out["time_of_day"] = parts[-1].upper()
        parts = parts[:-1]
    if parts:
        out["location"] = " - ".join(parts).upper()
        out["location_base"] = parts[0].upper()
    return out


# =============================================================================
# 3. Cue parsing  (speaker label + parentheticals)
# =============================================================================
_RE_PAREN = re.compile(r"\(([^()]*)\)")
_RE_TONE_SPLIT = re.compile(r"\s*(?:[,;/&]|\band\b)\s*", re.I)


def _is_modifier(token: str) -> bool:
    return re.sub(r"[^A-Z]", "", token.upper()) in CUE_MODIFIERS


def split_parentheticals(fragment: str) -> tuple[str, tuple, tuple]:
    """``'JULIANA (V.O.) (Whispering, tearful)'`` -> ``('JULIANA', ('whispering','tearful'), ('V.O.',))``

    Handles several parentheticals on one cue and an *unclosed* trailing one
    (a line wrapped mid-parenthetical), which is closed implicitly.
    """
    s = re.sub(r"\s+", " ", fragment).strip()
    if s.count("(") > s.count(")"):          # unbalanced -> close it
        s += ")" * (s.count("(") - s.count(")"))
    tones, mods = [], []
    for inner in _RE_PAREN.findall(s):
        inner = inner.strip()
        if not inner:
            continue
        if _is_modifier(inner):
            mods.append(inner.upper())
            continue
        for tok in _RE_TONE_SPLIT.split(inner):
            tok = tok.strip(" .").lower()
            if not tok:
                continue
            (mods if _is_modifier(tok) else tones).append(tok.upper() if _is_modifier(tok) else tok)
    label = _RE_PAREN.sub("", s).strip(" :")
    label = re.sub(r"\s+", " ", label)
    return label, tuple(tones), tuple(mods)


def classify_label(label: str) -> str:
    """Return the element kind for a block label (``DIALOGUE`` for any character)."""
    return NON_SPEAKER_LABELS.get(label.strip().upper(), DIALOGUE)


def clean_dialogue(text: str) -> tuple[str, tuple]:
    """Strip wrapping quotes and pull inline stage directions out of speech.

    ``'"Fine. (sighs) Go."'`` -> ``('Fine. Go.', ('sighs',))``
    """
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) >= 2 and text[0] == '"' and text[-1] == '"':
        text = text[1:-1].strip()
    inline = tuple(t.strip().lower() for t in _RE_PAREN.findall(text) if t.strip())
    text = re.sub(r"\s+", " ", _RE_PAREN.sub("", text)).strip()
    return text, inline


# =============================================================================
# 4. Dialect detection
# =============================================================================
_RE_CUE_LINE = re.compile(r"^\s*\*\*(.+?)\s*:?\*\*\s*:?\s*$")
_RE_TIMING = re.compile(
    rf"^\s*START\s*:?\s*\(?\s*(?P<s>{_TS})\s*\)?\s*(?:[|,;\-–]\s*)?"
    rf"(?:END\s*:?\s*\(?\s*(?P<e>{_TS})\s*\)?)?\s*$", re.I)


def detect_dialect(text: str) -> str:
    """``'timestamped'`` if bold cues followed by Start/End lines are found, else ``'fountain'``."""
    cues = timings = 0
    for line in text.split("\n", 400)[:400]:
        cues += bool(_RE_CUE_LINE.match(line))
        timings += bool(_RE_TIMING.match(line))
    return "timestamped" if cues >= 2 and timings >= 2 else "fountain"


# =============================================================================
# 5. Timestamped dialect
# =============================================================================
_RE_SCENE_NO = re.compile(r"^\s*SCENE\s+(\d+)\s*$", re.I)
_RE_KV = re.compile(
    r"^\s*(SCENE\s+HEADING|SCENE\s+START|SCENE\s+END|EPISODE\s+NUMBER|EPISODE\s+LOGLINE|"
    r"CONTINUITY\s+NOTES|ACTIONS?\s+AND\s+DIALOGUE)\s*:\s*(.*?)\s*$", re.I)
_RE_MARK = re.compile(r"^\s*-{2,}\s*SCRIPT\s+(START|END)\s*-{2,}\s*$", re.I)


def _parse_timestamped(text: str, source: str, episode_hint: Optional[int]) -> Episode:
    ep = Episode(number=episode_hint or 0, source=source, dialect="timestamped")
    scene: Optional[Scene] = None
    cur: Optional[dict] = None          # the block currently being accumulated
    header_field: Optional[str] = None  # which header field continuation lines belong to
    order = 0
    last_end = 0.0
    lines = text.split("\n")
    n = len(lines)

    def issue(line_no: int, sev: str, code: str, msg: str) -> None:
        ep.issues.append(ParseIssue(ep.number, line_no, sev, code, msg))

    def ensure_scene(line_no: int) -> Scene:
        nonlocal scene
        if scene is None:
            scene = Scene(episode=ep.number, scene_no=0)
            ep.scenes.append(scene)
            issue(line_no, "warning", "implicit_scene", "content before first SCENE marker")
        return scene

    def flush_block() -> None:
        nonlocal cur, order, last_end
        if cur is None:
            return
        c, cur = cur, None
        body = " ".join(c["text"]).strip()
        if not body:
            issue(c["line"], "warning", "empty_block", f"block '{c['label']}' has no text")
            return
        kind = classify_label(c["label"])
        tone, speaker = c["tone"], None
        if kind == DIALOGUE:
            body, inline = clean_dialogue(body)
            tone = tone + inline
            speaker = c["label"].upper()
            if not speaker:
                issue(c["line"], "warning", "empty_speaker", "dialogue block without a speaker")
                return
        else:
            body = re.sub(r"\s+", " ", body)
        start, end = c["start"], c["end"]
        if start is None:                         # missing timing: pin to previous end
            start = last_end
            issue(c["line"], "warning", "missing_timing", f"'{c['label']}' block has no Start/End")
        if end is None:
            end = start
        if end < start:
            issue(c["line"], "warning", "negative_duration", f"end<start ({end}<{start}); swapped")
            start, end = end, start
        last_end = max(last_end, end)
        sc = ensure_scene(c["line"])
        sc.elements.append(Element(
            episode=ep.number, scene_no=sc.scene_no, order=order, kind=kind,
            speaker_raw=speaker, tone=tone, modifiers=c["mods"], start=start, end=end, text=body))
        order += 1

    i = 0
    while i < n:
        raw = lines[i]
        line_no = i + 1
        stripped = raw.strip()
        i += 1
        if not stripped:
            continue

        mark = _RE_MARK.match(stripped)
        if mark:
            flush_block()
            if mark.group(1).upper() == "END":
                break
            header_field = None
            continue

        m_scene = _RE_SCENE_NO.match(stripped)
        if m_scene:
            flush_block()
            scene = Scene(episode=ep.number, scene_no=int(m_scene.group(1)))
            ep.scenes.append(scene)
            header_field = None
            continue

        m_kv = _RE_KV.match(stripped)
        if m_kv and cur is None:
            key = re.sub(r"\s+", " ", m_kv.group(1).upper())
            val = m_kv.group(2)
            header_field = None
            if key == "EPISODE NUMBER":
                num = re.search(r"\d+", val)
                if num and not episode_hint:
                    ep.number = int(num.group())
            elif key == "EPISODE LOGLINE":
                ep.logline, header_field = val, "logline"
            elif key == "CONTINUITY NOTES":
                ep.continuity, header_field = val, "continuity"
            elif key == "SCENE HEADING":
                ensure_scene(line_no).__setattr__("heading_raw", val)
                for k, v in parse_heading(val).items():
                    setattr(scene, k, v)
            elif key == "SCENE START":
                ensure_scene(line_no).start = parse_ts(val)
            elif key == "SCENE END":
                ensure_scene(line_no).end = parse_ts(val)
            continue

        # ---- block cue (possibly wrapped over several lines) ----------------
        if stripped.startswith("**"):
            joined, consumed = stripped, 0
            while not _RE_CUE_LINE.match(joined) and consumed < 3 and i + consumed < n \
                    and "**" not in joined[2:]:
                consumed += 1
                joined += " " + lines[i + consumed - 1].strip()
            m_cue = _RE_CUE_LINE.match(joined)
            if m_cue:
                flush_block()
                i += consumed
                label, tone, mods = split_parentheticals(m_cue.group(1))
                cur = {"label": label, "tone": tone, "mods": mods, "start": None,
                       "end": None, "text": [], "line": line_no, "timed": False}
                continue

        # ---- timing line ----------------------------------------------------
        if cur is not None and not cur["timed"]:
            m_t = _RE_TIMING.match(stripped)
            if m_t:
                cur["start"] = parse_ts(m_t.group("s"))
                cur["end"] = parse_ts(m_t.group("e")) if m_t.group("e") else None
                cur["timed"] = True
                continue

        # ---- free text ------------------------------------------------------
        if cur is not None:
            cur["text"].append(stripped)
        elif header_field == "logline":
            ep.logline += " " + stripped
        elif header_field == "continuity":
            ep.continuity += " " + stripped
        else:
            issue(line_no, "info", "orphan_text", f"unattached line: {stripped[:60]!r}")

    flush_block()
    _finalize_scenes(ep, issue)
    return ep


def _finalize_scenes(ep: Episode, issue) -> None:
    """Fill / validate scene boundaries from the elements they contain."""
    prev_end = 0.0
    for sc in ep.scenes:
        if not sc.heading_raw:
            issue(0, "warning", "missing_heading", f"scene {sc.scene_no} has no heading")
        if sc.elements:
            lo = min(e.start for e in sc.elements)
            hi = max(e.end for e in sc.elements)
        else:
            lo = hi = None
            issue(0, "warning", "empty_scene", f"scene {sc.scene_no} has no elements")
        if sc.start is None:
            sc.start = lo if lo is not None else prev_end
            issue(0, "info", "derived_scene_start", f"scene {sc.scene_no} start derived from content")
        if sc.end is None:
            sc.end = hi if hi is not None else sc.start
            issue(0, "info", "derived_scene_end", f"scene {sc.scene_no} end derived from content")
        if hi is not None and hi > sc.end + 1.0:
            issue(0, "warning", "element_outside_scene",
                  f"scene {sc.scene_no}: content runs {hi - sc.end:.1f}s past declared end")
        if sc.start < prev_end - 0.05:
            issue(0, "info", "scene_overlap", f"scene {sc.scene_no} starts before previous ends")
        prev_end = max(prev_end, sc.end)


# =============================================================================
# 6. Fountain / classic dialect
# =============================================================================
_RE_SLUG = re.compile(
    r"^\s*(?:\.(?=[A-Za-z])|(?:INT\.?\s*/\s*EXT\.?|EXT\.?\s*/\s*INT\.?|I\s*/\s*E\.?|INT\.?|EXT\.?|EST\.?)[\s.]\s*\S)", re.I)
_RE_TRANSITION = re.compile(r"^\s*(?:>.*|[A-Z ]+TO:|FADE (?:IN|OUT)[.:]?|FADE TO BLACK\.?|CUT TO BLACK\.?|THE END\.?)\s*$")
_RE_CHAR_CUE = re.compile(r"^\s*@?(?P<body>[A-Z][A-Z0-9 .'\-]{0,38}?(?:\s*\([^)]*\))*)\s*\^?\s*$")
_RE_TITLE_PAGE = re.compile(r"^(?:Title|Credit|Author|Authors|Source|Draft date|Contact|Copyright|Notes?)\s*:", re.I)
_WPS_SPEECH, _WPS_ACTION = 2.7, 3.2        # estimated words per second


def _parse_fountain(text: str, source: str, episode_hint: Optional[int]) -> Episode:
    ep = Episode(number=episode_hint or 0, source=source, dialect="fountain")
    lines = text.split("\n")
    n = len(lines)
    scene: Optional[Scene] = None
    clock, order, scene_no = 0.0, 0, 0

    def issue(line_no, sev, code, msg):
        ep.issues.append(ParseIssue(ep.number, line_no, sev, code, msg))

    def new_scene(heading: str) -> Scene:
        nonlocal scene, scene_no
        scene_no += 1
        scene = Scene(episode=ep.number, scene_no=scene_no, heading_raw=heading, start=clock)
        for k, v in parse_heading(heading).items():
            setattr(scene, k, v)
        ep.scenes.append(scene)
        return scene

    def add(kind, body, speaker=None, tone=(), mods=()):
        nonlocal clock, order
        if scene is None:
            new_scene("")
            issue(0, "warning", "implicit_scene", "content before first slugline")
        words = count_words(body)
        dur = max(0.8, words / (_WPS_SPEECH if kind == DIALOGUE else _WPS_ACTION))
        scene.elements.append(Element(
            episode=ep.number, scene_no=scene.scene_no, order=order, kind=kind,
            speaker_raw=speaker, tone=tuple(tone), modifiers=tuple(mods),
            start=round(clock, 2), end=round(clock + dur, 2), text=body, time_estimated=True))
        clock += dur
        order += 1

    i = 0
    while i < n:
        stripped = lines[i].strip()
        prev_blank = i == 0 or not lines[i - 1].strip()
        nxt = lines[i + 1].strip() if i + 1 < n else ""
        if not stripped:
            i += 1
            continue
        if scene is None and _RE_TITLE_PAGE.match(stripped):     # "Title: ...", "Credit: ..." before 1st slugline
            i += 1
            continue
        if _RE_SLUG.match(stripped):
            if scene is not None:
                scene.end = clock
            new_scene(stripped.lstrip("."))
            i += 1
            continue
        if _RE_TRANSITION.match(stripped) and prev_blank:
            i += 1
            continue
        if prev_blank and nxt and not _RE_SLUG.match(nxt) and (
                stripped.startswith("@") or (_RE_CHAR_CUE.match(stripped) and stripped == stripped.upper()
                                             and any(c.isalpha() for c in stripped))):
            label, tone, mods = split_parentheticals(stripped.lstrip("@").rstrip("^ "))
            i += 1
            speech: list[str] = []
            while i < n and lines[i].strip():
                seg = lines[i].strip()
                if seg.startswith("("):               # parenthetical, possibly multi-line
                    buf = seg
                    while ")" not in buf and i + 1 < n and lines[i + 1].strip():
                        i += 1
                        buf += " " + lines[i].strip()
                    _, t2, m2 = split_parentheticals(buf)        # "(V.O.)" -> modifier, "(whispering)" -> tone
                    tone, mods = tone + t2, mods + m2
                else:
                    speech.append(seg)
                i += 1
            body, inline = clean_dialogue(" ".join(speech))
            if body:
                add(DIALOGUE, body, speaker=label.upper(), tone=tone + inline, mods=mods)
            else:
                issue(i, "warning", "empty_dialogue", f"cue {label!r} without speech")
            continue
        block = []
        while i < n and lines[i].strip() and not _RE_SLUG.match(lines[i]):
            block.append(lines[i].strip())
            i += 1
        add(ACTION, re.sub(r"\s+", " ", " ".join(block)))
    if scene is not None:
        scene.end = clock
    return ep


# =============================================================================
# 7. Public API
# =============================================================================
def parse_text(text: str, source: str = "", episode_hint: Optional[int] = None,
               dialect: str = "auto") -> Episode:
    """Parse one episode's raw text into an :class:`Episode`.

    Parameters
    ----------
    text:
        Raw script text (any newline convention, BOM tolerated).
    source:
        File name; used in reports and to infer the episode number when the
        header lacks one.
    episode_hint:
        Overrides the episode number found in the header (useful for stable
        numbering when files are named ``episode-007-...``).
    dialect:
        ``"auto"`` (default), ``"timestamped"`` or ``"fountain"``.
    """
    text = normalize_text(text)
    if dialect == "auto":
        dialect = detect_dialect(text)
    parser = _parse_timestamped if dialect == "timestamped" else _parse_fountain
    ep = parser(text, source, episode_hint)
    if not ep.number:
        m = re.search(r"(\d+)", source)
        ep.number = int(m.group(1)) if m else 0
        for s in ep.scenes:
            s.episode = ep.number
            for e in s.elements:
                e.episode = ep.number
    return ep


_RE_FILE_EP = re.compile(r"episode[-_ ]?0*(\d+)", re.I)


def episode_number_from_filename(name: str) -> Optional[int]:
    m = _RE_FILE_EP.search(name)
    return int(m.group(1)) if m else None


# =============================================================================
# 8. DataFrame conversion
# =============================================================================
def episodes_to_frames(episodes: Iterable[Episode]) -> dict[str, pd.DataFrame]:
    """Flatten parsed episodes into four tidy tables.

    Returns a dict with ``elements``, ``scenes``, ``episodes`` and ``issues``.
    ``scenes.tod_effective`` resolves ``CONTINUOUS`` headings by inheriting the
    previous scene's time of day.
    """
    el_rows, sc_rows, ep_rows, is_rows = [], [], [], []
    for ep in sorted(episodes, key=lambda e: e.number):
        last_tod = None
        n_sc = len(ep.scenes)
        for idx, sc in enumerate(ep.scenes):
            tod = sc.time_of_day
            continuous = tod in ("CONTINUOUS", "CONTINUOUS ACTION", "SAME", "SAME TIME", "LATER", "MOMENTS LATER")
            eff = last_tod if (continuous or tod is None) and last_tod else tod
            last_tod = eff if eff else last_tod
            sc_rows.append({
                "episode": ep.number, "scene_no": sc.scene_no, "scene_idx": idx,
                "rel_pos": idx / (n_sc - 1) if n_sc > 1 else 0.0,
                "heading_raw": sc.heading_raw, "int_ext": sc.int_ext, "location": sc.location,
                "location_base": sc.location_base, "time_of_day": tod, "tod_effective": eff,
                "is_continuous": bool(continuous), "start": sc.start, "end": sc.end,
                "duration": (sc.end - sc.start) if sc.end is not None and sc.start is not None else None,
            })
            for el in sc.elements:
                el_rows.append({
                    "episode": el.episode, "scene_no": el.scene_no, "scene_idx": idx, "order": el.order,
                    "kind": el.kind, "speaker_raw": el.speaker_raw, "tone": "|".join(el.tone),
                    "modifiers": "|".join(el.modifiers), "start": el.start, "end": el.end,
                    "duration": el.end - el.start, "text": el.text, "n_words": count_words(el.text),
                    "time_estimated": el.time_estimated, "sent_text": el.sent_text,
                    "sent_tone": el.sent_tone, "sent": el.sent, "emotion": el.emotion,
                })
        ep_rows.append({
            "episode": ep.number, "source": ep.source, "dialect": ep.dialect, "logline": ep.logline.strip(),
            "continuity": ep.continuity.strip(), "n_scenes": n_sc,
            "runtime": max((s.end or 0) for s in ep.scenes) if ep.scenes else 0.0,
            "n_issues": len(ep.issues),
        })
        is_rows += [{"episode": ep.number, "line_no": x.line_no, "severity": x.severity,
                     "code": x.code, "message": x.message} for x in ep.issues]
    elements = pd.DataFrame(el_rows)
    for col in ("kind", "speaker_raw"):
        if col in elements:
            elements[col] = elements[col].astype("category")
    return {"elements": elements, "scenes": pd.DataFrame(sc_rows), "episodes": pd.DataFrame(ep_rows),
            "issues": pd.DataFrame(is_rows, columns=["episode", "line_no", "severity", "code", "message"])}
