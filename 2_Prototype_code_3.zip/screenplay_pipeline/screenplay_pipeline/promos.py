"""Promo finder - picks 20-60 s promos (one stretch *or* stitched moments) that pull new viewers in.

A good promo (per the brief) (1) opens on a **hook** in its first ~3 s, (2) ends on a
**cliffhanger**, (3) **makes sense on its own**.  Everything is computed from signals the pipeline
already extracts (timestamps, per-block sentiment, delivery tags, emotion) plus the script's own
CAMERA / SOUND FX / ACTION notes, then ranked and de-duplicated.  Optionally an LLM re-ranks the
shortlist through the provider interface in :mod:`screenplay_pipeline.providers`.

Method
------
1. **Single-stretch candidates**: every dialogue/action block start x lengths 20..60 s; the end
   snaps to the last block that finishes inside the length, so clips never cut mid-line.
2. **Multi-segment candidates (stitching)**: a strong *opening* segment (6-35 s) joined, in order,
   to a strong *closing* segment from a later, non-contiguous moment of the same episode or of the
   next ``cross_span`` episodes; total still 20-60 s.  Pairs need shared characters so the join is
   coherent, and a small ``stitch_penalty`` keeps a plain contiguous clip ahead when it is as good.
3. **Hard stand-alone gate** (:mod:`screenplay_pipeline.standalone`): clips cannot open on a dangling
   conjunction, a mid-sentence fragment, an unresolved pronoun, a one/two-word reply, or a line that
   leans on earlier events.  Rejections are counted and reported.
4. **Scores** (each 0..1):
   ``hook``        first-3-s jolt = (1-visual_share) x text arousal (|sentiment|, high-arousal emotion,
                   ! ? reveal words) + visual_share x the strongest CAMERA/SOUND/ACTION note overlapping
                   those 3 s (tight insert, slap, explosion ... see :mod:`screenplay_pipeline.visual`)
   ``cliffhanger``  end intensity + unanswered question / cut-off line + reaches the episode's own
                   final block + a strong visual/sound beat in the last ~6 s
   ``drama``       mean intensity + emotional range (something *changes*)
   ``standalone``  two speakers in conflict beat one; >=4 is confusing; episodes whose continuity notes
                   say they pick up mid-story are discounted
5. **Total** = weighted sum x mild length preference (35-45 s best); weights in :class:`PromoConfig`.
6. **Selection**: best-first, drop promos overlapping an already chosen one by > 30 % (across all their
   segments), keep up to ``max_per_episode`` per home episode, then rank globally.

Limits (also in the write-up): no video, so "visual" means the script's written shot description, not
pixels; the stand-alone gate removes *detectable* dependencies only; stitched cross-episode promos are
judged coherent by shared characters, not by understanding the plot.  A human editor stays the final
gate: the output is a *shortlist*.
"""
from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .models import ACTION, DIALOGUE
from .standalone import check_opening, name_tokens
from .visual import VISUAL_KINDS, add_visual_columns

HIGH_AROUSAL = {"anger", "fear", "shock", "contempt"}
HOOK_WORDS = ("secret", "pregnan", "poison", "arsenic", "duke", "traitor", "lie", "betray", "dead", "kill",
              "murder", "proof", "truth", "never forgive", "slap", "divorce", "mercy", "guilty", "arrest",
              "wedding", "married", "heir", "blood")


@dataclass
class PromoConfig:
    lengths: tuple = (20, 25, 30, 35, 40, 45, 50, 55, 60)
    min_len: float = 20.0
    max_len: float = 60.0
    hook_window: float = 3.0
    end_window: float = 6.0
    weights: dict = field(default_factory=lambda: {"hook": 0.30, "cliffhanger": 0.30, "drama": 0.20, "standalone": 0.20})
    max_per_episode: int = 2
    max_overlap: float = 0.30
    visual_share: float = 0.40          # share of the hook score that comes from camera/sound/action notes
    strict_standalone: bool = True      # hard gate (see standalone.py)
    strict_ending: bool = True          # a promo must end on an open or charged beat, never a neutral line
    end_charge: float = 0.45            # minimum arousal / visual score for a non-question ending
    # --- multi-segment stitching -------------------------------------------------------------
    stitch: bool = True
    seg_lengths: tuple = (8, 10, 12, 15, 18, 22, 26, 30)
    seg_min: float = 6.0
    seg_max: float = 35.0
    pool_hooks: int = 6                 # best opening starts kept per episode
    pool_cliffs: int = 6                # best closing ends kept per episode
    min_gap: float = 1.5                # seconds between segments, else it is just a contiguous clip
    stitch_penalty: float = 0.05        # a stitched promo must beat a contiguous one by this much
    cross_episode: bool = True
    cross_span: int = 2                 # closing segment may come from the next N episodes
    wave_sizes: tuple = (10, 30)        # posts in wave 1 and wave 2; everything after is wave 3
    spacing: int = 2                    # no promo from the same home episode within this many posts of each other
    min_topic_in: int = 1               # distinctive words two joined segments must share (same episode)
    min_topic_cross: int = 2            # ... and across episodes (characters alone are not a plot link)


def _arousal(text: str, sent: float, emotion, tone_hit: bool = False) -> float:
    """How jolting a block is.  Negative polarity counts fully, positive only 0.4x: a tender or
    relieved moment is not a scroll-stopper (first manual review caught warm actions ranked as hooks)."""
    t = (text or "").lower()
    s = sent if pd.notna(sent) else 0.0
    a = max(-s, 0.0) + 0.4 * max(s, 0.0)
    a += 0.25 if emotion in HIGH_AROUSAL else 0.0
    a += 0.15 if "!" in t else 0.0
    a += 0.10 if "?" in t else 0.0
    a += 0.20 if any(w in t for w in HOOK_WORDS) else 0.0
    return float(min(1.0, a))


def _mid_thought(text: str) -> bool:
    """True when a line starts mid-sentence ("...and killing my wife"): confusing as an opener."""
    t = (text or "").lstrip()
    return t.startswith(("...", "…")) or (bool(t) and t[0].islower())


def _open_end(text: str) -> float:
    t = (text or "").strip()
    if t.endswith(("?", "—", "-", "...", "…")):
        return 1.0
    return 0.5 if t.endswith("!") else 0.0


_RESOLVED = re.compile(
    r"\b(reassur\w*|peaceful\w*|warm\w*|tender\w*|gentl\w*|smil\w+|embrac\w+|hand[- ]in[- ]hand|side by side|sunlight|relie[fv]\w*|"
    r"content\w*|comfort\w*|unspoken bond|bond\w* (?:forming|between)|gaze[sd]? (?:deeply|lovingly|warmly)|adoring\w*|affection\w*|"
    r"calm\w*|serene\w*|at peace|safe(?:ly)?|home at last|together at last)\b", re.I)


def _ending(text: str, kind: str, aro_j: float, vis_j: float, vis_end: float, charge: float, sent_j: float = 0.0) -> str | None:
    """Classify how a candidate ends, or return None when it ends neutrally or *resolved* (a settled line, scene-setting
    action, a bare camera hold, or a warm/reassuring beat).  Only open or charged-with-tension endings may close a promo:
    a tender or positive final beat leaves nothing hanging, however strongly it is shot."""
    t = (text or "").strip()
    if kind == DIALOGUE:
        if t.endswith("?"):
            return "open question"
        if t.endswith(("\u2014", "-", "...", "\u2026")):
            return "cut-off line"
        if sent_j > 0.15:
            return None
        if aro_j >= charge or (t.endswith("!") and aro_j >= 0.3):
            return "charged line"
    else:
        if sent_j > 0.15 or _RESOLVED.search(t):
            return None
        if max(aro_j, vis_j) >= charge:
            return "charged action"
    return "charged shot" if (vis_end >= 0.6 and sent_j <= 0.0 and not _RESOLVED.search(t)) else None


def _fmt(sec: float) -> str:
    return f"{int(sec // 60):02d}:{sec % 60:04.1f}"


def _speaker_score(n: int) -> float:
    return {0: 0.1, 1: 0.35, 2: 1.0, 3: 0.8}.get(n, 0.5)


# --------------------------------------------------------------------------------- candidates
def _prep(gall: pd.DataFrame) -> dict | None:
    """One-time numpy view of an episode (shared by the single-clip and stitch-segment passes)."""
    g = gall[gall["kind"].astype(str).isin([DIALOGUE, ACTION])].reset_index(drop=True)
    if len(g) < 3:
        return None
    kind = g["kind"].astype(str).to_numpy()
    sent = g["sent"].fillna(0.0).to_numpy(float)
    text = g["text"].fillna("").tolist()
    emo = g["emotion"].tolist()
    aro = np.array([_arousal(t, x, e) * (0.8 if k == ACTION else 1.0) for t, x, e, k in zip(text, sent, emo, kind)])
    vm = gall["kind"].astype(str).isin(VISUAL_KINDS).to_numpy()
    return {"g": g, "vis": g["vis"].to_numpy(float), "start": g["start"].to_numpy(float), "end": g["end"].to_numpy(float), "kind": kind, "sent": sent,
            "text": text, "emo": emo, "spk": g["speaker"].fillna("").tolist(), "aro": aro,
            "vs": gall["start"].to_numpy(float)[vm], "ve": gall["end"].to_numpy(float)[vm], "vv": gall["vis"].to_numpy(float)[vm],
            "vt": gall["text"].fillna("").to_numpy()[vm], "vtag": gall["vis_tags"].fillna("").to_numpy()[vm],
            "vkind": gall["kind"].astype(str).to_numpy()[vm], "dlg": np.flatnonzero(kind == DIALOGUE),
            "toks": [frozenset(w for w in _TOK.findall(t.lower().replace("'s", "")) if w not in _STOP) if k == DIALOGUE else frozenset()
                     for t, k in zip(text, kind)]}


def _pool(ep: int, P: dict, dependent: bool, cfg: PromoConfig, lengths, min_len: float, max_len: float,
          names: set, stats: Counter | None) -> list[dict]:
    """All contiguous candidate segments of one prepared episode (see :func:`_prep`)."""
    g, start, end, kind, sent = P["g"], P["start"], P["end"], P["kind"], P["sent"]
    text, emo, spk, aro = P["text"], P["emo"], P["spk"], P["aro"]
    vs, ve, vv, vt, vtag, vkind, dlg_idx = P["vs"], P["ve"], P["vv"], P["vt"], P["vtag"], P["vkind"], P["dlg"]
    last_idx = len(g) - 1
    out, seen = [], set()
    for i in range(len(g)):
        if kind[i] != DIALOGUE and aro[i] < 0.5:          # don't open on quiet scene-setting
            continue
        t0 = start[i]
        # --- visual hook: notes overlapping the opening window ---------------------------------
        m = (ve > t0 - 0.3) & (vs < t0 + cfg.hook_window)
        if m.any():
            k_best = int(np.flatnonzero(m)[np.argmax(vv[m])])
            hook_vis, vis_note = float(vv[k_best]), (str(vkind[k_best]), str(vt[k_best]), str(vtag[k_best]))
        else:
            hook_vis, vis_note = 0.0, None
        # --- hard stand-alone gate on the opening ----------------------------------------------
        if cfg.strict_standalone:
            lead = " ".join(vt[(ve > t0 - 0.3) & (vs < t0 + 4.0)])
            nxt = dlg_idx[dlg_idx >= i][:3]
            verdict = check_opening([text[x] for x in nxt], lead, names, strong_visual=hook_vis >= 0.6)
            if not verdict.ok:
                if stats is not None:
                    stats["candidate_starts_rejected"] += 1
                    for r in verdict.reasons:
                        stats[r] += 1
                continue
        if stats is not None:
            stats["candidate_starts_kept"] += 1
        for L in lengths:
            j = int(np.searchsorted(end, t0 + L, side="right")) - 1
            if j <= i or (i, j) in seen:
                continue
            dur = end[j] - t0
            if not (min_len <= dur <= max_len):
                continue
            seen.add((i, j))
            mt = (ve > end[j] - 3.0) & (vs < end[j])
            end_type = _ending(text[j], kind[j], aro[j], P["vis"][j], float(vv[mt].max()) if mt.any() else 0.0, cfg.end_charge, float(sent[j]))
            if cfg.strict_ending and end_type is None:
                if stats is not None:
                    stats["ending_neutral"] += 1
                continue
            first = start[i:j + 1] < t0 + cfg.hook_window            # blocks that start inside the hook window
            a_win = aro[i:j + 1] * first
            hook_text = 0.7 * float(a_win.max()) + 0.3 * float(aro[i])
            hook = (1 - cfg.visual_share) * hook_text + cfg.visual_share * hook_vis
            tail = end[i:j + 1] > end[j] - cfg.end_window
            tail_int = float(np.abs(sent[i:j + 1][tail]).mean())
            mt = (ve > end[j] - cfg.end_window) & (vs < end[j])
            vis_tail = float(vv[mt].max()) if mt.any() else 0.0
            cliff = (0.30 * min(1.0, tail_int / 0.5) + 0.25 * _open_end(text[j])
                     + 0.25 * float(j == last_idx) + 0.20 * vis_tail)
            s = sent[i:j + 1]
            drama = 0.5 * min(1.0, 2 * float(np.abs(s).mean())) + 0.5 * min(1.0, float(s.max() - s.min()) / 1.2)
            speakers = frozenset(x for x, k in zip(spk[i:j + 1], kind[i:j + 1]) if k == DIALOGUE and x)
            stand = _speaker_score(len(speakers))
            if dependent:
                stand *= 0.85
            w = cfg.weights
            total = w["hook"] * hook + w["cliffhanger"] * cliff + w["drama"] * drama + w["standalone"] * stand
            total *= 1 - 0.15 * min(1.0, abs(dur - 40) / 20)
            out.append({"episode": ep, "i": i, "j": j, "start": float(t0), "end": float(end[j]), "duration": float(dur),
                        "score": float(total), "hook_score": hook, "hook_text": hook_text, "hook_visual": hook_vis,
                        "cliffhanger_score": cliff, "drama_score": drama, "standalone_score": stand,
                        "speakers": speakers, "ends_episode": j == last_idx, "vis_note": vis_note,
                        "vis_tail": vis_tail, "end_type": end_type or "neutral", "peak": i + int(np.argmax(a_win)), "_g": g, "_toks": P["toks"]})
    return out


_STOP = frozenset("""about above after again against almost already always another anyone anything around because
been before being below between both could doing during either enough every everyone everything first from
going great having herself himself indeed instead itself little maybe might myself never nothing other
ought please quite rather really right shall should since something still such taken than that their theirs
them then there these they think this those though through today tonight under until upon very want wanted
were what when where whether which while whom whose will with within without would your yours yourself
understand remember believe heard sorry thank thanks years year again once only just like know said
""".split())
_TOK = re.compile(r"[a-z]{5,}")


def _topic(seg: dict, drop: frozenset) -> frozenset:
    """Distinctive spoken content words of a segment, names and filler removed (spoken words only:
    action prose repeats generic stage vocabulary and would create false links)."""
    if "_topic" not in seg:
        seg["_topic"] = frozenset().union(*seg["_toks"][seg["i"]:seg["j"] + 1]) - drop
    return seg["_topic"]


def _overlap(a: list[tuple], b: list[tuple]) -> float:
    """Seconds of overlap between two lists of (episode, start, end) segments."""
    tot = 0.0
    for ea, sa, xa in a:
        for eb, sb, xb in b:
            if ea == eb:
                tot += max(0.0, min(xa, xb) - max(sa, sb))
    return tot


def _single(c: dict) -> dict:
    return {**c, "kind": "single", "segs": [c], "episodes": (c["episode"],), "total_dur": c["duration"],
            "spans": [(c["episode"], c["start"], c["end"])]}


def _stitch(a: dict, b: dict, cfg: PromoConfig, drop: frozenset = frozenset()) -> dict | None:
    """Join an opening segment *a* to a closing segment *b* (b later in time).  None if incoherent:
    they need shared characters AND shared distinctive words (a topical thread), more of both across episodes."""
    cross = a["episode"] != b["episode"]
    shared = len(a["speakers"] & b["speakers"])
    need = min(2, len(a["speakers"]), len(b["speakers"])) if cross else 1
    if shared < max(need, 1):
        return None
    topic = len(_topic(a, drop) & _topic(b, drop))
    if topic < (cfg.min_topic_cross if cross else cfg.min_topic_in):
        return None
    dur = a["duration"] + b["duration"]
    if not (cfg.min_len <= dur <= cfg.max_len):
        return None
    w = cfg.weights
    drama = (a["drama_score"] * a["duration"] + b["drama_score"] * b["duration"]) / dur
    coherence = 0.6 + 0.4 * min(1.0, shared / 2)
    stand = min(a["standalone_score"], b["standalone_score"]) * coherence * (0.9 if cross else 1.0)
    total = (w["hook"] * a["hook_score"] + w["cliffhanger"] * b["cliffhanger_score"] + w["drama"] * drama
             + w["standalone"] * stand)
    total *= 1 - 0.15 * min(1.0, abs(dur - 40) / 20)
    total -= cfg.stitch_penalty
    return {"kind": "stitched-cross-episode" if cross else "stitched-in-episode", "episode": a["episode"],
            "episodes": tuple(dict.fromkeys((a["episode"], b["episode"]))), "segs": [a, b], "score": float(total),
            "hook_score": a["hook_score"], "hook_text": a["hook_text"], "hook_visual": a["hook_visual"],
            "cliffhanger_score": b["cliffhanger_score"], "drama_score": drama, "standalone_score": stand,
            "ends_episode": b["ends_episode"], "total_dur": dur, "shared": sorted(a["speakers"] & b["speakers"]),
            "topic": sorted(_topic(a, drop) & _topic(b, drop)),
            "spans": [(a["episode"], a["start"], a["end"]), (b["episode"], b["start"], b["end"])]}


def _pools(cands: list[dict], cfg: PromoConfig) -> tuple[list[dict], list[dict]]:
    """Opening-role and closing-role segments for stitching (best starts / best ends only)."""
    if not cands:
        return [], []
    by_start: dict[int, list[dict]] = {}
    for c in cands:
        by_start.setdefault(c["i"], []).append(c)
    top_starts = sorted(by_start, key=lambda i: -max(x["hook_score"] for x in by_start[i]))[:cfg.pool_hooks]
    openers = [c for i in top_starts for c in by_start[i] if c["duration"] <= 30]
    by_end: dict[int, list[dict]] = {}
    for c in cands:
        by_end.setdefault(c["j"], []).append(c)
    top_ends = sorted(by_end, key=lambda j: -max(x["cliffhanger_score"] for x in by_end[j]))[:cfg.pool_cliffs]
    closers = [max(by_end[j], key=lambda x: x["cliffhanger_score"] * (0.5 + 0.5 * x["standalone_score"]) + 0.3 * x["drama_score"])
               for j in top_ends]
    closers += [max(by_end[j], key=lambda x: -x["duration"]) for j in top_ends]       # and a short variant of each ending
    return openers, closers


# --------------------------------------------------------------------------------- explanations
def _hook_text(c: dict) -> str:
    g, i, j = c["_g"], c["i"], c["j"]
    h = g.loc[c["peak"]]
    who = h["speaker"] if isinstance(h["speaker"], str) and h["speaker"] else "ACTION"
    tone = f" ({h['tone'].replace('|', ', ')})" if isinstance(h["tone"], str) and h["tone"] else ""
    return f'{who}{tone}: "{str(h["text"])[:110]}"'


_END_LABEL = {"open question": "unanswered question", "cut-off line": "cut-off line", "charged line": "charged final line",
              "charged action": "charged final action", "charged shot": "charged final shot"}
_END_EFFECT = {
    "open question": "ends on an unanswered question, so viewers tap through to the next episode for the answer",
    "cut-off line": "cuts off mid-thought, so viewers need the next part to finish it",
    "charged line": "ends on a charged line with nothing resolved, so viewers stay for what happens next",
    "charged action": "freezes on a tense beat with nothing resolved, so viewers want the follow-up",
    "charged shot": "holds on a loaded shot with nothing resolved, so viewers want the follow-up",
}


def _hook_kind(emotion, text: str, vis_tags: str, vis: float) -> str:
    """Plain-English name for what the first seconds show, used in the one-line rationale."""
    tg, t = vis_tags or "", (text or "").lower()
    if vis >= 0.5 and "impact: strike" in tg:
        return "a physical blow"
    if vis >= 0.5 and ("impact:" in tg or "weapon" in tg):
        return "violence on screen"
    if vis >= 0.4 and "shock reaction" in tg:
        return "a shocked reaction shot"
    if vis >= 0.5 and "tight insert" in tg:
        return "an extreme close-up of raw emotion"
    if any(w in t for w in HOOK_WORDS) and ("?" in t or "!" in t):
        return "a loaded accusation"
    if emotion in ("anger", "contempt"):
        return "an open confrontation"
    if emotion in ("fear", "shock"):
        return "a moment of fear"
    if emotion in ("sadness",):
        return "a heartbroken plea"
    return "a jolt of emotion"


def _explain(p: dict) -> dict:
    a, b = p["segs"][0], p["segs"][-1]
    hook = _hook_text(a)
    note = a["vis_note"]
    visual = f'{note[0]} [{note[2]}]: {note[1][:110]}' if note and a["hook_visual"] >= 0.3 else ""
    last = b["_g"].loc[b["j"]]
    lw = str(last["text"]).strip()
    kind = _END_LABEL.get(b["end_type"], "charged final beat")
    if p["ends_episode"]:
        kind = "episode-ending cliffhanger (" + kind + ")"
    cliff = f'{kind}: "{lw[:110]}"'
    # --- mechanical signals (kept for audit) -----------------------------------------------------
    sig = []
    if a["hook_text"] >= 0.7:
        sig.append("strong opening jolt in the dialogue")
    if a["hook_visual"] >= 0.5:
        sig.append("visual hook (" + note[2].split(",")[0] + ")")
    if p["ends_episode"]:
        sig.append("cuts where the show itself ends the episode")
    elif b["cliffhanger_score"] >= 0.5:
        sig.append("ends on a high-tension beat")
    if p["kind"] == "single" and len(a["speakers"]) == 2:
        sig.append("clear two-person conflict")
    if p["drama_score"] >= 0.6:
        sig.append("big emotional swing")
    if p["kind"] != "single":
        sh = ", ".join(s.title() for s in p["shared"][:2])
        where = "later in the episode" if p["kind"] == "stitched-in-episode" else f"from episode {b['episode']}"
        sig.append(f"stitched: opening beat + payoff {where}, same characters ({sh}), shared thread: {', '.join(p['topic'][:3])}")
    # --- the viewer-facing one-liner ----------------------------------------------------------------
    h = a["_g"].loc[a["peak"]]
    hk = _hook_kind(h["emotion"], str(h["text"]), note[2] if note else "", a["hook_visual"])
    stakes = ("two people in open conflict keep them watching" if p["kind"] == "single" and len(a["speakers"]) == 2
              else "a big emotional swing keeps them watching" if p["drama_score"] >= 0.6 else "")
    parts = [f"Opens on {hk} inside 3 s, so a scroller stops"]
    if p["kind"] != "single":
        parts.append("two beats of one thread, condensed under a minute")
    if stakes:
        parts.append(stakes)
    parts.append(_END_EFFECT.get(b["end_type"], "ends with tension unresolved") + (" (the show's own cut)" if p["ends_episode"] else ""))
    why = "; ".join(parts) + "."
    return {"hook": hook, "visual_hook": visual, "cliffhanger": cliff, "why_it_works": why,
            "signals": "; ".join(sig) or "balanced hook / tension / clarity", "hook_kind": hk}


def _opening_line(a: dict) -> str:
    g = a["_g"]
    d = g.loc[a["i"]:a["j"]]
    d = d[d["kind"].astype(str) == DIALOGUE]
    return str(d["text"].iloc[0])[:110] if len(d) else ""


# --------------------------------------------------------------------------------- posting plan
_STRENGTH = {"hook_score": "highest hooking power", "cliffhanger_score": "strongest pull toward the next episode",
             "drama_score": "biggest emotional swing", "standalone_score": "easiest for a brand-new viewer to follow"}


def plan_posting(promos: pd.DataFrame, cfg: PromoConfig | None = None) -> pd.DataFrame:
    """Add ``post_order``, ``wave`` and ``post_reason``.  ``rank`` stays the quality ranking; ``post_order`` is the
    schedule: quality order, except that two promos from one episode are never posted within ``spacing`` slots of
    each other (a feed of one episode back-to-back reads as repetition and splits the audience's attention).
    Wave 1 = the lead posts (highest hooking power / stakes), wave 2 = steady follow-ups, wave 3 = backfill."""
    cfg = cfg or PromoConfig()
    if promos.empty:
        return promos
    p = promos.sort_values("rank").reset_index(drop=True).copy()
    remaining, order, held, recent = list(p.index), [], set(), []
    while remaining:
        pick = next((i for i in remaining if not ({p.at[i, "episode"]} & set(recent[-cfg.spacing:]) if cfg.spacing else False)),
                    remaining[0])
        if pick != remaining[0]:
            held.add(remaining[0])                           # the better promo was pushed back to keep the feed varied
        remaining.remove(pick)
        order.append(pick)
        recent.append(p.at[pick, "episode"])
    p["post_order"] = 0
    for n, i in enumerate(order, 1):
        p.at[i, "post_order"] = n
    w1, w2 = cfg.wave_sizes
    p["wave"] = np.where(p["post_order"] <= w1, 1, np.where(p["post_order"] <= w1 + w2, 2, 3))
    means = {c: float(p[c].mean()) for c in _STRENGTH}
    reasons = []
    for r in p.itertuples():
        best = max(_STRENGTH, key=lambda c: getattr(r, c) - means[c])
        what = f"{_STRENGTH[best]} ({getattr(r, best):.2f} vs {means[best]:.2f} average)"
        end = _END_LABEL.get(r.end_type, "an open ending")
        lead = {1: "Lead wave - post first", 2: "Steady follow-up", 3: "Backfill - post after the stronger ones"}[int(r.wave)]
        extra = " Held back a slot so the feed does not repeat an episode." if r.Index in held else ""
        reasons.append(f"{lead}: {what}; opens on {getattr(r, 'hook_kind', 'an emotional jolt')}, ends on {end}.{extra}")
    p["post_reason"] = reasons
    return p.sort_values("rank").reset_index(drop=True)


# --------------------------------------------------------------------------------- main entry
def find_promos(elements: pd.DataFrame, episodes: pd.DataFrame, cfg: PromoConfig | None = None) -> pd.DataFrame:
    """Return a ranked promo shortlist (one row per promo; see columns below).

    ``result.attrs["filter_stats"]`` holds the stand-alone gate's rejection counts."""
    cfg = cfg or PromoConfig()
    if "vis" not in elements.columns:
        elements = add_visual_columns(elements)
    dep = {int(r.episode): str(r.continuity).lower().startswith(("picks up", "follows", "continues", "immediately"))
           for r in episodes.itertuples()}
    stats: Counter = Counter()
    frames = {int(ep): g.sort_values("order").reset_index(drop=True) for ep, g in elements.groupby("episode", sort=True)}
    names = {ep: name_tokens(g["speaker"].dropna().unique()) for ep, g in frames.items()}
    drop = frozenset().union(*names.values()) if names else frozenset()
    if len(frames) >= 10:                       # words found in >25 % of episodes are generic to the show, not a topic
        df = Counter(w for g in frames.values() for w in set(_TOK.findall(" ".join(g["text"].fillna("").astype(str)).lower())))
        drop = drop | frozenset(w for w, n in df.items() if n > 0.25 * len(frames))
    def nms(cands: list[dict], cap: int) -> list[dict]:
        """Best-first non-maximum suppression across all of a promo's segments."""
        kept: list[dict] = []
        for c in sorted(cands, key=lambda c: -c["score"]):
            if len(kept) >= cap:
                break
            if all(_overlap(c["spans"], k["spans"]) <= cfg.max_overlap * min(c["total_dur"], k["total_dur"]) for k in kept):
                kept.append(c)
        return kept

    cap = cfg.max_per_episode * 3                              # a few spares for the global pass
    singles: dict[int, list[dict]] = {}                        # pass 1: per-episode candidates, trimmed straight away
    openers: dict[int, list[dict]] = {}
    closers: dict[int, list[dict]] = {}
    for ep, g in frames.items():
        P = _prep(g)
        if P is None:
            singles[ep] = []
            continue
        found = _pool(ep, P, dep.get(ep, False), cfg, cfg.lengths, cfg.min_len, cfg.max_len, names[ep], stats)
        singles[ep] = [_single(c) for c in sorted(found, key=lambda c: -c["score"])[:150]]     # bounded memory, same greedy result
        if cfg.stitch:
            seg = _pool(ep, P, dep.get(ep, False), cfg, cfg.seg_lengths, cfg.seg_min, cfg.seg_max, names[ep], None)
            openers[ep], closers[ep] = _pools(seg, cfg)
    eps = sorted(frames)
    pool: list[dict] = []                                      # pass 2: add stitched pairs (they may reach into later episodes)
    for ep in eps:
        cands = list(singles[ep])
        if cfg.stitch:
            targets = [ep] + ([e for e in eps if ep < e <= ep + cfg.cross_span] if cfg.cross_episode else [])
            for a in openers.get(ep, []):
                for te in targets:
                    for b in closers.get(te, []):
                        if te == ep and b["start"] < a["end"] + cfg.min_gap:
                            continue
                        st = _stitch(a, b, cfg, drop)
                        if st:
                            cands.append(st)
        pool += nms(cands, cap)
    chosen: list[dict] = []
    home: Counter = Counter()
    for c in sorted(pool, key=lambda c: -c["score"]):
        if home[c["episode"]] >= cfg.max_per_episode:
            continue
        if all(_overlap(c["spans"], k["spans"]) <= cfg.max_overlap * min(c["total_dur"], k["total_dur"]) for k in chosen):
            chosen.append(c)
            home[c["episode"]] += 1
    rows = []
    for c in sorted(chosen, key=lambda c: -c["score"]):
        ex = _explain(c)
        spans = c["spans"]
        rows.append({"rank": len(rows) + 1, "episode": c["episode"], "episodes": "+".join(str(e) for e in c["episodes"]),
                     "kind": c["kind"], "n_segments": len(spans),
                     "segment_start": round(spans[0][1], 2), "segment_end": round(spans[-1][2], 2),
                     "start_ts": _fmt(spans[0][1]), "end_ts": _fmt(spans[-1][2]),
                     "timestamps": " | ".join(f"ep{e} {_fmt(s)}-{_fmt(x)}" for e, s, x in spans),
                     "duration_s": round(c["total_dur"], 1), "score": round(c["score"], 3),
                     "hook": ex["hook"], "visual_hook": ex["visual_hook"], "cliffhanger": ex["cliffhanger"],
                     "why_it_works": ex["why_it_works"], "end_type": c["segs"][-1]["end_type"],
                     "signals": ex["signals"], "hook_kind": ex["hook_kind"], "opening_line": _opening_line(c["segs"][0]),
                     "hook_score": round(c["hook_score"], 3), "hook_text_score": round(c["hook_text"], 3),
                     "hook_visual_score": round(c["hook_visual"], 3), "cliffhanger_score": round(c["cliffhanger_score"], 3),
                     "drama_score": round(c["drama_score"], 3), "standalone_score": round(c["standalone_score"], 3),
                     "segments_json": json.dumps([{"episode": e, "start": round(s, 2), "end": round(x, 2)} for e, s, x in spans])})
    out = plan_posting(pd.DataFrame(rows), cfg)
    out.attrs["filter_stats"] = dict(stats)
    return out


def promo_transcript(promo: pd.Series | dict, elements: pd.DataFrame) -> tuple[str, str]:
    """(spoken transcript, shot notes) for a promo row, segment by segment, in order."""
    segs = json.loads(promo["segments_json"])
    talk, notes = [], []
    for n, s in enumerate(segs, 1):
        e = elements[(elements["episode"] == s["episode"]) & (elements["end"] > s["start"]) & (elements["start"] < s["end"])]
        e = e.sort_values(["start", "order"])
        head = f"[segment {n}: ep{s['episode']} {_fmt(s['start'])}-{_fmt(s['end'])}]"
        talk.append(head)
        notes.append(head)
        for r in e.itertuples():
            if r.kind == DIALOGUE:
                talk.append(f"{_fmt(r.start)} {r.speaker or '?'}: {r.text}")
            elif r.kind in VISUAL_KINDS:
                notes.append(f"{_fmt(r.start)} {r.kind}: {r.text}")
    return "\n".join(talk), "\n".join(notes)


def write_promo_report(path, promos: pd.DataFrame, top: int = 15) -> None:
    from .metrics import md_table
    fs = promos.attrs.get("filter_stats", {})
    kinds = promos["kind"].value_counts().to_dict() if len(promos) else {}
    L = ["# Promo shortlist", "",
         f"{len(promos)} promos (max 2 per home episode). `rank` is the quality ranking; `post_order` is the posting schedule "
         "(quality order, with no two promos from one episode back-to-back). **A human editor confirms each clip before it posts.**", "",
         "Mix: " + ", ".join(f"{v} {k}" for k, v in kinds.items()) + ".", ""]
    if fs:
        rej = {k: v for k, v in fs.items() if k not in ("candidate_starts_kept", "candidate_starts_rejected", "ending_neutral")}
        L += ["Stand-alone gate: " + f"{fs.get('candidate_starts_rejected', 0)} of "
              f"{fs.get('candidate_starts_rejected', 0) + fs.get('candidate_starts_kept', 0)} possible opening blocks rejected "
              "(" + ", ".join(f"{k} {v}" for k, v in sorted(rej.items(), key=lambda kv: -kv[1])) + ").",
              f"Ending gate: {fs.get('ending_neutral', 0)} candidate endings rejected for being neutral (resolved line, scene-setting "
              "action or a bare camera hold); every promo ends on " + ", ".join(
                  f"{v} x {k}" for k, v in promos["end_type"].value_counts().items()) + ".", ""]
    by_post = promos.sort_values("post_order")
    L += ["## Posting plan", "",
          "Wave 1 is the lead posts (highest hooking power and stakes), wave 2 steady follow-ups, wave 3 backfill.", ""]
    for w, label in ((1, "Wave 1 - lead posts"), (2, "Wave 2 - steady follow-ups"), (3, "Wave 3 - backfill")):
        g = by_post[by_post["wave"] == w]
        if g.empty:
            continue
        L += [f"### {label} ({len(g)} promos, post #{int(g.post_order.min())}-{int(g.post_order.max())})", ""]
        if w == 1:
            for r in g.itertuples():
                when = f"{r.start_ts} -> {r.end_ts}" if r.n_segments == 1 else r.timestamps
                L += [f"{r.post_order}. **Ep {r.episodes}, {when}** (rank {r.rank}) - {r.post_reason}"]
            L += [""]
        else:
            L += [md_table(g[["post_order", "rank", "episodes", "timestamps", "duration_s", "score"]]), ""]
    L += ["## Details for the first posts", ""]
    for r in by_post.head(top).itertuples():
        when = f"{r.start_ts} -> {r.end_ts}" if r.n_segments == 1 else r.timestamps
        L += [f"### Post #{r.post_order} (rank {r.rank}) - {'Episode ' + r.episodes if r.n_segments == 1 else 'Episodes ' + r.episodes}, "
              f"{when} ({r.duration_s}s, score {r.score}, {r.kind})",
              f"- **Why it works:** {r.why_it_works}", f"- **Hook:** {r.hook}"]
        if r.visual_hook:
            L.append(f"- **Visual hook:** {r.visual_hook}")
        L += [f"- **Cliffhanger:** {r.cliffhanger}", f"- **Signals:** {r.signals}", f"- **Why post here:** {r.post_reason}", ""]
    cols = ["post_order", "wave", "rank", "episodes", "timestamps", "kind", "end_type", "duration_s", "score", "hook_score",
            "cliffhanger_score", "drama_score", "standalone_score"]
    L += ["## Full ranking", "", md_table(promos.sort_values("post_order")[cols])]
    path.write_text("\n".join(L) + "\n", encoding="utf-8")
