"""Static charts (PNG) for the report.

Colour roles follow one rule set: a single hue for magnitude (blue ramp), a
blue <-> orange diverging pair with a neutral midpoint for polarity
(orange = negative, blue = positive), and categorical slots 1-3 in fixed order
(blue, orange, aqua) for identity.  Text always uses neutral ink, never the
series colour.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap

SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
DIVERGING = LinearSegmentedColormap.from_list("polarity", [ORANGE, "#e9e8e4", BLUE])
SEQUENTIAL = LinearSegmentedColormap.from_list("magnitude", ["#eef4fc", BLUE, "#0f3d75"])

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "axes.edgecolor": GRID, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "text.color": INK, "axes.titlecolor": INK, "axes.titleweight": "bold", "axes.titlesize": 12,
    "axes.titlelocation": "left", "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8,
    "axes.spines.top": False, "axes.spines.right": False, "font.size": 10, "legend.frameon": False,
})


def _save(fig, path: Path) -> Path:
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_series_arc(episodes: pd.DataFrame, path: Path) -> Path:
    """Episode-level sentiment (top) and emotional intensity (bottom) across the series."""
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(10, 6), sharex=True, height_ratios=[3, 2])
    x = episodes["episode"]
    a1.axhline(0, color=INK2, lw=0.8)
    a1.plot(x, episodes["mean_sentiment"], color=BLUE, lw=2, marker="o", ms=5, label="Mean sentiment")
    roll = episodes["mean_sentiment"].rolling(5, center=True, min_periods=2).mean()
    a1.plot(x, roll, color=ORANGE, lw=2, label="5-episode trend")
    a1.set_ylabel("Sentiment (−1 … +1)")
    a1.set_title("Series emotional arc")
    a1.legend(loc="upper right")
    a2.bar(x, episodes["mean_intensity"], color=BLUE, width=0.7)
    a2.set_ylabel("Intensity (|sentiment|)")
    a2.set_xlabel("Episode")
    a2.set_title("How emotionally loaded each episode is")
    return _save(fig, path)


def plot_beat_heatmap(beats: pd.DataFrame, path: Path) -> Path:
    """Episodes (rows) x relative position in episode (columns), coloured by beat sentiment."""
    bins = 12
    sc = beats.dropna(subset=["sentiment"]).copy()
    sc["col"] = np.minimum((sc["rel_pos"] * bins).astype(int), bins - 1)
    grid = sc.pivot_table(index="episode", columns="col", values="sentiment", aggfunc="mean")
    grid = grid.reindex(columns=range(bins))
    fig, ax = plt.subplots(figsize=(8, 0.17 * len(grid) + 1.6))
    lim = max(0.3, float(np.nanmax(np.abs(grid.to_numpy()))))
    im = ax.imshow(grid.to_numpy(), aspect="auto", cmap=DIVERGING, vmin=-lim, vmax=lim)
    ax.set_yticks(range(len(grid)))
    ax.set_yticklabels(grid.index, fontsize=7)
    ax.set_xticks([0, bins - 1])
    ax.set_xticklabels(["start of episode", "end of episode"])
    ax.grid(False)
    ax.set_title("Where each episode turns dark or hopeful")
    cb = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02)
    cb.set_label("Sentiment")
    return _save(fig, path)


def plot_mood_transitions(beats: pd.DataFrame, path: Path) -> Path:
    """Row-normalised mood -> next-mood probability matrix with counts annotated."""
    t = beats.dropna(subset=["prev_mood"])
    moods = [m for m in pd.unique(pd.concat([t["prev_mood"], t["dominant_mood"]])) if isinstance(m, str)]
    moods = sorted(moods, key=lambda m: -(t["prev_mood"].eq(m).sum() + t["dominant_mood"].eq(m).sum()))
    cnt = pd.crosstab(t["prev_mood"], t["dominant_mood"]).reindex(index=moods, columns=moods, fill_value=0)
    prob = cnt.div(cnt.sum(axis=1).replace(0, np.nan), axis=0)
    fig, ax = plt.subplots(figsize=(7.2, 6))
    im = ax.imshow(prob.to_numpy(), cmap=SEQUENTIAL, vmin=0, vmax=max(0.5, float(np.nanmax(prob.to_numpy()))))
    ax.set_xticks(range(len(moods)), moods, rotation=40, ha="right")
    ax.set_yticks(range(len(moods)), moods)
    ax.set_xlabel("Next beat's mood")
    ax.set_ylabel("This beat's mood")
    ax.grid(False)
    for i in range(len(moods)):
        for j in range(len(moods)):
            n = cnt.iat[i, j]
            if n:
                dark = prob.iat[i, j] > 0.35
                ax.text(j, i, str(n), ha="center", va="center", fontsize=8, color="white" if dark else INK)
    ax.set_title("Mood transitions between consecutive 10-second beats")
    fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02).set_label("Share of transitions from this mood")
    return _save(fig, path)


def plot_network(G: nx.Graph, communities: dict, path: Path, top_n: int = 18) -> Path:
    """Co-presence network of the *top_n* most connected characters."""
    keep = sorted(G.nodes, key=lambda n: -G.degree(n, weight="weight"))[:top_n]
    H = G.subgraph(keep)
    fig, ax = plt.subplots(figsize=(9, 7))
    ax.axis("off")
    if H.number_of_nodes() == 0:
        return _save(fig, path)
    pos = nx.spring_layout(H, weight="weight", seed=7, k=1.4 / np.sqrt(max(H.number_of_nodes(), 1)))
    w = np.array([H[u][v]["weight"] for u, v in H.edges]) if H.number_of_edges() else np.array([1])
    nx.draw_networkx_edges(H, pos, ax=ax, edge_color="#b8b7b0", width=0.6 + 4.5 * w / w.max())
    palette = [BLUE, ORANGE, AQUA]
    colors = [palette[communities.get(n, 0) % 3] for n in H.nodes]
    sizes = [120 + 38 * H.nodes[n].get("lines", 1) ** 0.75 for n in H.nodes]
    nx.draw_networkx_nodes(H, pos, ax=ax, node_color=colors, node_size=sizes, edgecolors=SURFACE, linewidths=2)
    nx.draw_networkx_labels(H, pos, ax=ax, font_size=8, font_color=INK,
                            labels={n: n.title() for n in H.nodes},
                            bbox=dict(boxstyle="round,pad=0.15", fc=SURFACE, ec="none", alpha=0.85))
    ax.set_title("Who shares scenes with whom (node size = lines spoken, colour = community)")
    return _save(fig, path)


def plot_pacing(episodes: pd.DataFrame, path: Path) -> Path:
    """Dialogue share of story words and cutting rate per episode (two panels, no dual axis)."""
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(10, 5.5), sharex=True)
    x = episodes["episode"]
    a1.bar(x, episodes["dialogue_word_share"] * 100, color=BLUE, width=0.7)
    a1.set_ylabel("Dialogue share of words (%)")
    a1.set_title("Dialogue vs. action balance")
    a2.bar(x, episodes["shots_per_min"], color=AQUA, width=0.7)
    a2.set_ylabel("Camera cuts per minute")
    a2.set_xlabel("Episode")
    a2.set_title("Cutting rate")
    return _save(fig, path)


def plot_episode_timeline(elements: pd.DataFrame, scenes: pd.DataFrame, episode: int, path: Path,
                          bin_seconds: float = 5.0) -> Path:
    """Second-by-second feel of one episode: sentiment line over shaded scene spans."""
    el = elements[(elements["episode"] == episode) & elements["sent"].notna()]
    sc = scenes[scenes["episode"] == episode]
    t = (el["start"] + el["end"]) / 2
    tl = el.assign(bin=(t // bin_seconds) * bin_seconds).groupby("bin")["sent"].mean()
    fig, ax = plt.subplots(figsize=(10, 3.8))
    for i, r in enumerate(sc.itertuples()):
        if i % 2 == 0:
            ax.axvspan(r.start, r.end, color="#efeeea", lw=0)
        ax.text((r.start + r.end) / 2, 1.02, str(r.scene_no), ha="center", va="bottom", fontsize=8, color=INK2,
                transform=ax.get_xaxis_transform())
    ax.axhline(0, color=INK2, lw=0.8)
    ax.plot(tl.index + bin_seconds / 2, tl.values, color=BLUE, lw=2, marker="o", ms=4)
    ax.set_xlabel("Seconds into episode")
    ax.set_ylabel("Sentiment")
    ax.set_title(f"Episode {episode} sentiment timeline (scene numbers on top)", pad=18)
    return _save(fig, path)


def make_all(out_dir: Path, *, episodes, scenes, beats, elements, graph, centrality, timeline_episode: Optional[int] = None) -> list[Path]:
    fig_dir = Path(out_dir) / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)
    comm = dict(zip(centrality["character"], centrality["community"])) if len(centrality) else {}
    paths = [
        plot_series_arc(episodes, fig_dir / "series_arc.png"),
        plot_beat_heatmap(beats, fig_dir / "beat_sentiment_heatmap.png"),
        plot_mood_transitions(beats, fig_dir / "mood_transitions.png"),
        plot_network(graph, comm, fig_dir / "character_network.png"),
        plot_pacing(episodes, fig_dir / "pacing.png"),
    ]
    ep = timeline_episode if timeline_episode is not None else int(episodes["episode"].iloc[0])
    paths.append(plot_episode_timeline(elements, scenes, ep, fig_dir / f"episode_{ep:03d}_timeline.png"))
    return paths
