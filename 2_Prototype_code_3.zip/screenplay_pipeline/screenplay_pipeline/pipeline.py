"""End-to-end orchestration:

    Ingest -> Parse (A) -> Score (C-element) -> Resolve characters -> Network (B)
           -> Aggregate sentiment / arcs (C) -> Metrics & export (D) -> Charts

Parse + element scoring run **per episode in a process pool** (episodes are
independent; the stages that need the whole corpus - character resolution,
network, arcs - run once afterwards on columnar DataFrames).
"""
from __future__ import annotations

import dataclasses

import time
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pandas as pd

from . import metrics, network, promos as promo_mod, providers, sentiment, viz
from .characters import CharacterResolver, MentionDetector, load_alias_rules
from .ingest import decode_bytes, iter_sources
from .models import DIALOGUE, Episode
from .parser import episode_number_from_filename, episodes_to_frames, parse_text
from .sentiment import Lexicon, ScoringConfig

_PKG_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_ALIASES = _PKG_ROOT / "config" / "aliases.json"
DEFAULT_LEXICON = _PKG_ROOT / "config" / "lexicon.json"


@dataclass
class PipelineConfig:
    input_path: str
    output_dir: str = "output"
    backend: str = "vader"
    backend_kwargs: dict = field(default_factory=dict)
    aliases_path: Optional[str] = str(DEFAULT_ALIASES)
    lexicon_path: Optional[str] = str(DEFAULT_LEXICON)
    workers: Optional[int] = None          # None -> min(cpu, files); 1 -> serial
    episodes: Optional[set] = None
    min_mention_lines: int = 3
    find_promos: bool = True
    promo_config: Optional[promo_mod.PromoConfig] = None       # stitching, visual share, stand-alone gate ...
    rerank_provider: Optional[str] = None                      # None / "rules" = no model; see providers.py
    rerank_kwargs: dict = field(default_factory=dict)          # model, base_url, api_key_env, cache_dir ...
    rerank_shortlist: int = 4                                  # candidates per episode shown to the model
    rerank_blend: float = 0.5                                  # weight of the model's verdict in the final score
    beat_seconds: float = 10.0
    make_figures: bool = True
    scoring: ScoringConfig = field(default_factory=ScoringConfig)


# --- worker (top-level so it pickles) -----------------------------------------
_WORKER_CACHE: dict = {}


def _process_source(args) -> Episode:
    name, raw, backend, backend_kwargs, lexicon_path, scoring = args
    key = (backend, lexicon_path, tuple(sorted(backend_kwargs.items())))
    if key not in _WORKER_CACHE:                 # build the scorer once per process
        lex = Lexicon.load(lexicon_path)
        _WORKER_CACHE[key] = (sentiment.make_backend(backend, lex, **backend_kwargs), lex)
    be, lex = _WORKER_CACHE[key]
    ep = parse_text(decode_bytes(raw), source=name, episode_hint=episode_number_from_filename(name))
    return sentiment.score_episode(ep, be, lex, scoring)


def _process_chunk(args) -> dict:
    """Parse + score a *chunk* of files and return compact DataFrames.

    Returning columnar frames (a handful of buffers) instead of ~100k small
    ``Element`` objects makes the inter-process transfer ~an order of magnitude
    cheaper - measured: pickling objects made 2 workers *slower* than 1.
    """
    chunk, backend, kwargs, lexicon_path, scoring = args
    frames = episodes_to_frames([_process_source((n, b, backend, kwargs, lexicon_path, scoring)) for n, b in chunk])
    frames["elements"] = frames["elements"].astype({"kind": object, "speaker_raw": object})
    return frames


def _chunks(items: list, n: int) -> list:
    size = max(1, -(-len(items) // n))
    return [items[i:i + size] for i in range(0, len(items), size)]


def run_pipeline(cfg: PipelineConfig) -> dict:
    """Run everything and write outputs; returns the in-memory tables and summary."""
    t0 = time.perf_counter()
    stages: dict = {}
    _mark = [t0]

    def tick(name: str) -> None:
        now = time.perf_counter()
        stages[name] = round(now - _mark[0], 2)
        _mark[0] = now

    out = Path(cfg.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # ---- 1-3. ingest, parse, score (parallel per episode) ---------------------
    sources = list(iter_sources(cfg.input_path, cfg.episodes))
    if not sources:
        raise SystemExit(f"no script files found under {cfg.input_path}")
    import os
    workers = cfg.workers or min(os.cpu_count() or 1, len(sources))
    if cfg.backend != "vader":
        workers = 1                              # model backends batch internally; avoid N model copies
    n_chunks = workers * 4 if workers > 1 and len(sources) >= 8 else 1
    jobs = [(c, cfg.backend, cfg.backend_kwargs, cfg.lexicon_path, cfg.scoring) for c in _chunks(sources, n_chunks)]
    if n_chunks > 1:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            parts = list(pool.map(_process_chunk, jobs))
    else:
        parts = [_process_chunk(j) for j in jobs]
    tick("1_parse_and_score")

    frames = {k: pd.concat([p[k] for p in parts], ignore_index=True) for k in parts[0]}
    elements = frames["elements"].sort_values(["episode", "order"], kind="stable").reset_index(drop=True)
    elements = elements.astype({"kind": "category", "speaker_raw": "category"})
    scenes = frames["scenes"].sort_values(["episode", "scene_idx"]).reset_index(drop=True)
    eps_df = frames["episodes"].sort_values("episode").reset_index(drop=True)
    issues = frames["issues"]
    dup = eps_df[eps_df.duplicated("episode", keep=False)]
    if len(dup):                                 # two files claim the same episode number -> silent merge risk
        extra = pd.DataFrame({"episode": dup["episode"], "line_no": 0, "severity": "error",
                              "code": "duplicate_episode_number", "message": dup["source"]})
        issues = pd.concat([issues, extra], ignore_index=True)

    # ---- 4. characters ---------------------------------------------------------
    dlg = elements[elements["kind"].astype(str).eq(DIALOGUE)]
    raw_labels = dlg["speaker_raw"].astype(str)
    resolver = CharacterResolver(rules=load_alias_rules(cfg.aliases_path)).fit(raw_labels)
    elements = network.resolve_speakers(elements, resolver)
    detector = MentionDetector(resolver, Counter(raw_labels), cfg.min_mention_lines)

    tick("2_assemble_and_characters")
    # ---- 5. interaction network (Module B) ------------------------------------
    presence = network.build_presence(elements, detector)
    edges_ep, edges = network.build_edges(presence)
    exchanges = network.dialogue_exchanges(elements)
    node_lines = elements[elements["kind"].astype(str).eq(DIALOGUE)].groupby("speaker", observed=True).size()
    graph = network.build_graph(edges, node_lines)
    centrality = network.centrality_table(graph)

    tick("3_network")
    # ---- 6. sentiment & arcs (Module C) ---------------------------------------
    lex = Lexicon.load(cfg.lexicon_path)
    scenes_a = sentiment.analyze_scenes(elements, scenes, cfg.scoring)
    scenes_a = metrics.scene_metrics(elements, scenes_a)
    beats = sentiment.build_beats(elements, scenes_a, cfg.beat_seconds, cfg.scoring)
    eps_a = sentiment.analyze_episodes(beats, eps_df)
    eps_a = metrics.episode_metrics(elements, eps_a)
    transitions = sentiment.mood_transitions(beats)
    timeline = sentiment.sentiment_timeline(elements)
    coverage = sentiment.tone_coverage(elements, lex)

    tick("4_sentiment_aggregation_and_metrics")
    # ---- 7. metrics & export (Module D) ---------------------------------------
    characters = metrics.character_table(elements, presence, centrality)
    unresolved = resolver.unresolved_report()
    summary = metrics.build_summary(
        episodes=eps_a, scenes=scenes_a, beats=beats, elements=elements, characters=characters,
        transitions=transitions, issues=issues, coverage=coverage, backend=cfg.backend, unresolved=unresolved)
    tick("5_character_table_and_summary")

    tables = {
        "elements": elements.drop(columns=["text"]).assign(text=elements["text"]),
        "scenes": scenes_a, "beats": beats, "episodes": eps_a, "characters": characters,
        "character_edges_series": edges, "character_edges_by_episode": edges_ep,
        "scene_presence": presence, "dialogue_exchanges": exchanges, "mood_transitions": transitions,
        "sentiment_timeline": timeline, "parse_issues": issues,
        "unresolved_labels": pd.DataFrame(unresolved, columns=["label", "lines"]),
        "tone_tag_coverage": coverage,
    }
    figs = []
    if cfg.make_figures:
        figs = viz.make_all(out, episodes=eps_a, scenes=scenes_a, beats=beats, elements=elements, graph=graph,
                            centrality=centrality)
    tick("6_figures")
    if cfg.find_promos:
        pcfg = cfg.promo_config or promo_mod.PromoConfig()
        provider = providers.make_provider(cfg.rerank_provider, **cfg.rerank_kwargs) if cfg.rerank_provider else None
        if provider is None:
            promos = promo_mod.find_promos(elements, eps_a, pcfg)
        else:                                    # model judges a wider shortlist, then we keep the best per episode
            wide = promo_mod.find_promos(elements, eps_a, dataclasses.replace(pcfg, max_per_episode=cfg.rerank_shortlist))
            promos = providers.rerank_promos(wide, elements, provider, blend=cfg.rerank_blend,
                                             keep_per_episode=pcfg.max_per_episode)
            summary["rerank"] = {"provider": promos.attrs.get("provider"), "judged": promos.attrs.get("judged"),
                                 "shortlist": int(len(wide)), "provider_errors": promos.attrs.get("provider_errors")}
        tables["promos"] = promos
        summary["promo_filter_stats"] = promos.attrs.get("filter_stats", {})
        summary["promo_kinds"] = promos["kind"].value_counts().to_dict() if len(promos) else {}
        promo_mod.write_promo_report(out / "PROMOS.md", promos)
        summary["n_promos"] = int(len(promos))
    tick("7_promos")
    summary["runtime_seconds"] = {**stages, "total": round(time.perf_counter() - t0, 2)}
    metrics.export_tables(out, tables, summary)
    metrics.write_report(out / "REPORT.md", summary, eps_a, characters, scenes_a)
    return {"summary": summary, "tables": tables, "figures": figs, "graph": graph, "resolver": resolver}
