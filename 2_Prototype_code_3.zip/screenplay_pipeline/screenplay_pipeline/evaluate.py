"""Human-in-the-loop quality check for the sentiment model.

    # 1. draw a blind sample (model scores are withheld so you are not anchored by them)
    python -m screenplay_pipeline.evaluate sample --elements output/data/elements.csv --n 80 --out eval/to_label.csv
    # 2. open eval/to_label.csv, fill the `label` column with -1 (negative), 0 (neutral) or 1 (positive)
    #    judging the line IN CONTEXT of the scene (and optionally `emotion_label`)
    # 3. score the model against your labels
    python -m screenplay_pipeline.evaluate score --labels eval/to_label.csv --elements output/data/elements.csv

Reports accuracy, macro-F1, Cohen's kappa, a confusion matrix, and the lines the model got most
wrong - the raw material for the "where does it fail" section of a write-up.
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

NEUTRAL_BAND = 0.15       # |score| below this counts as "neutral"


def to_class(score: pd.Series, band: float = NEUTRAL_BAND) -> pd.Series:
    return pd.Series(np.where(score > band, 1, np.where(score < -band, -1, 0)), index=score.index)


def draw_sample(elements: pd.DataFrame, n: int = 80, seed: int = 7, kinds=("DIALOGUE", "ACTION")) -> pd.DataFrame:
    """Random sample, stratified so dialogue and action are both represented; scores withheld."""
    pool = elements[elements["kind"].isin(kinds) & (elements["n_words"] >= 2)].reset_index(names="row_id")
    per = max(1, n // len(kinds))
    parts = [g.sample(min(per, len(g)), random_state=seed) for _, g in pool.groupby("kind")]
    s = pd.concat(parts).sort_values("row_id")
    s = s[["row_id", "episode", "scene_idx", "kind", "speaker", "tone", "text"]].copy()
    s["label"] = ""
    s["emotion_label"] = ""
    return s


def cohen_kappa(a: pd.Series, b: pd.Series) -> float:
    ct = pd.crosstab(a, b)
    labels = sorted(set(ct.index) | set(ct.columns))
    ct = ct.reindex(index=labels, columns=labels, fill_value=0).to_numpy(float)
    n = ct.sum()
    po = np.trace(ct) / n
    pe = (ct.sum(0) * ct.sum(1)).sum() / n ** 2
    return float((po - pe) / (1 - pe)) if pe < 1 else 1.0


def evaluate(labels: pd.DataFrame, elements: pd.DataFrame, band: float = NEUTRAL_BAND) -> dict:
    lab = labels[labels["label"].astype(str).str.strip() != ""].copy()
    lab["label"] = lab["label"].astype(int)
    m = lab.merge(elements[["sent", "emotion"]], left_on="row_id", right_index=True, how="left")
    m["pred"] = to_class(m["sent"], band)
    acc = float((m["pred"] == m["label"]).mean())
    f1s = []
    for c in (-1, 0, 1):
        tp = ((m.pred == c) & (m.label == c)).sum(); fp = ((m.pred == c) & (m.label != c)).sum()
        fn = ((m.pred != c) & (m.label == c)).sum()
        f1s.append(2 * tp / (2 * tp + fp + fn) if (2 * tp + fp + fn) else 0.0)
    out = {"n_labelled": len(m), "accuracy": acc, "macro_f1": float(np.mean(f1s)),
           "kappa": cohen_kappa(m["label"], m["pred"]),
           "confusion (rows=human, cols=model)": pd.crosstab(m["label"], m["pred"]),
           "worst_misses": m.assign(err=(m["sent"] - m["label"]).abs()).nlargest(8, "err")[
               ["kind", "speaker", "tone", "text", "label", "sent"]]}
    if "emotion_label" in m and (m["emotion_label"].astype(str).str.strip() != "").any():
        e = m[m["emotion_label"].astype(str).str.strip() != ""]
        out["emotion_accuracy"] = float((e["emotion_label"].str.lower() == e["emotion"]).mean())
    return out


def promo_sheet(promos: pd.DataFrame, k: int = 20, n_low: int = 10, seed: int = 7):
    """Blind review sheet for promo picks: the top *k* plus *n_low* lower-ranked clips, shuffled,
    with scores and rank withheld.  Returns ``(sheet, key)``; keep the key out of sight until scored."""
    top = promos.head(k)
    low = promos.iloc[k:].sample(min(n_low, max(len(promos) - k, 0)), random_state=seed)
    pool = pd.concat([top, low]).sample(frac=1, random_state=seed).reset_index(drop=True)
    pool["clip_id"] = [f"C{i + 1:02d}" for i in range(len(pool))]
    cols = ["clip_id", "episodes" if "episodes" in pool else "episode", "timestamps" if "timestamps" in pool else "start_ts"]
    cols += ["end_ts"] if "timestamps" not in pool else []
    cols += [c for c in ("kind", "duration_s", "hook", "visual_hook", "cliffhanger") if c in pool]
    sheet = pool[cols].copy()
    sheet["would_post"] = ""          # y / n  (watch the clip: would YOU post it?)
    sheet["hook_ok"] = ""             # y / n  (first 3 seconds stop a scroller?)
    sheet["cliffhanger_ok"] = ""      # y / n
    sheet["standalone_ok"] = ""       # y / n  (makes sense to a new viewer?)
    sheet["why_bad"] = ""
    return sheet, pool[["clip_id", "rank", "score"]]


def promo_precision(sheet: pd.DataFrame, key: pd.DataFrame, k: int = 20) -> dict:
    """Precision of the ranker: share of 'would post' = y among top-k vs. among lower-ranked clips."""
    m = sheet.merge(key, on="clip_id")
    m = m[m["would_post"].astype(str).str.strip().str.lower().isin(["y", "n"])]
    yes = m["would_post"].str.strip().str.lower().eq("y")
    top, low = m["rank"] <= k, m["rank"] > k
    out = {"n_reviewed": len(m), f"precision_top{k}": float(yes[top].mean()) if top.any() else None,
           "precision_lower_ranked": float(yes[low].mean()) if low.any() else None}
    for col in ("hook_ok", "cliffhanger_ok", "standalone_ok"):
        v = m[col].astype(str).str.strip().str.lower()
        if v.isin(["y", "n"]).any():
            out[f"{col}_rate"] = float(v.eq("y")[v.isin(["y", "n"])].mean())
    return out


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sample"); s.add_argument("--elements", required=True); s.add_argument("--n", type=int, default=80)
    s.add_argument("--seed", type=int, default=7); s.add_argument("--out", required=True)
    c = sub.add_parser("score"); c.add_argument("--labels", required=True); c.add_argument("--elements", required=True)
    c.add_argument("--band", type=float, default=NEUTRAL_BAND)
    ps = sub.add_parser("promo-sample", help="blind review sheet for promo picks")
    ps.add_argument("--promos", required=True); ps.add_argument("--out", required=True); ps.add_argument("--key", required=True)
    pc = sub.add_parser("promo-score", help="precision of the promo ranking from your y/n labels")
    pc.add_argument("--labels", required=True); pc.add_argument("--key", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "promo-sample":
        sheet, key = promo_sheet(pd.read_csv(a.promos))
        sheet.to_csv(a.out, index=False); key.to_csv(a.key, index=False)
        print(f"wrote {a.out} (fill would_post etc. with y/n) and {a.key} (don't open until scored)")
        return
    if a.cmd == "promo-score":
        print(promo_precision(pd.read_csv(a.labels), pd.read_csv(a.key)))
        return
    el = pd.read_csv(a.elements)
    if a.cmd == "sample":
        draw_sample(el, a.n, a.seed).to_csv(a.out, index=False)
        print(f"wrote {a.out}: fill the 'label' column with -1 / 0 / 1")
    else:
        r = evaluate(pd.read_csv(a.labels), el, a.band)
        for k, v in r.items():
            print(f"\n{k}:\n{v}" if isinstance(v, pd.DataFrame) else f"{k}: {v:.3f}" if isinstance(v, float) else f"{k}: {v}")


if __name__ == "__main__":
    main()
