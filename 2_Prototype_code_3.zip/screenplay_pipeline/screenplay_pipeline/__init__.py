"""Automated scene breakdown & sentiment analysis pipeline for episodic screenplays."""
from .parser import parse_text, episodes_to_frames          # Module A
from .pipeline import PipelineConfig, run_pipeline

__all__ = ["parse_text", "episodes_to_frames", "PipelineConfig", "run_pipeline"]
__version__ = "1.0.0"
