"""Module B - entity extraction & character interaction network.

Two complementary relationship signals are built from the parsed tables:

**Co-presence (undirected).**  Two characters are linked in a scene if both
are *present*: they speak, or the action / camera / sound text names them
("Juliana pauses ... as Gerald holds the Lady's hand").  Edge attributes:

``scenes_together``    scenes where both are present (speaking or shown)
``scenes_both_speak``  scenes where both actually have dialogue

**Dialogue exchange (directed).**  When speaker B talks directly after speaker
A inside the same scene we count an ``A -> B`` exchange.  This is a proxy for
"A addressed B" - cheap and transparent, but it cannot see who a line was
*meant* for in a 3+ person scene (documented limitation).
"""
from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations
from typing import Optional

import networkx as nx
import numpy as np
import pandas as pd

from .characters import CharacterResolver, MentionDetector
from .models import DIALOGUE


def resolve_speakers(elements: pd.DataFrame, resolver: CharacterResolver) -> pd.DataFrame:
    """Add a canonical ``speaker`` column (episode-aware alias resolution)."""
    out = elements.copy()
    kind = out["kind"].astype(str)
    raw = out["speaker_raw"].astype(object)
    is_d = kind.eq(DIALOGUE)
    pairs = set(zip(raw[is_d], out.loc[is_d, "episode"]))
    mapping = {(s, e): resolver.resolve(s, int(e)) for s, e in pairs}
    out["speaker"] = [mapping.get((s, e)) if d else None for s, e, d in zip(raw, out["episode"], is_d)]
    return out


def build_presence(elements: pd.DataFrame, detector: MentionDetector) -> pd.DataFrame:
    """One row per (episode, scene, character) with ``n_lines``, ``n_words``, ``n_mentions``, ``role``."""
    keys = ["episode", "scene_idx", "character"]
    d = elements[elements["kind"].astype(str).eq(DIALOGUE)]
    spoken = (d.groupby(["episode", "scene_idx", "speaker"], observed=True)
                .agg(n_lines=("order", "size"), n_words=("n_words", "sum")).reset_index()
                .rename(columns={"speaker": "character"}))
    nd = elements[~elements["kind"].astype(str).eq(DIALOGUE)]
    counts: Counter = Counter()
    for ep, si, text in zip(nd["episode"], nd["scene_idx"], nd["text"]):
        for name in detector.find(text):
            counts[(ep, si, name)] += 1
    mentioned = pd.DataFrame([(*k, v) for k, v in counts.items()], columns=keys + ["n_mentions"])
    pres = spoken.merge(mentioned, on=keys, how="outer")
    for col in ("n_lines", "n_words", "n_mentions"):
        pres[col] = pres[col].fillna(0).astype(int)
    pres["role"] = np.where(pres["n_lines"] > 0, "speaker", "mentioned")
    return pres.sort_values(keys).reset_index(drop=True)


def build_edges(presence: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return ``(edges_by_episode, edges_series)`` co-presence tables (``a < b`` alphabetically)."""
    acc: dict = defaultdict(lambda: [0, 0])
    for (ep, _), g in presence.groupby(["episode", "scene_idx"]):
        members = sorted(zip(g["character"], g["role"].eq("speaker")))
        for (a, sa), (b, sb) in combinations(members, 2):
            cell = acc[(ep, a, b)]
            cell[0] += 1
            cell[1] += int(sa and sb)
    cols = ["episode", "a", "b", "scenes_together", "scenes_both_speak"]
    by_ep = pd.DataFrame([(*k, *v) for k, v in acc.items()], columns=cols)
    series = (by_ep.groupby(["a", "b"], as_index=False)[["scenes_together", "scenes_both_speak"]].sum()
              if len(by_ep) else pd.DataFrame(columns=["a", "b", "scenes_together", "scenes_both_speak"]))
    return by_ep, series.sort_values("scenes_together", ascending=False).reset_index(drop=True)


def dialogue_exchanges(elements: pd.DataFrame) -> pd.DataFrame:
    """Directed turn-taking counts: ``src`` spoke, then ``dst`` answered, in the same scene."""
    d = elements[elements["kind"].astype(str).eq(DIALOGUE)].sort_values(["episode", "order"])
    prev = d.groupby(["episode", "scene_idx"])["speaker"].shift()
    m = prev.notna() & (prev != d["speaker"])
    ex = pd.DataFrame({"src": prev[m], "dst": d.loc[m, "speaker"]})
    return (ex.groupby(["src", "dst"]).size().rename("exchanges").reset_index()
              .sort_values("exchanges", ascending=False).reset_index(drop=True))


def build_graph(edges: pd.DataFrame, node_lines: Optional[pd.Series] = None,
                weight: str = "scenes_together", min_weight: int = 1) -> nx.Graph:
    """Weighted undirected character graph; isolated speakers are kept as nodes."""
    G = nx.Graph()
    if node_lines is not None:
        for name, n in node_lines.items():
            G.add_node(name, lines=int(n))
    for r in edges.itertuples(index=False):
        w = getattr(r, weight)
        if w >= min_weight:
            G.add_edge(r.a, r.b, weight=int(w))
    return G


def centrality_table(G: nx.Graph) -> pd.DataFrame:
    """Strength, degree, betweenness (distance = 1/weight), PageRank and community per node."""
    if G.number_of_nodes() == 0:
        return pd.DataFrame(columns=["character", "strength", "degree", "betweenness", "pagerank", "community"])
    H = G.copy()
    for _, _, d in H.edges(data=True):
        d["dist"] = 1.0 / d["weight"]
    comm = {}
    if H.number_of_edges():
        for i, c in enumerate(nx.community.greedy_modularity_communities(H, weight="weight")):
            comm.update({n: i for n in c})
    bt = nx.betweenness_centrality(H, weight="dist")
    pr = nx.pagerank(H, weight="weight") if H.number_of_edges() else {n: 0.0 for n in H}
    return pd.DataFrame({
        "character": list(H.nodes),
        "strength": [H.degree(n, weight="weight") for n in H],
        "degree": [H.degree(n) for n in H],
        "betweenness": [bt[n] for n in H],
        "pagerank": [pr[n] for n in H],
        "community": [comm.get(n, -1) for n in H],
    }).sort_values("strength", ascending=False).reset_index(drop=True)
