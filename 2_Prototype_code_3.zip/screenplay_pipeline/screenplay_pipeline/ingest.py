"""Stage 1 - ingestion.

Accepts a single ``.txt`` file, a directory (recursive) or a ``.zip`` archive and
yields ``(name, raw_bytes)`` pairs in natural episode order.  Archives are read
**in memory** via :mod:`zipfile` - nothing is extracted to disk, so a hostile
archive cannot write outside the working directory (zip-slip).
"""
from __future__ import annotations

import re
import zipfile
from pathlib import Path
from typing import Iterator, Optional

_TEXT_SUFFIXES = {".txt", ".fountain", ".script"}


def _natural_key(name: str) -> list:
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", name)]


def iter_sources(path: str | Path, episodes: Optional[set] = None) -> Iterator[tuple[str, bytes]]:
    """Yield ``(file_name, bytes)`` for every script found under *path*.

    ``episodes`` optionally restricts to episode numbers parsed from file names.
    """
    from .parser import episode_number_from_filename

    p = Path(path)
    items: list[tuple[str, object]] = []
    if p.is_file() and p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as zf:
            for info in zf.infolist():
                nm = Path(info.filename)
                if info.is_dir() or nm.suffix.lower() not in _TEXT_SUFFIXES or "__MACOSX" in info.filename:
                    continue
                items.append((nm.name, (zf, info.filename)))
            items.sort(key=lambda t: _natural_key(t[0]))
            for name, (z, member) in items:
                if episodes and episode_number_from_filename(name) not in episodes:
                    continue
                yield name, z.read(member)
        return
    if p.is_file():
        files = [p]
    elif p.is_dir():
        files = [f for f in p.rglob("*") if f.is_file() and f.suffix.lower() in _TEXT_SUFFIXES]
    else:
        raise FileNotFoundError(f"input path not found: {p}")
    for f in sorted(files, key=lambda f: _natural_key(f.name)):
        if episodes and episode_number_from_filename(f.name) not in episodes:
            continue
        yield f.name, f.read_bytes()


def decode_bytes(raw: bytes) -> str:
    """Decode script bytes: UTF-8 (with/without BOM) first, then Windows-1252, then Latin-1."""
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", errors="replace")
