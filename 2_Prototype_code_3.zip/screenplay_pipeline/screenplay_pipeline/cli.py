"""Command line interface:  ``python -m screenplay_pipeline run --input scripts.zip --output out/``"""
from __future__ import annotations

import argparse
import json
from typing import Optional

from .pipeline import DEFAULT_ALIASES, DEFAULT_LEXICON, PipelineConfig, run_pipeline
from .promos import PromoConfig


def _episode_set(spec: Optional[str]) -> Optional[set]:
    """``'1-5,9'`` -> ``{1,2,3,4,5,9}``"""
    if not spec:
        return None
    out: set = set()
    for part in spec.split(","):
        lo, _, hi = part.partition("-")
        out.update(range(int(lo), int(hi or lo) + 1))
    return out


def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser(prog="screenplay_pipeline", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="parse, analyse and export a screenplay set")
    r.add_argument("--input", required=True, help="file, directory or .zip of episode scripts")
    r.add_argument("--output", default="output", help="output directory (default: ./output)")
    r.add_argument("--backend", default="vader", help="sentiment backend: vader | transformer | <registered>")
    r.add_argument("--model", help="model id for --backend transformer")
    r.add_argument("--aliases", default=str(DEFAULT_ALIASES), help="character alias JSON ('' to disable)")
    r.add_argument("--lexicon", default=str(DEFAULT_LEXICON), help="domain lexicon JSON")
    r.add_argument("--workers", type=int, help="process count (default: CPU count; 1 = serial)")
    r.add_argument("--episodes", help="restrict to episode numbers, e.g. '1-10,25'")
    r.add_argument("--beat-seconds", type=float, default=10.0, help="window length for arc / mood analysis")
    r.add_argument("--no-figures", action="store_true")
    r.add_argument("--no-promos", action="store_true", help="skip the promo shortlist")
    r.add_argument("--no-stitch", action="store_true", help="contiguous promos only (no multi-segment stitching)")
    r.add_argument("--no-cross-episode", action="store_true", help="stitch only within one episode")
    r.add_argument("--rerank-provider", default="rules",
                   help="rules (no model) | openai-compatible | anthropic | <registered provider>")
    r.add_argument("--rerank-model", help="model id for the re-rank provider")
    r.add_argument("--rerank-base-url", help="endpoint base URL (openai-compatible: Groq, OpenRouter, Ollama, vLLM ...)")
    r.add_argument("--rerank-key-env", help="name of the environment variable holding the API key")
    r.add_argument("--rerank-cache", help="directory to cache model replies (re-runs are free and reproducible)")
    r.add_argument("--rerank-shortlist", type=int, default=4, help="candidates per episode the model judges")
    r.add_argument("--rerank-blend", type=float, default=0.5, help="weight of the model's verdict in the final score")
    args = ap.parse_args(argv)

    kwargs = {"model": args.model} if args.model else {}
    rk = {k: v for k, v in {"model": args.rerank_model, "base_url": args.rerank_base_url,
                            "api_key_env": args.rerank_key_env, "cache_dir": args.rerank_cache}.items() if v}
    pcfg = PromoConfig(stitch=not args.no_stitch, cross_episode=not args.no_cross_episode)
    cfg = PipelineConfig(input_path=args.input, output_dir=args.output, backend=args.backend,
                         backend_kwargs=kwargs, aliases_path=args.aliases or None, lexicon_path=args.lexicon,
                         workers=args.workers, episodes=_episode_set(args.episodes),
                         make_figures=not args.no_figures, beat_seconds=args.beat_seconds,
                         find_promos=not args.no_promos, promo_config=pcfg, rerank_provider=args.rerank_provider,
                         rerank_kwargs=rk, rerank_shortlist=args.rerank_shortlist, rerank_blend=args.rerank_blend)
    res = run_pipeline(cfg)
    s = res["summary"]
    print(json.dumps({k: s[k] for k in ("n_episodes", "n_scenes", "n_elements", "n_characters",
                                         "series_da_word_ratio", "mean_sentiment", "runtime_seconds")}, indent=2))
    print(f"outputs written to {args.output}/ (REPORT.md, summary.json, data/, figures/)")
    return 0
